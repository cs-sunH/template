from pathlib import Path
import hashlib,json,re,runpy,sys
root=Path(__file__).resolve().parents[2]
repos=('astra-sim-face','astra-sim-face-LRU','astra-sim-wscllm','astra-sim-wscllm-LRU','astra-sim-joint')
core=json.loads((root/'die/configs/core32.json').read_text())
read_rows=runpy.run_path(str(root/'die/tools/check_core_source.py'))['read_rows']
doc=root/core['source_document']['path']
assert hashlib.sha256(doc.read_bytes()).hexdigest()==core['source_document']['sha256']
rows=read_rows(doc);assert rows==core['rows']
results={}
for repo in repos:
 b=root/repo/'extern/die_model'
 legacy=json.loads((b/'configs/core_table.json').read_text())
 assert legacy['source_document']==core['source_document']
 assert len(legacy['rows'])==32
 for row,source in zip(legacy['rows'],rows):
  assert set(row)=={'sram-mb-per-core','noc-width-bits','vec-g-eqop-per-core','pe-int4-gops-per-core','side-ref-um'}
  assert row['sram-mb-per-core']==source['sram_mib_per_core']
  assert row['noc-width-bits']==source['noc_width_bits']
  assert row['vec-g-eqop-per-core']==source['n_vec']*3.9554
  assert row['pe-int4-gops-per-core']==source['n_pe']*2
  assert row['side-ref-um']==source['l0_mm_display']*1000
 text=(b/'src/Hardware.cc').read_text();init=text.split('constexpr CoreTableEntry kCoreTable[32] = {',1)[1].split('\n};',1)[0]
 compiled=[list(map(float,line)) for line in re.findall(r'\{([^{}]+)\}',init) for line in [line.split(',')]]
 assert len(compiled)==32
 for actual,row in zip(compiled,legacy['rows']):
  assert actual==[row[k] for k in ['sram-mb-per-core','noc-width-bits','vec-g-eqop-per-core','pe-int4-gops-per-core','side-ref-um']]
 assert 'CoreType' not in (b/'include/DieTypes.hh').read_text()
 assert 'std::floor' not in text
 configs=[]
 for p in (root/repo/'sh_test_mesh/hardware').glob('*.json'):
  j=json.loads(p.read_text())
  if 'die' not in j:continue
  assert 'core-type' not in j['die'] and 'mesh-nx' not in j['die'] and 'mesh-ny' not in j['die']
  configs.append(p.name)
 paths=[p for p in b.rglob('*') if p.is_file() and 'coarse' not in p.relative_to(b).parts]
 paths += [root/repo/'sh_test_mesh/config_resolver.py', root/repo/'sh_test_mesh/tests/test_config_resolver.py']
 paths += list((root/repo/'sh_test_mesh/hardware').glob('*.json'))
 entries={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}
 results[repo]={'rows':len(compiled),'default_configs_requiring_user_grid':configs,'source_sha256':entries}
print(json.dumps({'status':'passed','document':core['source_document'],'row_count':32,'variants':results},indent=2,ensure_ascii=False))
