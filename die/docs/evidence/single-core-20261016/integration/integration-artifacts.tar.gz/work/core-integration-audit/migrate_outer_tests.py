from pathlib import Path
import re
root=Path(__file__).resolve().parents[2]
repos=['astra-sim-face','astra-sim-face-LRU','astra-sim-wscllm','astra-sim-wscllm-LRU','astra-sim-joint']
for repo in repos:
 r=root/repo
 for directory in ['astra-sim/workload/execution_driven/tests','sh_test_mesh/workload/llama2_7b_inference']:
  for p in (r/directory).rglob('*'):
   if p.suffix not in {'.cc','.py'} or not ('test' in p.name):continue
   t=p.read_text()
   if 'core-type' not in t:continue
   t=t.replace('"core-type": "large",','"mesh-nx": 23, "mesh-ny": 23,')
   t=t.replace('{"core-type", "large"},','{"mesh-nx", 23u}, {"mesh-ny", 23u},')
   t=t.replace('1225.0 * 1218.0 * 1e9','529.0 * 1266.0 * 1e9')
   t=t.replace('default die point of contract §3.5 (0.75 MB large / 800 mm2 /','explicit test fixture (0.75 MiB / 23x23 / 800 mm2 /')
   t=t.replace('contract §3.5 (0.75 MB large / 800 mm2 /','explicit fixture (0.75 MiB / 23x23 / 800 mm2 /')
   p.write_text(t)
 p=r/'sh_test_mesh/tests/test_config_resolver.py';t=p.read_text()
 start=t.index('class DieHardwareTests(');tail=t[start:]
 tail=tail.replace('_HARDWARE_SOURCE','self.fixture_source')
 setup='    def setUp(self) -> None:\n'
 insert='''        # Explicit validation fixture; the checked-in research hardware stays
        # unmodified and requires the user's mesh-nx/mesh-ny choice.
        self._grid_temp = tempfile.TemporaryDirectory()
        self.addCleanup(self._grid_temp.cleanup)
        data = json.loads(_HARDWARE_SOURCE.read_text(encoding="utf-8"))
        data["die"].update({"mesh-nx": 23, "mesh-ny": 23})
        self.fixture_source = Path(self._grid_temp.name) / "explicit_grid_fixture.json"
        self.fixture_source.write_text(json.dumps(data), encoding="utf-8")
'''
 tail=tail.replace(setup,setup+insert,1)
 tail=tail.replace('"core-type": "large",','"mesh-nx": 23, "mesh-ny": 23,')
 tail=tail.replace('derived["mesh_n"], 35','derived["mesh_n"], 23').replace('derived["cores"], 1225','derived["cores"], 529')
 tail=tail.replace('resolved["derived"]["cores"], 1225','resolved["derived"]["cores"], 529')
 tail=tail.replace('1492.05','669.714')
 tail=tail.replace('1.75','3.0')
 tail=tail.replace('exactly_six_keys','explicit_grid_keys').replace('six_key_structure','explicit_grid_structure')
 tail=tail.replace('test_checked_in_die_node_is_the_ruling_point','test_explicit_fixture_preserves_user_hardware_parameters')
 tail=tail.replace('test_checked_in_die_source_resolves_derived_scalars','test_explicit_fixture_resolves_derived_scalars')
 tail=tail.replace('"""契约 §3.5 裁定点:large / 0.75 MB / 800 mm2 / HBM 4x1 / 512 bit','"""Explicit test input: 23x23 / 0.75 MiB / 800 mm2 / HBM 4x1 / 512 bit')
 tail=tail.replace('0.75/large/800/4x1/512','0.75 MiB/23x23/800/4x1/512')
 tail=tail.replace('3.0 MB 不在 §3.1 核表(0.25..2.0 的 14 行)中','3.0 MiB is outside the 32-row Core table')
 before='\n\nif __name__ == "__main__":'
 test='''
    def test_checked_in_hardware_requires_user_explicit_grid(self) -> None:
        original = json.loads(_HARDWARE_SOURCE.read_text(encoding="utf-8"))
        self.assertNotIn("core-type", original["die"])
        self.assertNotIn("mesh-nx", original["die"])
        self.assertNotIn("mesh-ny", original["die"])
        with self.assertRaisesRegex(ValueError, "explicit mesh-nx/mesh-ny"):
            load_hardware_config(_HARDWARE_SOURCE, "validation-die-64g")

    def test_obsolete_core_selector_is_rejected_without_conversion(self) -> None:
        for value in ("small", "large", "core"):
            source = json.loads(self.fixture_source.read_text(encoding="utf-8"))
            source["die"]["core-type"] = value
            path = Path(self._grid_temp.name) / "obsolete_core_selector.json"
            path.write_text(json.dumps(source), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "core-type"):
                load_hardware_config(path, "validation-die-64g")
'''
 tail=tail.replace(before,'\n'+test+before)
 t=t[:start]+tail;p.write_text(t)
print('outer fixtures explicit; default migration rejection and obsolete-selector tests added')
