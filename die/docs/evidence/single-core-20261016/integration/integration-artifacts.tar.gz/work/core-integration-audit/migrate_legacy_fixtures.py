from pathlib import Path
import re
root=Path(__file__).resolve().parents[2]
repos=['astra-sim-face','astra-sim-face-LRU','astra-sim-wscllm','astra-sim-wscllm-LRU','astra-sim-joint']
for repo in repos:
 b=root/repo/'extern/die_model'
 for p in (b/'tests').glob('*'):
  if p.suffix not in {'.cc','.hh'}:continue
  t=p.read_text()
  t=re.sub(r'die_node\(([^,]+), "(?:large|small)",',r'die_node(\1,',t)
  t=t.replace('die_node(double sram, const char* type, double area,','die_node(double sram, double area,')
  t=t.replace('std::uint64_t width) {\n  nlohmann::json die;','std::uint64_t width, std::uint64_t nx = 23,\n                               std::uint64_t ny = 23) {\n  nlohmann::json die;')
  t=t.replace('  die["core-type"] = type;','  die["mesh-nx"] = nx;\n  die["mesh-ny"] = ny;')
  t=t.replace('"sram-mb-per-core": 0.75, "core-type": "large",','"sram-mb-per-core": 0.75, "mesh-nx": 23, "mesh-ny": 23,')
  t=t.replace('  die["core-type"] = "large";','  die["mesh-nx"] = 23u;\n  die["mesh-ny"] = 23u;')
  t=t.replace('hw_small()', 'hw_low_sram()')
  t=t.replace('die_node(0.75, 500, 2, 2, 256)','die_node(0.75, 500, 2, 2, 256, 18, 18)')
  t=t.replace('35u &&','23u &&').replace('== 1225u','== 529u')
  t=t.replace('0.9079551923877489 * 1218e9','0.9079551923877489 * 1266e9')
  t=t.replace('hw4.mesh_n, 29, "29x29 mesh on the 4-stack point"','hw4.mesh_n, 18, "explicit 18x18 mesh on the 4-stack fixture"')
  if p.name=='selection_fuzz_test.cc':
   t=t.replace('static const double sram[] = {0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 2.0};','static const double sram[] = {0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0};')
   t=t.replace('static const std::uint64_t widths[] = {64, 128, 256, 512, 1024};','static const std::uint64_t widths[] = {64, 128, 256, 512};')
   t=t.replace('sram[r.u64(0, 6)]','sram[r.u64(0, 7)]').replace('widths[r.u64(0, 4)]','widths[r.u64(0, 3)]')
   t=t.replace('  die["core-type"] = r.chance(0.5) ? "small" : "large";','  const auto n = r.u64(1, 4);\n  die["mesh-nx"] = n;\n  die["mesh-ny"] = n;')
  if p.name=='configs_consistency_test.cc':
   t=t.replace('14 rows','32 rows').replace('== 14','== 32').replace('14,','32,')
   start=t.index('    expect(r.at("core-type")');end=t.index('    expect_double(r.at("vec-g-eqop-per-core")',start)
   t=t[:start]+'''    expect(r.at("noc-width-bits").get<std::uint64_t>() == rows[i].noc_width_bits,
           (what + " NoC width").c_str());
'''+t[end:]
   t=t.replace('pe-gflops-per-core','pe-int4-gops-per-core').replace('pe_gflops_per_core','pe_int4_gops_per_core')
  p.write_text(t)
 # Rewrite fixture header's obsolete physical point explanation, retaining tests.
 p=b/'tests/test_helpers.hh';t=p.read_text();start=t.index('/*\ntest_helpers.hh');end=t.index('*/',start)+2
 t=t[:start]+'''/*
Shared explicit hardware fixtures for legacy ABI compatibility tests.
0.75 MiB / 800 mm2 / 512 bit / 23x23 and 0.25 MiB / 300 mm2 /
256 bit / 23x23 are test inputs, not selected or recommended architectures.
The production typed model and this compatibility layer use one Core design.
*/'''+t[end:]
 t=t.replace('0.75/large','0.75 MiB').replace('The §3.5 default die point.','The explicit 23x23 compatibility-test fixture.')
 p.write_text(t)
print('legacy unit fixtures migrated, hardware_test is replaced separately')
