from pathlib import Path
import json
root=Path(__file__).resolve().parents[2]
repos=['astra-sim-face','astra-sim-face-LRU','astra-sim-wscllm','astra-sim-wscllm-LRU','astra-sim-joint']
for r in repos:
 repo=root/r;b=repo/'extern/die_model'
 p=b/'include/DieTypes.hh';s=p.read_text().replace('  double compute_area_mm2 = 0.0;','''  double compute_area_mm2 = 0.0;
  bool explicit_die_dimensions = false;
  double die_width_mm = 0.0;
  double die_height_mm = 0.0;''');p.write_text(s)
 p=b/'src/Hardware.cc';s=p.read_text().replace('"mesh-ny", "compute-area-mm2", "hbm-per-side",','"mesh-ny", "compute-area-mm2", "die-width-mm", "die-height-mm", "hbm-per-side",')
 marker='  hw.hbm_per_side = detail::require_uint(die, "hbm-per-side", path);'
 s=s.replace(marker,'''  const bool has_width = die.contains("die-width-mm");
  const bool has_height = die.contains("die-height-mm");
  if (has_width != has_height) {
    detail::fail(path, "die-width-mm and die-height-mm must be provided together");
  }
  if (has_width) {
    hw.explicit_die_dimensions = true;
    hw.die_width_mm = detail::require_number(die, "die-width-mm", path);
    hw.die_height_mm = detail::require_number(die, "die-height-mm", path);
    if (!(hw.die_width_mm > 0.0) || !(hw.die_height_mm > 0.0)) {
      detail::fail(path, "die-width-mm and die-height-mm must be positive");
    }
    const long double physical_area = static_cast<long double>(hw.die_width_mm) * hw.die_height_mm;
    const long double difference = std::abs(physical_area - hw.compute_area_mm2);
    if (!std::isfinite(physical_area) ||
        difference > 1e-12L * std::max(1.0L, std::abs(static_cast<long double>(hw.compute_area_mm2)))) {
      detail::fail(path, "die-width-mm times die-height-mm must equal compute-area-mm2");
    }
  }
'''+marker)
 s=s.replace('#include <cmath>','#include <algorithm>\n#include <cmath>')
 marker='  // Fit above bounds the number of Cores for the legacy area\'s finite set.'
 s=s.replace(marker,'''  if (hw.explicit_die_dimensions &&
      (side > static_cast<long double>(hw.die_width_mm) ||
       side > static_cast<long double>(hw.die_height_mm))) {
    detail::fail(path, "explicit Core grid does not fit die-width-mm and die-height-mm independently; no automatic hardware resize is performed");
  }
'''+marker)
 marker='  die["compute-area-mm2"] = hw.compute_area_mm2;'
 s=s.replace(marker,marker+'''
  if (hw.explicit_die_dimensions) {
    die["die-width-mm"] = hw.die_width_mm;
    die["die-height-mm"] = hw.die_height_mm;
  }''')
 marker='  derived["mesh_n"] = hw.mesh_n;'
 s=s.replace(marker,'''  derived["die_geometry_mode"] = hw.explicit_die_dimensions
      ? "explicit_width_height" : "legacy_area_only_square_compatibility";
'''+marker)
 p.write_text(s)
 p=b/'src/CostModel.cc';s=p.read_text();marker='  s += ",d{" + std::to_string(hw.mesh_n)'
 s=s.replace(marker,'''  if (hw.explicit_die_dimensions) {
    s += ",shape{" + std::to_string(hw.die_width_mm) + "," +
         std::to_string(hw.die_height_mm) + "}";
  }
'''+marker);p.write_text(s)
 p=repo/'sh_test_mesh/config_resolver.py';s=p.read_text().replace('_LEGAL_NOC_WIDTH_BITS = frozenset({64, 128, 256, 512})','_DIE_OPTIONAL_KEYS = frozenset({"die-width-mm", "die-height-mm"})\n_LEGAL_NOC_WIDTH_BITS = frozenset({64, 128, 256, 512})')
 s=s.replace('if actual != set(_DIE_NODE_KEYS):','if (_DIE_NODE_KEYS - actual) or (actual - _DIE_NODE_KEYS - _DIE_OPTIONAL_KEYS):').replace('extra = sorted(actual - _DIE_NODE_KEYS)','extra = sorted(actual - _DIE_NODE_KEYS - _DIE_OPTIONAL_KEYS)')
 marker='    _require_number(die["compute-area-mm2"], f"{context}.compute-area-mm2", positive=True)'
 s=s.replace(marker,marker+'''
    if ("die-width-mm" in die) != ("die-height-mm" in die):
        raise ValueError(f"{context}.die-width-mm and die-height-mm must be provided together")
    if "die-width-mm" in die:
        _require_number(die["die-width-mm"], f"{context}.die-width-mm", positive=True)
        _require_number(die["die-height-mm"], f"{context}.die-height-mm", positive=True)''')
 p.write_text(s)
 for p in (repo/'sh_test_mesh/hardware').glob('*.json'):
  j=json.loads(p.read_text())
  if 'die' not in j:continue
  j['die'].update({'mesh-nx':10,'mesh-ny':10,'die-width-mm':25,'die-height-mm':32})
  j['notes']=[x for x in j.get('notes',[]) if not x.startswith('Migration required:')]
  j['notes'].append('User-authorized engineering comparison point (2026-10-16): 10 x 10 Core grid on a 25 mm x 32 mm compute Die (800 mm2), 0.75 MiB SRAM/Core and 512-bit NoC. Architectural PE peak is 126.6 INT4 TOPS, numerically compared with the TX8 128 BF16 TFLOPS reference; precision and independent measurement are not equivalent. Vec FP32-equivalent peak is 12.65728 T eq-op/s, not the TX8 1 T reference. Legacy HBM remains the preserved 4 x 16 GB / 410 GB/s per-stack reference (64 GB and 1640 GB/s), not current DOCX HBM3E.')
  p.write_text(json.dumps(j,indent=2,ensure_ascii=False)+'\n')
 p=repo/'sh_test_mesh/tests/test_config_resolver.py';s=p.read_text()
 s=s.replace('        data["die"].update({"mesh-nx": 23, "mesh-ny": 23})','''        data["die"].pop("die-width-mm", None)
        data["die"].pop("die-height-mm", None)
        data["die"].update({"mesh-nx": 23, "mesh-ny": 23})''')
 start=s.index('    def test_checked_in_hardware_requires_user_explicit_grid');end=s.index('    def test_obsolete_core_selector_is_rejected_without_conversion',start)
 s=s[:start]+'''    def test_checked_in_authorized_engineering_point(self) -> None:
        original = json.loads(_HARDWARE_SOURCE.read_text(encoding="utf-8"))
        self.assertNotIn("core-type", original["die"])
        self.assertEqual((original["die"]["mesh-nx"], original["die"]["mesh-ny"]), (10, 10))
        self.assertEqual((original["die"]["die-width-mm"], original["die"]["die-height-mm"]), (25, 32))
        hardware = load_hardware_config(_HARDWARE_SOURCE, "validation-die-64g")
        self.assertEqual(hardware.die_derived["cores"], 100)
        self.assertAlmostEqual(hardware.die_derived["pe_peak_int4_tops"], 126.6)
        self.assertEqual(hardware.die_derived["die_geometry_mode"], "explicit_width_height")

    def test_optional_dimensions_are_paired_and_physically_checked(self) -> None:
        source = json.loads(self.fixture_source.read_text(encoding="utf-8"))
        for dimensions, needle in (({"die-width-mm": 25}, "provided together"),
                ({"die-width-mm": 25, "die-height-mm": 33}, "must equal"),
                ({"die-width-mm": 10, "die-height-mm": 80}, "independently")):
            current = json.loads(json.dumps(source))
            current["die"].update(dimensions)
            path = Path(self._grid_temp.name) / "invalid_dimensions.json"
            path.write_text(json.dumps(current), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, needle):
                load_hardware_config(path, "validation-die-64g")

'''+s[end:]
 p.write_text(s)
 # Geometry unit coverage keeps the existing area-only explicit-grid fixture.
 p=b/'tests/hardware_test.cc';s=p.read_text();marker='  // Width changes installed units, never the user grid or the Core outline.'
 s=s.replace(marker,'''  j=node(0.75,512,10,10);j["die-width-mm"]=25.0;j["die-height-mm"]=32.0;
  const auto explicit_shape=DieModel::make_hardware(j);
  check(explicit_shape.explicit_die_dimensions && explicit_shape.cores==100,"authorized explicit dimensions");
  near(explicit_shape.pe_peak_die,126.6e12,"authorized INT4 engineering peak");
  auto explicit_summary=DieModel::hardware_summary_json(explicit_shape);
  check(DieModel::hardware_summary_json(DieModel::make_hardware(nlohmann::json::parse(explicit_summary.dump())))==explicit_summary,"explicit dimensions wire round trip");
  check(explicit_summary.at("die").at("die-width-mm")==25.0 && explicit_summary.at("die").at("die-height-mm")==32.0,"dimensions carried on wire");
  j.erase("die-height-mm");reject(j,"provided together");
  j["die-height-mm"]=33.0;reject(j,"must equal");
  j["die-width-mm"]=10.0;j["die-height-mm"]=80.0;reject(j,"independently");
'''+marker);p.write_text(s)
 p=b/'include/DieModel.hh';s=p.read_text().replace('// integers fitting the area, and are never inferred or resized.','''// integers fitting the area, and are never inferred or resized. Optional paired
// die-width-mm/die-height-mm must multiply to compute-area-mm2 and independently
// fit the Core grid. Without them, only legacy area-only square compatibility
// is checked; this is reported as die_geometry_mode in the summary.''');p.write_text(s)
print('authorized 10x10,25x32 point and paired geometry contract installed in five variants')
