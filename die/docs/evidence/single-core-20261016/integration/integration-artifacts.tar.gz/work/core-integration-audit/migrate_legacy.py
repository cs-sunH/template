from pathlib import Path
import json,re
root=Path(__file__).resolve().parents[2]
repos=['astra-sim-face','astra-sim-face-LRU','astra-sim-wscllm','astra-sim-wscllm-LRU','astra-sim-joint']
canonical=json.loads((root/'die/configs/core32.json').read_text())
rows=[]
for r in canonical['rows']:
 rows.append({'sram-mb-per-core':r['sram_mib_per_core'],'noc-width-bits':r['noc_width_bits'],'vec-g-eqop-per-core':r['n_vec']*3.9554,'pe-int4-gops-per-core':r['n_pe']*2.0,'side-ref-um':r['l0_mm_display']*1000})
for repo in repos:
 base=root/repo/'extern/die_model'
 p=base/'include/DieTypes.hh';t=p.read_text()
 t=t.replace('enum class CoreType { Small, Large };\n','').replace('DIE_MODEL_ENUM_FN(CoreType, "small", "large")\n','')
 t=t.replace('  CoreType core_type = CoreType::Small;','  std::uint64_t noc_width_bits = 0;')
 t=t.replace('  CoreType core_type = CoreType::Large;\n','')
 t=t.replace('pe_gflops_per_core','pe_int4_gops_per_core')
 t=t.replace('14-row','32-row').replace('six §3.1 inputs','explicit hardware inputs').replace('six die inputs','hardware inputs')
 t=t.replace('// GFLOP/s per core','// INT4 GOPS per core; architectural peak assumption')
 t=t.replace('// FLOP/s\n  double vec_peak_die','// INT4 op/s (legacy scalar field name retained)\n  double vec_peak_die')
 p.write_text(t)
 p=base/'src/CostModel.cc';t=p.read_text().replace('pe_gflops_per_core','pe_int4_gops_per_core')
 t=t.replace('s += "," + std::to_string(hw.sram_mb_per_core) + "," + to_string(hw.core_type);','s += "," + std::to_string(hw.sram_mb_per_core);')
 p.write_text(t)
 table={'schema_version':1,'profile':'core_table','source_document':canonical['source_document'],'core_resource_table_id':'core32_v1','capacity_unit':'MiB (legacy sram-mb-per-core key spelling retained)','pe_unit':'INT4 GOPS; architectural assumption, not measured BF16 throughput','rows':rows}
 (base/'configs/core_table.json').write_text(json.dumps(table,indent=2,ensure_ascii=False)+'\n')
 p=base/'src/Hardware.cc';t=p.read_text()
 start=t.index('constexpr CoreTableEntry kCoreTable[');end=t.index('\n};',start)+3
 block='constexpr CoreTableEntry kCoreTable[32] = {\n'+''.join('    {'+f'{r["sram-mb-per-core"]}, {r["noc-width-bits"]}, {r["vec-g-eqop-per-core"]!r}, {r["pe-int4-gops-per-core"]!r}, {r["side-ref-um"]!r}'+'},\n' for r in rows)+'};'
 t=t[:start]+block+t[end:]
 t=t.replace('14-row','32-row').replace('14 rows','32 rows').replace('x 5 widths x 14 core rows = 700 candidates','x 4 widths x 8 SRAM capacities')
 t=t.replace('constexpr std::uint64_t kLegalNoCWidths[5] = {64, 128, 256, 512, 1024};','constexpr std::uint64_t kLegalNoCWidths[4] = {64, 128, 256, 512};')
 start=t.index('// Reference NoC bit width per core type');end=t.index('\nstd::string layout_list()',start)
 t=t[:start]+'// The authoritative Core outline is fixed by the SRAM long side.\n// NoC width selects installed PE/Vec resources, without resizing the Core.\n'+t[end:]
 t=t.replace('"sram-mb-per-core", "core-type", "compute-area-mm2"','"sram-mb-per-core", "compute-area-mm2"')
 start=t.index('  const std::string core_type =');end=t.index('\n  hw.compute_area_mm2',start)
 t=t[:start]+t[end:]
 t=t.replace('// (sram, core-type) must hit the core table (design doc §3.1).','// Match the unique Core resource row by SRAM capacity and NoC width.')
 t=t.replace('row.core_type == hw.core_type','row.noc_width_bits == hw.noc_width_bits')
 t=t.replace('no core table row for (sram-mb-per-core, core-type) = (','no core table row for (sram-mb-per-core, noc-width-bits) = (')
 t=t.replace('to_string(hw.core_type)','std::to_string(hw.noc_width_bits)')
 t=t.replace('not in {64,128,256,512,1024}','not in {64,128,256,512}')
 start=t.index('  const double width_ref =');end=t.index('  const double n_exact =',start)
 t=t[:start]+'''  const double core_side_mm = hw.core_row.core_side_ref_um / 1000.0;
  hw.acore_mm2 = core_side_mm * core_side_mm;
'''+t[end:]
 t=t.replace('pe_gflops_per_core','pe_int4_gops_per_core').replace('0.90 * hw.sram_mb_per_core * 1e6','0.90 * hw.sram_mb_per_core * 1048576.0')
 t=t.replace('  die["core-type"] = std::to_string(hw.noc_width_bits);\n','')
 t=t.replace('  derived["pe_peak_tflops"] = hw.pe_peak_die / 1e12;','''  // The legacy key is kept for ABI consumers; the typed companion records
  // the actual INT4 unit and prevents this architectural peak being mistaken
  // for independently measured BF16/FP32 hardware throughput.
  derived["pe_peak_tflops"] = hw.pe_peak_die / 1e12;
  derived["pe_peak_int4_tops"] = hw.pe_peak_die / 1e12;
  derived["pe_peak_provenance"] = "DOCX architectural INT4 peak; legacy scalar model, not target hardware calibration";''')
 t=t.replace('strict parsing/validation of the six §3.1 die inputs','strict parsing/validation of the explicit die inputs')
 p.write_text(t)
print('migrated 32-row legacy Core resources without touching defaults or grid policy')
