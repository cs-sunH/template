from pathlib import Path
import argparse,hashlib,json,os,re,subprocess,sys,time
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--label',required=True);p.add_argument('--phase',choices=['configure','build','unit','config','default'],required=True);a=p.parse_args()
root=Path(__file__).resolve().parents[2];repo=root/a.repo
if a.repo not in ('astra-sim-face','astra-sim-face-LRU','astra-sim-wscllm','astra-sim-wscllm-LRU','astra-sim-joint'):p.error('not an active variant')
work=root/'work/core-integration-audit';out=work/'results'/a.label;out.mkdir(parents=True,exist_ok=False)
build=work/'build'/a.repo
cmake='/workspace/template/work/tool-env/cmake/data/bin/cmake';ctest='/workspace/template/work/tool-env/cmake/data/bin/ctest';ninja='/workspace/template/work/tool-env/bin/ninja'
targets=['die_model_cabi','tx8_reference_test','hardware_test','spec_parse_test','configs_consistency_test','workload_test','mapping_test','costmodel_test','tx8_compile_test','execution_test','selection_fuzz_test','capi_test']
cmds={'configure':[cmake,'-S',str(repo/'extern/die_model'),'-B',str(build),'-G','Ninja','-DCMAKE_MAKE_PROGRAM='+ninja,'-DCMAKE_CXX_COMPILER=/usr/bin/g++','-DCMAKE_BUILD_TYPE=Release','-DCOARSE_DIE_BUILD_TESTS=OFF'],
 'build':[cmake,'--build',str(build),'--parallel','2','--target']+targets,
 'unit':[ctest,'--test-dir',str(build),'--output-on-failure'],
 'config':[sys.executable,'-B','-m','unittest','discover','-s',str(repo/'sh_test_mesh/tests'),'-p','test_config_resolver*.py','-v'],
 'default':[sys.executable,'-B','-c','import sys,json;from pathlib import Path;sys.path.insert(0,sys.argv[1]);from config_resolver import load_hardware_config;\ntry:load_hardware_config(Path(sys.argv[2]),"validation-die-64g")\nexcept ValueError as e:\n assert "explicit mesh-nx/mesh-ny" in str(e);print(json.dumps({"status":"expected_rejected","error":str(e)}));sys.exit(0)\nraise RuntimeError("default research hardware must not gain an automatically selected grid")',str(repo/'sh_test_mesh'),str(repo/'sh_test_mesh/hardware/face_case5_config_c.json')]}
command=cmds[a.phase];env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1';env['DIE_MODEL_CABI_PATH']=str(build/'lib/libdie_model_cabi.so');env['DIE_COARSE_CABI_PATH']=str(build/'lib/libcoarse_die_cabi.so')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=[x for x in (repo/'extern/die_model').rglob('*') if x.is_file() and 'coarse' not in x.relative_to(repo/'extern/die_model').parts]
files += [repo/'sh_test_mesh/config_resolver.py',repo/'sh_test_mesh/tests/test_config_resolver.py']
files += list((repo/'sh_test_mesh/hardware').glob('*.json'))
identity={'repo':a.repo,'phase':a.phase,'command':command,'cwd':str(root),'source_sha256':{str(x.relative_to(root)):sha(x) for x in sorted(set(files))},'runner_sha256':sha(Path(__file__)),'started_unix':time.time()}
with (out/'run.log').open('w') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
identity.update(finished_unix=time.time(),return_code=r.returncode,log_sha256=sha(out/'run.log'))
identity['libraries']={str(x):sha(x) for x in (build/'lib').glob('*.so')} if (build/'lib').is_dir() else {}
log=(out/'run.log').read_text();counts=re.findall(r'Ran (\d+) tests? in ',log)
identity['tests_run']=int(counts[-1]) if counts else None
identity['skips_mentioned']='skipped' in log.lower()
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
print(json.dumps({k:identity[k] for k in ['repo','phase','return_code','tests_run','skips_mentioned']}))
if r.returncode:print(log[-6500:])
raise SystemExit(r.returncode)
