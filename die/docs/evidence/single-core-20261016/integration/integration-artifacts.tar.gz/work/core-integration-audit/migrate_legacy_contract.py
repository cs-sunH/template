from pathlib import Path
import re,json
root=Path(__file__).resolve().parents[2]
repos=['astra-sim-face','astra-sim-face-LRU','astra-sim-wscllm','astra-sim-wscllm-LRU','astra-sim-joint']
for repo in repos:
 r=root/repo;base=r/'extern/die_model'
 p=base/'src/Hardware.cc';t=p.read_text()
 t=t.replace('"sram-mb-per-core", "compute-area-mm2", "hbm-per-side",','"sram-mb-per-core", "mesh-nx", "mesh-ny", "compute-area-mm2", "hbm-per-side",')
 marker='  hw.compute_area_mm2 = detail::require_number(die, "compute-area-mm2", path);'
 t=t.replace(marker,'''  if (!die.contains("mesh-nx") || !die.contains("mesh-ny")) {
    detail::fail(path, "explicit mesh-nx and mesh-ny are required; hardware grids are never inferred from area; use coarse_die_v2 for rectangular grids");
  }
  const auto nx = detail::require_uint(die, "mesh-nx", path);
  const auto ny = detail::require_uint(die, "mesh-ny", path);
  if (nx == 0 || ny == 0 || nx != ny) {
    detail::fail(path, "mesh-nx and mesh-ny must be equal positive integers in the legacy scalar backend; use coarse_die_v2 for rectangular grids");
  }
  hw.mesh_n = nx;
'''+marker)
 start=t.index('  const double n_exact =');end=t.index('  hw.pe_peak_die =',start)
 t=t[:start]+'''  const long double side = static_cast<long double>(hw.mesh_n) * core_side_mm;
  const long double occupied = side * side;
  if (occupied > static_cast<long double>(hw.compute_area_mm2)) {
    detail::fail(path, "explicit mesh-nx x mesh-ny Core grid exceeds compute-area-mm2 at the DOCX SRAM-long-side Core outline; provide a legal hardware configuration, no automatic resize is performed");
  }
  // Fit above bounds the number of Cores for the legacy area's finite set.
  hw.cores = hw.mesh_n * hw.mesh_n;
'''+t[end:]
 t=t.replace('  die["sram-mb-per-core"] = hw.sram_mb_per_core;','  die["sram-mb-per-core"] = hw.sram_mb_per_core;\n  die["mesh-nx"] = hw.mesh_n;\n  die["mesh-ny"] = hw.mesh_n;')
 t=t.replace('  derived["pe_peak_tflops"] = hw.pe_peak_die / 1e12;','  derived["pe_peak_tflops"] = hw.pe_peak_die / 1e12;\n  derived["pe_peak_tflops_deprecated_unit"] = "INT4 TOPS compatibility scalar; not BF16/FP32 TFLOPS";')
 t=t.replace('  derived["hbm_count"] = hw.hbm_count;','  derived["hbm_count"] = hw.hbm_count;\n  derived["hbm_profile"] = "legacy_16GB_410GBps_per_stack_reference; not current DOCX HBM3E";')
 t=t.replace('Bare die node: exactly the six keys','Bare die node: explicit hardware keys including mesh-nx/mesh-ny')
 p.write_text(t)
 p=base/'include/DieTypes.hh';t=p.read_text().replace('0.90 * sram_mb * 1e6','0.90 * sram_mib * 1048576')
 t=t.replace('double mesh_n =','double mesh_n =')
 t=t.replace('// n, mesh side length in cores','// explicit mesh-nx == mesh-ny, Cores per side')
 p.write_text(t)
 p=base/'include/DieModel.hh';t=p.read_text().replace('"sram-mb-per-core": 0.75, "core-type": "large",','"sram-mb-per-core": 0.75, "mesh-nx": 23, "mesh-ny": 23,')
 p.write_text(t)
 p=base/'include/DieCApi.h';t=p.read_text().replace('...six keys...','...explicit hardware keys including mesh-nx/mesh-ny...')
 p.write_text(t)
 p=r/'sh_test_mesh/config_resolver.py';t=p.read_text()
 t=t.replace('        "core-type",','        "mesh-nx",\n        "mesh-ny",')
 t=t.replace('_LEGAL_NOC_WIDTH_BITS = frozenset({64, 128, 256, 512, 1024})','_LEGAL_NOC_WIDTH_BITS = frozenset({64, 128, 256, 512})')
 start=t.index('    core_type = die["core-type"]');end=t.index('    _require_number(die["compute-area-mm2"]',start)
 t=t[:start]+'''    nx = _require_int(die["mesh-nx"], f"{context}.mesh-nx", positive=True)
    ny = _require_int(die["mesh-ny"], f"{context}.mesh-ny", positive=True)
    if nx != ny:
        raise ValueError(f"{context} requires equal mesh-nx/mesh-ny; use coarse_die_v2 for rectangular grids")
'''+t[end:]
 t=t.replace('"unexpected {\', \'.join(extra)})")','"unexpected {\', \'.join(extra)}); explicit mesh-nx/mesh-ny are required, never inferred from area")')
 t=t.replace('die 节六键的结构检查','die 节显式网格的结构检查').replace('die 六参数','die 显式硬件参数')
 p.write_text(t)
 for p in (r/'sh_test_mesh/hardware').glob('*.json'):
  j=json.loads(p.read_text())
  if 'die' in j:
   j['die'].pop('core-type',None)
   notes=j.get('notes',[])
   notes=[x for x in notes if 'large cores /' not in x]
   notes.append('Migration required: the single Core design requires user-specified mesh-nx and mesh-ny. These inputs are intentionally absent; no Core grid is inferred or selected from the preserved area/SRAM/NoC configuration. Legacy HBM remains the explicit 16 GB / 410 GB/s per-stack reference, not current DOCX HBM3E.')
   j['notes']=notes;p.write_text(json.dumps(j,indent=2,ensure_ascii=False)+'\n')
print('legacy explicit-grid contract updated; checked-in hardware intentionally lacks new user grid')
