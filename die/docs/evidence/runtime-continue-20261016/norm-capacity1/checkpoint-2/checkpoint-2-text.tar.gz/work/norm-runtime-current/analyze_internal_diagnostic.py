#!/usr/bin/env python3
from pathlib import Path
from fractions import Fraction
from decimal import Decimal,getcontext
import hashlib,json,subprocess
getcontext().prec=80
HERE=Path(__file__).resolve().parent
log=HERE/'run-interior-internal-diagnostic/run.stderr.log'
contract=json.loads((HERE/'norm-seven-epoch-contract.json').read_text())
macros=subprocess.check_output(['c++','-dM','-E','-x','c++','/dev/null'],text=True)
mantissa=int(next(x.split()[-1] for x in macros.splitlines() if x.startswith('#define __LDBL_MANT_DIG__')))
assert mantissa==64, 'This exact reconstruction is scoped to observed x87 64-bit-significand ABI'
def exact_progress(text):
 q=Fraction(text)
 if q==0:return q
 sign=1 if q>0 else -1;q=abs(q)
 e=q.numerator.bit_length()-q.denominator.bit_length()
 def pow2(n):return Fraction(2**n) if n>=0 else Fraction(1,2**(-n))
 while q<pow2(e):e-=1
 while q>=pow2(e+1):e+=1
 unit=pow2(e-(mantissa-1));v=q/unit;n,r=divmod(v.numerator,v.denominator)
 if 2*r>v.denominator or (2*r==v.denominator and n%2):n+=1
 return sign*n*unit

def dec(x):return str(Decimal(x.numerator)/Decimal(x.denominator))
records=[];integrates=[]
for line in log.read_text().splitlines():
 if line.startswith('norm_integrate '):integrates.append(json.loads(line.split(' ',1)[1]))
 if not line.startswith('norm_recompute '):continue
 record=json.loads(line.split(' ',1)[1]);epoch=contract['epochs'][record['epoch']]
 p={a['id']:exact_progress(a['progress']) for a in record['activities']}
 credit=[Fraction(str(v)) for v in epoch['credit_initial']]
 for a in epoch['activities']:
  for b in range(2):credit[b]+=Fraction(str(a['credit_delta'][b]))*p[a['id']]
 record['exact_credit_of_reconstructed_represented_progress']=list(map(dec,credit))
 record['represented_credit_outside_closed_capacity']=[credit[b]<0 or credit[b]>epoch['credit_capacity'][b] for b in range(2)]
 record['exact_outside_magnitude']=[dec(-credit[b] if credit[b]<0 else credit[b]-Fraction(str(epoch['credit_capacity'][b])))
   if record['represented_credit_outside_closed_capacity'][b] else '0' for b in range(2)]
 records.append(record)
violations=[r for r in records if any(r['represented_credit_outside_closed_capacity'])]
result={'scope':'observation-only mixed interior diagnostic; exact Fraction analysis of represented x87 progress, not timing candidate',
 'long_double_significand_bits':mantissa,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),
 'integrate_calls':len(integrates),'recompute_calls':len(records),
 'all_positive_deltas':all(Fraction(x['delta_ns'])>0 for x in integrates),
 'all_represented_clocks_advanced':all(x['origin_before']!=x['origin_after'] or x['fraction_before']!=x['fraction_after'] for x in integrates),
 'minimum_integrate_delta_ns':str(min(Fraction(x['delta_ns']) for x in integrates)),
 'represented_credit_outside_observations':len(violations),'outside_records':violations,
 'records':records,'integrates':integrates,
 'public_snapshots_byte_identical_to_nondiagnostic':all(
   (HERE/'run-interior-only/trace'/f'event-{n:03}.json').read_bytes()==
   (HERE/'run-interior-internal-diagnostic/trace'/f'event-{n:03}.json').read_bytes() for n in range(14))}
(HERE/'internal-diagnostic-analysis.json').write_text(json.dumps(result,indent=2)+'\n')
summary={k:v for k,v in result.items() if k not in ['records','integrates']}
print(json.dumps(summary,indent=2))
