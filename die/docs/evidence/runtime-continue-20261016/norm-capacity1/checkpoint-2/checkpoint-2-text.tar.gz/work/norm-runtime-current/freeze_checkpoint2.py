#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,shutil
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;DEST=HERE/'checkpoint-2';DEST.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths=[]
for name in ['CANDIDATE2-STATUS.md','build_variant.py','Execution-interior-diagnostic.cc','Execution-physical-candidate.cc',
 'Execution-physical-diagnostic.cc','Execution-physical-diagnostic-v2.cc','physical_credit_helper.inc',
 'prepare_physical_candidate.py','capacity_one_slack_driver.cc','run_capacity_one.py','subepsilon_credit_driver.cc',
 'run_subepsilon.py','analyze_internal_diagnostic.py','internal-diagnostic-analysis.json',
 'internal-diagnostic-analysis.stdout.log','runtime_snapshot_split_owner_diagnostic.cc',
 'runtime_snapshot_split_owner_ulp_probe.cc','run_ulp_probe.py','credit_enclosure_oracle.cc',
 'run_enclosure_oracle.py','freeze_checkpoint2.py']:
 paths.append(HERE/name)
paths.extend(HERE.glob('build-*.stdout.log'));paths.extend(HERE.glob('capacity-one-*.stdout.log'))
paths.extend(HERE.glob('subepsilon-*.stdout.log'));paths.extend(HERE.glob('focused-physical*.stdout.log'))
paths.extend(HERE.glob('ab-ulp-*.stdout.log'));paths.extend(HERE.glob('enclosure-offline*.stdout.log'))
for name in ['capacity-one-baseline-ab-interior','capacity-one-physical-enclosure','subepsilon-ab-physical',
 'run-interior-internal-diagnostic','candidate-interior-diagnostic','candidate-physical-enclosure',
 'candidate-physical-diagnostic','candidate-physical-diagnostic-v2','run-physical-enclosure',
 'focused-physical-enclosure','split-reject-diagnostic','service-curve-reject-diagnostic',
 'physical-context-diagnostic-v2','ab-ulp-probe','enclosure-offline-oracle']:
 paths.extend(p for p in (HERE/name).rglob('*') if p.is_file())
for name in ['die/tests/runtime_subunit_credit_test.cc','die/tests/runtime_snapshot_split_owner_test.cc',
 'die/tests/service_curve_runtime_test.cc','die/tests/test_support.hh','die/tests/fixtures/snapshot_split_owner.json']:
 paths.append(ROOT/name)
rows=[]
for path in sorted(set(paths)):
 if path.suffix in ['.a','.o','.so','.pyc'] or not path.suffix:continue
 assert path.suffix in ['.json','.jsonl','.log','.py','.cc','.hh','.h','.md','.patch','.inc'],str(path)
 rel=path.relative_to(ROOT);dest=DEST/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,dest)
 assert sha(path)==sha(dest)
 rows.append({'original_path':str(rel),'saved_path':str(dest.relative_to(DEST)),
  'original_sha256':sha(path),'saved_sha256':sha(dest),'bytes':dest.stat().st_size})
manifest={'status':'completed_frozen_checkpoint_no_binaries','scope':'current-Core actual numerical dependencies; candidate2 rejected; no production adoption',
 'files':rows,'excluded':['ELF','objects','archives','shared libraries','parent time-only research']}
(DEST/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'files':len(rows),'bytes':sum(r['bytes'] for r in rows),'manifest_sha256':sha(DEST/'manifest.json')},indent=2))
