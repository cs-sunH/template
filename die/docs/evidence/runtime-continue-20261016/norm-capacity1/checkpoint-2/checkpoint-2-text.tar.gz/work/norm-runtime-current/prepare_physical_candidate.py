#!/usr/bin/env python3
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
s=(ROOT/'die/src/Execution.cc').read_text()
def change(a,b,count=1):
 global s
 assert s.count(a)==count,(a[:90],s.count(a),count)
 s=s.replace(a,b)
change('const std::array<const char*, resource_count> kResourceNames = {',
 (HERE/'physical_credit_helper.inc').read_text()+'\nconst std::array<const char*, resource_count> kResourceNames = {')
change('''long double min_positive(long double current, long double candidate) {
  if (!std::isfinite(candidate) || candidate <= kTimeEpsilonNs) return current;''',
'''long double min_positive(long double current, long double candidate,bool strict_positive=false) {
  if (!std::isfinite(candidate) || candidate <= (strict_positive?0:kTimeEpsilonNs)) return current;''')
# Existing near-terminal closure must use the same physical boundary classifier;
# its progress-close and residual guards are unchanged.
change('''            credit_blocked = credit_blocked ||
                (execution.credit[buffer] <= tolerance && slope[buffer] < 0.0) ||
                (execution.credit[buffer] >= epoch.credit_capacity[buffer]-tolerance &&
                 slope[buffer] > 0.0);''',
'''            const auto boundary=physical_credit(execution);
            credit_blocked = credit_blocked ||
                (boundary.low[buffer] && slope[buffer] < 0.0) ||
                (boundary.high[buffer] && slope[buffer] > 0.0);''')
change('''      unsigned mask = 0;
      for (std::size_t b = 0; b < 2; ++b) {
        const double tolerance = credit_boundary_tolerance(execution,b,
            kCreditTolerance * std::max(1.0, execution.credit_capacity[b]));
        if (execution.credit[b] <= tolerance) mask |= 1u << (2 * b);
        if (execution.credit[b] >= execution.credit_capacity[b] - tolerance)
          mask |= 2u << (2 * b);
      }''',
'''      unsigned mask = 0;
      const auto boundary=physical_credit(execution);
      for (std::size_t b = 0; b < 2; ++b) {
        if (boundary.low[b]) mask |= 1u << (2 * b);
        if (boundary.high[b]) mask |= 2u << (2 * b);
      }''')
change('''    for(std::size_t b=0;b<2;++b) {
      const double tolerance=credit_boundary_tolerance(*ref.execution,b,
          kCreditTolerance*std::max(1.0,ref.execution->credit_capacity[b]));
      const double credit=ref.execution->credit[b];
      if((credit<=tolerance&&ref.credit_slope[b]<0.0)||
         (credit>=ref.execution->credit_capacity[b]-tolerance&&ref.credit_slope[b]>0.0))
        rate=0.0;
    }''',
'''    const auto boundary=physical_credit(*ref.execution);
    for(std::size_t b=0;b<2;++b) {
      if((boundary.low[b]&&ref.credit_slope[b]<0.0)||
         (boundary.high[b]&&ref.credit_slope[b]>0.0)) rate=0.0;
    }''')
change('''      const double credit = execution->credit[buffer];
      const double capacity = execution->credit_capacity[buffer];
      const double tolerance = credit_boundary_tolerance(*execution,buffer,
          kCreditTolerance * std::max(1.0, capacity));
      const bool at_low = credit <= tolerance;
      const bool at_high = credit >= capacity - tolerance;''',
'''      const auto boundary=physical_credit(*execution);
      const bool at_low = boundary.low[buffer];
      const bool at_high = boundary.high[buffer];''')
# Both event paths reconstruct physical state once per execution.
change('''      long double credit_rate[2]{0.0L, 0.0L};''',
'''      const auto physical=physical_credit(execution);
      long double credit_rate[2]{0.0L, 0.0L};''')
change('''
    long double credit_rate[2]{0.0L, 0.0L};''',
'''
    const auto physical=physical_credit(execution);
    long double credit_rate[2]{0.0L, 0.0L};''')
# Above indentation-insensitive substring would match nested declaration too;
# assert and repair the only duplicated insertion if it occurred.
s=s.replace('''      const auto physical=physical_credit(execution);
      const auto physical=physical_credit(execution);
    long double credit_rate''','''      const auto physical=physical_credit(execution);
      long double credit_rate''')
change('''const long double credit = execution.credit[buffer];''',
'''const long double credit = physical.raw[buffer];''',2)
change('''if (rate > 0.0L && credit < capacity - tolerance) {''',
'''if (rate > 0.0L && credit < capacity - (physical.curved?0:tolerance)) {''',2)
change('''} else if (rate < 0.0L && credit > tolerance) {''',
'''} else if (rate < 0.0L && credit > (physical.curved?0:tolerance)) {''',2)
change('''(capacity - credit) / rate * kNsPerSecond);''',
'''(capacity - credit) / rate * kNsPerSecond,physical.curved);''',2)
change('''credit / (-rate) * kNsPerSecond);''',
'''credit / (-rate) * kNsPerSecond,physical.curved);''',2)
# Keep all legacy time policy; curved worlds retain positive represented times.
start=s.index('void Runtime::advance_to(');end=s.index('\nvoid Runtime::cancel(',start)
part=s[start:end]
part=part.replace('''  if (absolute_ns < now_ns_)''','''  const bool strict_curved=std::any_of(executions_.begin(),executions_.end(),
      [](const auto& e){return has_credit_curves(*e.second.plan);});
  const long double event_epsilon=strict_curved?0:kTimeEpsilonNs;
  if (absolute_ns < now_ns_)''')
part=part.replace('kTimeEpsilonNs','event_epsilon')
part=part.replace('event_epsilon=strict_curved?0:event_epsilon','event_epsilon=strict_curved?0:kTimeEpsilonNs')
part=part.replace('remain / live.rate * kNsPerSecond);','remain / live.rate * kNsPerSecond,strict_curved);')
s=s[:start]+part+s[end:]
start=s.index('std::optional<std::uint64_t> Runtime::next_event() const');end=s.index('\nnlohmann::json Runtime::query_progress',start)
part=s[start:end].replace('''  long double delta =''','''  const bool strict_curved=std::any_of(executions_.begin(),executions_.end(),
      [](const auto& e){return has_credit_curves(*e.second.plan);});
  long double delta =''',1)
part=part.replace('remain / live.rate * kNsPerSecond);','remain / live.rate * kNsPerSecond,strict_curved);')
part=part.replace('std::ceil(delta - kTimeEpsilonNs)','std::ceil(delta - (strict_curved?0:kTimeEpsilonNs))')
s=s[:start]+part+s[end:]
change('''std::uint64_t Runtime::ceil_exact_time() const {
  if (exact_ns_ <= kTimeEpsilonNs) return exact_origin_ns_;''',
'''std::uint64_t Runtime::ceil_exact_time() const {
  const bool strict_curved=std::any_of(executions_.begin(),executions_.end(),
      [](const auto& e){return has_credit_curves(*e.second.plan);});
  if (exact_ns_ <= (strict_curved?0:kTimeEpsilonNs)) return exact_origin_ns_;''')
# Fail closed on events which cannot advance represented clock or any service.
change('''  const long double seconds = delta_ns / kNsPerSecond;''',
'''  const bool strict_curved=std::any_of(executions_.begin(),executions_.end(),
      [](const auto& e){return has_credit_curves(*e.second.plan);});
  if(strict_curved && next_origin==exact_origin_ns_ && next_fraction==exact_ns_)
    throw std::runtime_error("numerical_failure: positive curved interval cannot advance represented clock");
  bool eligible_service=false,represented_service=false;
  const long double seconds = delta_ns / kNsPerSecond;''')
change('''      long double delta_progress = static_cast<long double>(live.rate) * seconds;''',
'''      eligible_service=true;
      long double delta_progress = static_cast<long double>(live.rate) * seconds;''')
change('''      live.progress = next_progress;''',
'''      represented_service=represented_service || next_progress>live.progress;
      live.progress = next_progress;''')
change('''  if (compute_busy) compute_busy_ns_ += delta_ns;''',
'''  if(strict_curved && eligible_service && !represented_service)
    throw std::runtime_error("numerical_failure: positive curved interval cannot advance represented physical progress");
  if (compute_busy) compute_busy_ns_ += delta_ns;''')
# Imported published allocations use exactly the same physical boundary state.
change('''        const long double capacity = execution.credit_capacity[buffer];
        const long double tolerance = credit_boundary_tolerance(execution,buffer,
            static_cast<long double>(kCreditTolerance) * std::max(1.0L, capacity));
        const bool at_low = execution.credit[buffer] <= tolerance;
        const bool at_high = execution.credit[buffer] >= capacity - tolerance;''',
'''        const auto boundary=physical_credit(execution);
        const bool at_low = boundary.low[buffer];
        const bool at_high = boundary.high[buffer];''')
(HERE/'Execution-physical-candidate.cc').write_text(s)
print('prepared research-only physical helper candidate; no production edit')
