// Offline arithmetic check only: emit actual candidate helper enclosures.
#include "test_support.hh"
#include <cmath>
#include <iomanip>
#include <limits>
#include <sstream>
namespace coarse_die {std::array<long double,2> accumulated_credit(const LiveActivity&);}
namespace candidate_arithmetic {
using namespace coarse_die;
constexpr double kCreditTolerance=2e-10;
template<class T>T credit_boundary_tolerance(const Execution&,std::size_t,T original){return original;}
#include "physical_credit_helper.inc"
}
using namespace coarse_die;using nlohmann::json;
std::string exact_text(long double x){std::ostringstream s;s<<std::scientific<<std::setprecision(std::numeric_limits<long double>::max_digits10)<<x;return s.str();}
int main(){
 std::vector<std::vector<CreditPoint>> curves{
  {{0,{{0,0}}},{1,{{254,-255}}}},
  {{0,{{0,0}}},{.5,{{0,0}}},{1,{{2000000,-2000000}}}},
  {{0,{{0,0}}},{.3,{{1.1,-.7}}},{.7,{{5.3,2.2}}},{1,{{6.9,-7.1}}}},
  {{0,{{0,0}}},{1,{{std::ldexp(1.,-60),-std::ldexp(1.,-60)}}}},
  {{0,{{0,0}}},{.3,{{1e-300,-1e-300}}},{1,{{3e-300,2e-300}}}},
  {{0,{{0,0}}},{.7,{{1e300,-1e300}}},{1,{{2e300,3e300}}}}
 };
 std::vector<long double> progress{0,1,.5L,.25L,.75L,.3L,.7L,
  std::nextafter(1.L,0.L),std::nextafter(.5L,0.L),std::nextafter(.5L,1.L),
  std::ldexp(1.L,-100),std::ldexp(1.L,-1000)};
 std::uint64_t state=0x91e10da5c79e7b1dULL;
 for(unsigned i=0;i<64;++i){state^=state<<13;state^=state>>7;state^=state<<17;progress.push_back(std::ldexp(static_cast<long double>(state),-64));}
 unsigned id=0;
 for(std::size_t c=0;c<curves.size();++c)for(auto p:progress){
  LiveActivity live;live.progress=p;live.definition.credit_curve=curves[c];live.definition.credit_delta=curves[c].back().cumulative;
  json curve=json::array();for(auto point:curves[c])curve.push_back({{"progress",point.progress},{"cumulative",point.cumulative}});
  json boxes=json::array();for(unsigned b=0;b<2;++b){const auto box=candidate_arithmetic::credit_contribution_interval(live,b);boxes.push_back({{"lower",exact_text(box.lo)},{"upper",exact_text(box.hi)}});}
  std::cout<<json{{"case",id++},{"curve_index",c},{"curve",curve},{"progress",exact_text(p)},
   {"enclosures",boxes},{"long_double_digits",std::numeric_limits<long double>::digits},
   {"long_double_min_exponent",std::numeric_limits<long double>::min_exponent}}.dump()<<'\n';
 }
}
