#!/usr/bin/env python3
from pathlib import Path
import subprocess,json,hashlib,os
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;d=HERE/'ab-ulp-probe';d.mkdir(exist_ok=False)
s=HERE/'runtime_snapshot_split_owner_ulp_probe.cc';a=ROOT/'work/build-runtime-ab-release/libcoarse_die.a';o=ROOT/'work/build-runtime-ab-release/CMakeFiles/coarse_die_cabi.dir/src/Capi.cc.o';exe=d/'probe'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
cmd=['c++','-std=c++17','-O2','-I'+str(ROOT/'die/include'),'-I'+str(ROOT/'die/tests'),'-I'+str(ROOT/'astra-sim-wscllm/extern/helper'),'-DCOARSE_DIE_SOURCE_DIR="'+str(ROOT/'die')+'"','-DCOARSE_DIE_ROOT_DIR="'+str(ROOT)+'"',str(s),str(o),str(a),'-o',str(exe)]
r={'scope':'fresh A+B exact source-rate integrity probes; changed only probe direction/count and logging in scratch test','command':cmd,'source_sha256':sha(s),'archive_sha256':sha(a),'capi_object_sha256':sha(o),'probes':[]}
c=subprocess.run(cmd,text=True,capture_output=True,timeout=180);(d/'compile.stdout.log').write_text(c.stdout);(d/'compile.stderr.log').write_text(c.stderr);r['compile_returncode']=c.returncode
if c.returncode==0:
 r['executable_sha256']=sha(exe)
 for ulps in [-5,-4,-3,-2,2,3,4,5]:
  env=dict(os.environ);env['COARSE_SPLIT_TAMPER_ULPS']=str(ulps)
  c=subprocess.run([str(exe)],env=env,text=True,capture_output=True,timeout=30)
  name=('plus' if ulps>0 else 'minus')+str(abs(ulps));(d/(name+'.stdout.log')).write_text(c.stdout);(d/(name+'.stderr.log')).write_text(c.stderr)
  row={'ulps_from_actual_source_rate':ulps,'returncode':c.returncode,'diagnostic_reject':[]}
  for line in c.stderr.splitlines():
   if line.startswith('diagnostic_reject '):
    data=json.loads(line.split(' ',1)[1]);row['diagnostic_reject'].append({k:v for k,v in data.items() if k!='requested_snapshot'})
  row['tamper_accepted']=any(x['actual_status']==0 and x['result_handle']!=0 for x in row['diagnostic_reject'])
  r['probes'].append(row)
(d/'identity.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k=='probes'},indent=2))
