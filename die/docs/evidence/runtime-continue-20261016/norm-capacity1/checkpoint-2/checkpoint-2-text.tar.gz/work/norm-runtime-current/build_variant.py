#!/usr/bin/env python3
"""Build one isolated Execution object and relink a frozen base archive serially."""
from pathlib import Path
import argparse,hashlib,json,shutil,subprocess,time
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 p=argparse.ArgumentParser();p.add_argument('--name',required=True);p.add_argument('--source',type=Path,required=True);p.add_argument('--scope',required=True)
 a=p.parse_args();dest=HERE/('candidate-'+a.name);dest.mkdir(exist_ok=False)
 source=dest/'die/src';source.mkdir(parents=True);shutil.copytree(ROOT/'die/include',dest/'die/include')
 for name in ['PackingAllocation.hh','RatioAllocation.hh']:shutil.copy2(ROOT/'die/src'/name,source/name)
 shutil.copy2(a.source,source/'Execution.cc')
 archive=dest/'libcoarse_die.a';base=ROOT/'work/build-runtime-ab-release/libcoarse_die.a';shutil.copy2(base,archive)
 patch=subprocess.run(['diff','-u',str(ROOT/'die/src/Execution.cc'),str(source/'Execution.cc')],text=True,capture_output=True)
 (dest/'variant.patch').write_text(patch.stdout)
 command=['c++','-std=c++17','-O3','-DNDEBUG','-Wall','-Wextra','-Wpedantic',
  '-I'+str(dest/'die/include'),'-I'+str(ROOT/'astra-sim-wscllm/extern/helper'),'-c',str(source/'Execution.cc'),'-o',str(dest/'Execution.cc.o')]
 r={'scope':a.scope+'; mixed relink, not fresh adoption','source_input':str(a.source),'source_input_sha256':sha(a.source),
 'base_archive_sha256':sha(base),'compile_command':command,'source_sha256':{str(p.relative_to(dest)):sha(p) for p in sorted((dest/'die').rglob('*')) if p.is_file()}}
 started=time.monotonic();c=subprocess.run(command,cwd=ROOT,text=True,capture_output=True,timeout=180)
 (dest/'compile.stdout.log').write_text(c.stdout);(dest/'compile.stderr.log').write_text(c.stderr)
 r['compile_returncode']=c.returncode;r['compile_wall_s']=time.monotonic()-started
 if c.returncode==0:
  command=['ar','r',str(archive),str(dest/'Execution.cc.o')];subprocess.run(command,check=True,timeout=20)
  r['archive_update_command']=command;r['archive_sha256']=sha(archive)
  r['archive_objects_sha256']={n:hashlib.sha256(subprocess.check_output(['ar','p',str(archive),n])).hexdigest() for n in subprocess.check_output(['ar','t',str(archive)],text=True).splitlines()}
 r['base_archive_sha256_after']=sha(base);(dest/'identity.json').write_text(json.dumps(r,indent=2)+'\n')
 print(json.dumps(r,indent=2));return c.returncode
if __name__=='__main__':raise SystemExit(main())
