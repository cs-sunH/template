# Candidate2：已拒绝，物理与兼容性依赖分开保存

`candidate-physical-enclosure/` 只替换 fresh A+B 静态库中的 Execution 对象，
属于 mixed relink 实验，**不是 fresh 全源构建，未采用**。源码、patch、命令、
object/library/ELF hash 及全部真实结果均保存。

新增 helper 对当前 epoch 最多 3 个活动、2 个 channel，使用 nextafter 向外舍入，
重建未 snap 的物理 inventory/headroom 及公式计算包络。owner 边界 mask、singleton、
LP、事件、终态 roundoff 的边界上下文、snapshot 切向验证共用此状态。公开 wire
仍保留原 snap；原 validation 宽度、progress-close、工量、Q、PRIVATE、R1 和固定分段
均未放宽。曲线正事件不再被旧时间 floor 擦去，clock 和至少一项 progress 推进分别检查。

## 实际通过和失败范围

- 完整七 epoch：双 owner 均在 5135048829ns 完成，28 个内部事件、14 个公开观察；
  公开时刻没有信用区间被证实越界，投影后的 bytes/Vec 总量通过。这是 synthetic。
- capacity1 dyadic：emptying/filling 两方向均通过精确 500ms 事件、quarter progress .25、
  500e9 已付操作、原 busy、snapshot 和 cancel。fresh main、A+B、interior-only 各库两方向
  均为实际 red：初始无事件、250ms 进度仍为零。
- 独立正 subepsilon：A+B red、候选2通过。unit=2^-60、capacity=4unit、initial=unit、
  delta=-2unit、gate/PRIVATE=2^-85s、Q=1、Vec=1e12；真半程触底事件为
  1.29246970711410574198658e-17ns。A+B 丢初始事件，advance_to1ns 越界到 -2^-60 后
  被原 guard 拒绝。候选2只执行半程、支付500e9、原 busy 恰为真实间隔、固定事件、
  restore/cancel 均通过。它是 Runtime 时间依赖，不是 Norm 修复。
- 原 focused 回归：tiny-credit 通过；split-owner 和 service-curve **失败**。未修改原测试
  或期望来制造通过。

## 两个实际失败的原因

split 的日志副本确认，冻结的 source-minus-4-ULP 探针得到 DIE_OK=0、新 handle15。
source rate=7862645.685395651，非法保存 rate=7862645.685395647；普通重建 rate 等于
source，而冗余 row witness 重建为7862645.685395646，非法值恰为它 +1ULP。
候选2因此违反既有冻结负4ULP回归，保持 REJECTED。

合同须区分：one-ULP 实现相对于实际 chosen canonical 重建，不是相对于未知的历史
source vector。另测 fresh A+B：source=7862645.685395646，普通 canonical=...651；
-2/-3/-4/-5 以及 +2/+3 source ULP 被拒，+4/+5 被接受且落普通 canonical ±1ULP 内。
这不能冒称 B 新回归或硬件精度错误。若要求绑定唯一历史 source allocation，v3 缺少
allocation context，需另行设计 context/version；本次只记录设计需求，不扩大实施。

service-curve 的仅日志诊断确认：epoch `progress_delayed_output` 中 Compute progress
严格停在0.5、rate1；Store progress 却达到3.63797880709171295158926e-21、rate0.5。
output 为 -7.27595761418342590317852e-21，公式包络完全负，约为
[-7.275957614183425909e-21, -7.275957614183425897e-21]，容量1。
这证实 per-role 表示失配：消费者付服务，而生产者的表示进度未改变。helper failclosed
保留了真实失败；候选2尚未使此合法输入可用。

## 算术证明与兼容性边界

包络覆盖**给定表示进度下的曲线公式求值**，不自动覆盖从连续积分到多个独立 progress
的舍入误差。至少一项 progress 变动不能证明所有相关角色守恒。需要分别验证 chosen
事件的相关角色及其物理进展，不能赠送服务、放宽容量或改变 busy 定义。

当前 strict_curved 扫描所有 retained Plan，包括 queued/terminal 曲线，可能改变后续
纯 legacy endpoint 的时钟行为且增加扫描开销。需要清楚的当前活跃曲线/时钟一致性合同。
no-progress 检测目前位于部分活动修改之后，不是原子拒绝，不能称源状态未变。

interior-only 的独立内部日志有25次integrate、111次recompute，全部正dt并推进clock，
最小dt约0.124999704654ns。精确 Fraction 重构当前x87 64-bit-significand progress，
发现8个 stats 表示信用高于512的观察，最大1.2620685034970668e-17；raw求和恰为512。
其14份公开快照与非诊断版逐byte相同。公开时刻未证实越界不等于全部内部积分严格安全，
也不等于覆盖subepsilon。

实际 C++ contribution-enclosure helper 另与独立 Fraction 公式对拍：456case、912channel
全部包含参考值；覆盖端点、相邻progress、非dyadic knot、2^-60、1e-300、1e300及每曲线64个
固定随机progress。原始C++输出、独立oracle和身份在 `enclosure-offline-oracle/`。
这个结果只验证所采样的公式求值包络，不证明积分、per-role服务、snapshot上下文或采用。

准备脚本曾因缩进子串重复匹配而 assertion；当时没有生成候选源码或开始编译，修正后才
构建当前候选。所有 C++ 初始失败、后续仅日志诊断和新探针结果分别保存，没有覆盖。
