#!/usr/bin/env python3
from pathlib import Path
from fractions import Fraction
import hashlib,json,subprocess
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;DEST=HERE/'enclosure-offline-oracle';DEST.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=HERE/'credit_enclosure_oracle.cc';exe=DEST/'oracle';library=ROOT/'work/build-runtime-ab-release/libcoarse_die.a'
command=['c++','-std=c++17','-O2','-Wall','-Wextra','-Wpedantic','-I'+str(HERE),'-I'+str(ROOT/'die/include'),'-I'+str(ROOT/'die/tests'),'-I'+str(ROOT/'astra-sim-wscllm/extern/helper'),'-DCOARSE_DIE_SOURCE_DIR="'+str(ROOT/'die')+'"','-DCOARSE_DIE_ROOT_DIR="'+str(ROOT)+'"',str(source),str(library),'-o',str(exe)]
report={'scope':'offline candidate contribution enclosure vs exact Fraction formula at represented progress; does not certify integration or adoption',
 'source_sha256':sha(source),'helper_sha256':sha(HERE/'physical_credit_helper.inc'),'library_sha256':sha(library),'command':command}
c=subprocess.run(command,text=True,capture_output=True,timeout=180);(DEST/'compile.stdout.log').write_text(c.stdout);(DEST/'compile.stderr.log').write_text(c.stderr);report['compile_returncode']=c.returncode
if c.returncode:
 (DEST/'report.json').write_text(json.dumps(report,indent=2)+'\n');raise SystemExit(2)
report['executable_sha256']=sha(exe);c=subprocess.run([str(exe)],text=True,capture_output=True,timeout=30);(DEST/'raw.jsonl').write_text(c.stdout);(DEST/'run.stderr.log').write_text(c.stderr);report['returncode']=c.returncode

def pow2(n):return Fraction(2**n) if n>=0 else Fraction(1,2**(-n))
def represented(text,digits,min_exp):
 q=Fraction(text)
 if not q:return q
 sign=1 if q>0 else -1;q=abs(q);e=q.numerator.bit_length()-q.denominator.bit_length()
 while q<pow2(e):e-=1
 while q>=pow2(e+1):e+=1
 unit=pow2(max(e-(digits-1),min_exp-digits));value=q/unit;n,r=divmod(value.numerator,value.denominator)
 if 2*r>value.denominator or (2*r==value.denominator and n%2):n+=1
 return sign*n*unit
failures=[];channels=0;cases=0
for line in c.stdout.splitlines():
 a=json.loads(line);cases+=1;digits=a['long_double_digits'];minimum=a['long_double_min_exponent'];p=represented(a['progress'],digits,minimum)
 curve=[(Fraction.from_float(float(x['progress'])),[Fraction.from_float(float(v)) for v in x['cumulative']]) for x in a['curve']]
 upper=next((i for i,x in enumerate(curve) if x[0]>p),None)
 for b in range(2):
  channels+=1
  exact=curve[-1][1][b] if upper is None else curve[upper-1][1][b]+(p-curve[upper-1][0])/(curve[upper][0]-curve[upper-1][0])*(curve[upper][1][b]-curve[upper-1][1][b])
  lo=represented(a['enclosures'][b]['lower'],digits,minimum);hi=represented(a['enclosures'][b]['upper'],digits,minimum)
  if not lo<=exact<=hi:failures.append({'case':a['case'],'channel':b,'exact':str(exact),'lower':str(lo),'upper':str(hi)})
report.update({'cases':cases,'channels':channels,'failures':failures,'status':'passed' if not failures and c.returncode==0 else 'failed','raw_sha256':sha(DEST/'raw.jsonl')})
(DEST/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k in ['status','cases','channels','failures']},indent=2))
