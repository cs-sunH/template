// Exact dyadic physical slack at an ordinary capacity1 boundary. Runtime-only.
#include "test_support.hh"
#include <cmath>
#include <filesystem>
#include <fstream>
using namespace coarse_die;
using namespace coarse_die_test;
namespace fs=std::filesystem;
namespace {
void save(const fs::path& p,const json& j) {std::ofstream out(p);out<<j.dump(2)<<'\n';}
json run(const fs::path& directory,bool filling,const Hardware& hw) {
  fs::create_directories(directory);
  const double gap=std::ldexp(1.,-36),delta=std::ldexp(1.,-35);
  Epoch e;e.name="exact_dyadic_capacity_one_half_second";
  e.credit_capacity={{1,0}};e.credit_initial={{filling?1-gap:gap,0}};
  auto a=activity(1,Role::Compute,COMPUTE_GATE,1);
  a.private_time_s=1;a.canonical_q=1;a.vec_eqops=1000000000000ULL;
  a.credit_delta={{filling?delta:-delta,0}};
  a.credit_curve={{0,{{0,0}}},{1,a.credit_delta}};e.activities={a};
  const auto plan=manual_plan(hw,{e},"new_capacity_one_dyadic_positive_slack_v1");
  json result={{"filling",filling},{"gap",gap},{"delta",delta},
               {"plan",plan_to_json(*plan)},{"assertions",json::array()},{"observations",json::array()}};
  Runtime r(hw);const auto h=r.submit(plan,owner(1,1,1),0);
  auto check=[&](bool good,const char* message){result["assertions"].push_back({{"passed",good},{"message",message}});};
  auto observe=[&](const char* name){
    const auto next=r.next_event();const auto snapshot=r.export_snapshot();
    save(directory/(std::string(name)+"-snapshot.json"),snapshot);
    result["observations"].push_back({{"name",name},{"now_ns",r.now_ns()},
      {"next_event_ns",next?json(*next):json(nullptr)},{"query",r.query_progress(h)},
      {"counters",r.counters()}});
    return snapshot;
  };
  observe("initial");
  check(r.next_event()==500000000ULL,"exact dyadic inventory/headroom pays exactly 0.5 second");
  r.advance_to(250000000ULL);const auto quarter=observe("quarter");
  check(r.query_progress(h).at("activities")[0].at("progress")==0.25,"quarter second earns exact progress0.25");
  check(r.query_progress(h).at("served").at("vec_eqops")==250000000000ULL,"quarter second pays250e9 operations");
  try {
    const auto fork=Runtime::import_snapshot(hw,quarter);
    check(fork->export_snapshot()==quarter,"actual quarter snapshot roundtrips exactly");
  }catch(const std::exception& error){check(false,error.what());}
  r.advance_to(500000000ULL);observe("half");
  check(!r.next_event()&&!r.drained()&&r.query_progress(h).at("activities")[0].at("progress")==0.5,
        "only the physically payable half completes, remaining work blocks");
  r.advance_to(750000000ULL);observe("blocked");
  check(r.query_progress(h).at("served").at("vec_eqops")==500000000000ULL&&
        r.counters().at("compute_busy_ns")==500000000ULL,"blocked interval earns no unpaid ops or original busy");
  r.cancel(h,750000000ULL);observe("cancelled");
  check(r.drained()&&r.query_progress(h).at("cancelled")==true&&
        r.query_progress(h).at("served").at("vec_eqops")==500000000000ULL,"cancel retains exactly physical half trillion work");
  bool good=true;for(const auto& c:result["assertions"])good=good&&c.at("passed").get<bool>();
  result["status"]=good?"passed":"failed";save(directory/"result.json",result);return result;
}
}
int main(int argc,char**argv){
  if(argc!=3){std::cerr<<"usage: capacity_one_slack_driver OUTPUT LABEL\n";return 2;}
  const fs::path directory=argv[1];fs::create_directories(directory);
  std::array<double,resource_count> rates{};rates[COMPUTE_GATE]=1;
  auto hw=manual_hardware(rates);
  hw.fingerprint="synthetic_current_core_capacity_one_dyadic_slack_v1:"+
    stable_hash(json{{"current_resolved_hardware",hw.fingerprint},{"rates",rates}}.dump());
  json report={{"label",argv[2]},{"scope","current-Core synthetic Runtime-only; exact dyadic physical slack"},
               {"hardware_fingerprint",hw.fingerprint},{"cases",json::array()}};
  bool passed=true;
  for(bool filling:{false,true}){
    try{auto r=run(directory/(filling?"filling":"emptying"),filling,hw);
      passed=passed&&r.at("status")=="passed";report["cases"].push_back(r);
    }catch(const std::exception& error){passed=false;report["cases"].push_back({{"filling",filling},{"status","exception"},{"error",error.what()}});}
  }
  report["status"]=passed?"passed":"failed";save(directory/"report.json",report);
  std::cout<<json{{"label",argv[2]},{"status",report["status"]}}.dump()<<'\n';return passed?0:1;
}
