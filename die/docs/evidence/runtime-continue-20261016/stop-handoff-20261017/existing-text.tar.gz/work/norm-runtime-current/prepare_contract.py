#!/usr/bin/env python3
"""Read immutable evidence; extract numeric work, never import saved Runtime state."""
from pathlib import Path
import hashlib
import json
import tarfile

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
BASE = ROOT / 'die/docs/analysis/pre-core-migration-20261016'
ARCHIVE_SHA = '975e7a574f3a6ce322f340f2824c4ce12ebcaa35b0879d67e8d5612f0dee589e'
MEMBERS = {
    'work/norm-review/runtime-archive-20261016/strict-projection.stderr.log':
        '0973c32fd6bdf2e891ba5c096cf3b4722440cbf710da8cbc4bfc13eaf64226c6',
    'die/tests/norm_long_row_test.cc':
        '37933c20a538e995b349c2d5ff9b4e6f5d2331a8423dfe25f8dee7dea8423ba0',
    'die/src/NormLongRow.hh':
        '16b428bdbb8a7ae622b391dedf0ff3d9d9f4bb1e26c1f0954cddd4c431020ff7',
}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def main():
    archive = BASE / 'unadopted-artifacts.tar.gz'
    manifest = json.loads((BASE / 'manifest.json').read_text())
    assert sha(archive.read_bytes()) == ARCHIVE_SHA == manifest['archive_sha256']
    extracted = {}
    with tarfile.open(archive) as tf:
        for name, digest in MEMBERS.items():
            data = tf.extractfile(name).read()
            assert sha(data) == digest == manifest['source_files_and_raw_sha256'][name]
            destination = OUT / Path(name).name
            destination.write_bytes(data)
            extracted[name] = {'sha256': digest, 'bytes': len(data),
                               'destination': str(destination.relative_to(ROOT))}
    log = (OUT / 'strict-projection.stderr.log').read_text()
    saved = json.JSONDecoder().raw_decode(log.split('nonadvancing_runtime_snapshot ', 1)[1])[0]
    old = saved['executions'][0]['plan']
    assert len(saved['executions']) == 2
    assert old == saved['executions'][1]['plan']
    assert len(old['epochs']) == 7
    assert sum(len(e['activities']) for e in old['epochs']) == 12
    assert old['launch_ns'] == 0
    ledger_keys = ['hbm_read_bytes_total', 'hbm_write_bytes_total', 'physical_transfer_bytes',
                   'sram_read_bytes', 'sram_write_bytes', 'vec_equivalent_ops',
                   'local_bus_bytes', 'norm_long_row_ledger', 'service_curves']
    source = {'archive': str(archive.relative_to(ROOT)), 'archive_sha256': ARCHIVE_SHA,
              'member': next(iter(MEMBERS)), 'member_sha256': MEMBERS[next(iter(MEMBERS))],
              'historical_hardware_fingerprint': saved['hardware_fingerprint'],
              'historical_plan_fingerprint': old['fingerprint']}
    contract = {
        'schema': 'synthetic_numeric_norm_contract_v1', 'source': source,
        'synthetic_rates': saved['capacities'], 'synthetic_vec_peak_per_core': 204800,
        'total_cores': 4, 'active_cores': 1, 'launch_ns': old['launch_ns'],
        'epochs': old['epochs'], 'historical_task_context': old['task'],
        'physical_ledger': {key: old['summary'][key] for key in ledger_keys},
        'historical_stall': {
            'now_ns': saved['now_ns'], 'internal_events': saved['internal_events'],
            'epoch': saved['executions'][0]['epoch_index'],
            'activities': [{k: v for k, v in a.items() if k in
                            ['activity_id', 'curve_progress_exact', 'done', 'rate', 'alpha']}
                           for a in saved['executions'][0]['activities'] if a['epoch_index'] == 4],
        },
    }
    # Integer byte/operation totals are checked independently of saved summary.
    acts = [a for e in old['epochs'] for a in e['activities']]
    assert sum(a['vec_eqops'] for a in acts) == 8 * 65537 == 524296
    assert sum(a['hbm_bytes'][r][0] for a in acts for r in range(2)) == 8 * 65537 == 524296
    assert sum(a['hbm_bytes'][r][1] for a in acts for r in range(2)) == 4 * 65537 == 262148
    for resource in [1, 2]:
        assert sum(a['work'][resource] for a in acts) == 20 * 65537 + 16 == 1310756
    assert sum(a['work'][3] for a in acts) == 28 * 65537 + 32 == 1835068
    (OUT / 'norm-seven-epoch-contract.json').write_text(json.dumps(contract, indent=2) + '\n')
    (OUT / 'extraction.json').write_text(json.dumps({'archive': str(archive.relative_to(ROOT)),
        'archive_sha256': ARCHIVE_SHA, 'members': extracted}, indent=2) + '\n')
    print(json.dumps({'status': 'numeric_contract_extracted_not_executed',
                      'epochs': 7, 'activities': 12, 'contract_sha256':
                      sha((OUT / 'norm-seven-epoch-contract.json').read_bytes())}, indent=2))

if __name__ == '__main__':
    main()
