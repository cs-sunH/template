#!/usr/bin/env python3
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import time
ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
DEST=HERE/'candidate-interior-only'
DEST.mkdir(exist_ok=False)
source=DEST/'die/src'
include=DEST/'die/include'
source.mkdir(parents=True)
shutil.copytree(ROOT/'die/include',include)
for name in ['Execution.cc','PackingAllocation.hh','RatioAllocation.hh']:
 shutil.copy2(ROOT/'die/src'/name,source/name)
path=source/'Execution.cc'
before=path.read_text()
needle='''    if (std::abs(credit[buffer]) <= tolerance) credit[buffer] = 0.0L;
    if (std::abs(credit[buffer] - capacity) <= tolerance) credit[buffer] = capacity;
    execution.credit[buffer] = static_cast<double>(credit[buffer]);'''
replacement='''    // ISOLATED CAUSAL EXPERIMENT ONLY: keep real interior inventory/headroom.
    // All validation tolerances, event/tangent guards and legacy paths stay.
    const bool curved = std::any_of(epoch.activities.begin(),epoch.activities.end(),
        [](const Activity& activity) { return !activity.credit_curve.empty(); });
    if (std::abs(credit[buffer]) <= tolerance && (!curved || credit[buffer] <= 0.0L))
      credit[buffer] = 0.0L;
    if (std::abs(credit[buffer] - capacity) <= tolerance && (!curved || credit[buffer] >= capacity))
      credit[buffer] = capacity;
    execution.credit[buffer] = static_cast<double>(credit[buffer]);'''
assert before.count(needle)==1
path.write_text(before.replace(needle,replacement))
patch=subprocess.run(['diff','-u',str(ROOT/'die/src/Execution.cc'),str(path)],text=True,capture_output=True)
(DEST/'interior-only.patch').write_text(patch.stdout)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
original=ROOT/'work/build-runtime-ab-release/libcoarse_die.a'
archive=DEST/'libcoarse_die-interior-only.a'
shutil.copy2(original,archive)
command=['c++','-std=c++17','-O3','-DNDEBUG','-Wall','-Wextra','-Wpedantic',
 '-I'+str(include),'-I'+str(ROOT/'astra-sim-wscllm/extern/helper'),
 '-c',str(path),'-o',str(DEST/'Execution.cc.o')]
identity={'scope':'mixed relinked isolated causal experiment; not fresh library adoption',
 'base_archive':str(original.relative_to(ROOT)),'base_archive_sha256':sha(original),
 'original_execution_sha256':hashlib.sha256(before.encode()).hexdigest(),
 'candidate_execution_sha256':sha(path),'compile_command':command,
 'source_sha256':{str(p.relative_to(DEST)):sha(p) for p in sorted((DEST/'die').rglob('*')) if p.is_file()}}
(DEST/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
started=time.monotonic();compiled=subprocess.run(command,text=True,capture_output=True,timeout=180)
(DEST/'compile.stdout.log').write_text(compiled.stdout)
(DEST/'compile.stderr.log').write_text(compiled.stderr)
identity['compile_returncode']=compiled.returncode;identity['compile_wall_s']=time.monotonic()-started
if compiled.returncode==0:
 update=['ar','r',str(archive),str(DEST/'Execution.cc.o')]
 subprocess.run(update,check=True,timeout=20)
 identity['archive_update_command']=update
 identity['candidate_archive_sha256']=sha(archive)
 identity['archive_objects_sha256']={}
 for member in subprocess.check_output(['ar','t',str(archive)],text=True).splitlines():
  data=subprocess.check_output(['ar','p',str(archive),member])
  identity['archive_objects_sha256'][member]=hashlib.sha256(data).hexdigest()
identity['base_archive_sha256_after']=sha(original)
(DEST/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
print(json.dumps(identity,indent=2))
raise SystemExit(compiled.returncode)
