# Current actual scope after first causal experiment

- Fresh main baseline and fresh A+B both compile the new synthetic fixture and
  reproduce the exact historical epoch4 deadlock at5130029297ns,18internal events.
  Their11actual public snapshots are byte-identical; all source/library/ELF
  identities are retained. This is current-Core synthetic evidence.
- The mixed relinked **interior-only causal experiment** completes both owners at
  5135048829ns (14public observations,27internal events), correct projected byte/
  Vec totals and no **public-event** credit interval proven out of bounds.
  Public-event observations are not proof of every internal integration.
- The unchanged tiny-credit and service-curve Runtime tests pass the mixed
  candidate. The split-owner regression first failed to link because this scratch
  runner omitted CAPI; the entire failed command/link log is preserved. After
  adding the actual fresh CAPI object it compiles and runs, but fails the final
  outward-boundary fixture assertion: `outward fixture reaches a finite-credit
  boundary`. That fixture waits for diagnostic credit exactly1; retained interior
  credit no longer guarantees that projected wire value. The failure remains a
  failure; no production test or expectation was changed to pass it.
- Global per-row exact accumulated output is262147.999999999999971578B, whereas
  integer projected counters equal262148B and per-activity terminal work is fully
  served. The2.8422e-14B machine summation residual remains disclosed; this is not
  strict integer equality for cumulative long-double accounting.
- Guard widths, terminal progress-close, LP/Q/PRIVATE, physical work, R1 and time
  floor remain unchanged. This candidate does not resolve ordinary-capacity
  positive-slack boundary classification or subepsilon represented advancement,
  is not adopted, and does not establish full Norm/SDK/accuracy/acceptance.

`README.md` starts with the historical preparation-phase account. Its earlier
"not run" words apply only to that phase; actual execution scope is this file.
Every original failed and subsequent corrected scratch command is preserved.

The frozen checkpoint intentionally excludes future/in-progress dyadic and
internal-diagnostic experiments. No binaries/libraries/objects are saved.
