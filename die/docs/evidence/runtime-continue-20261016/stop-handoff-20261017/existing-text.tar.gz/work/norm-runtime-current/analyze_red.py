#!/usr/bin/env python3
"""Reproduce the event7 -> event8 explanation using retained current-Core snapshots."""
from pathlib import Path
from decimal import Decimal, getcontext
import hashlib
import json

getcontext().prec = 80
HERE = Path(__file__).resolve().parent
D = Decimal

def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def inspect(label):
    root = HERE / label
    result = json.loads((root / 'trace/result.json').read_text())
    old = json.loads((HERE / 'norm-seven-epoch-contract.json').read_text())
    output = {'label': label, 'status': result['status'], 'liveness_status': result['liveness_status'],
              'identity_sha256': digest(root / 'identity.json'), 'snapshots': []}
    for n in [7, 8, 9, 10]:
        path = root / f'trace/event-{n:03}.json'
        snapshot = json.loads(path.read_text())
        owner = snapshot['executions'][0]
        a = {a['activity_id']: a for a in owner['activities'] if a['epoch_index'] == 4}
        p = {k: D(v['curve_progress_exact']) for k, v in a.items()}
        rate = {k: D.from_float(v['rate']) for k, v in a.items()}
        credit = [1 + 254*p[13] - 255*p[14], 1 + 254*p[14] - 255*p[15]]
        netrate = [254*rate[13] - 255*rate[14], 254*rate[14] - 255*rate[15]]
        row = {'event': n, 'snapshot_sha256': digest(path), 'now_ns': snapshot['now_ns'],
               'internal_events': snapshot['internal_events'],
               'exact_physical_credit_from_saved_progress': list(map(str, credit)),
               'reported_credit': owner['credit'],
               'net_credit_per_s_from_binary64_rates': list(map(str, netrate)),
               'active_progress': {str(k): v['curve_progress_exact'] for k, v in a.items()},
               'done': {str(k): v['done'] for k, v in a.items()}}
        if n == 7:
            row['extra_output_integration_ns_from_snap_to_capacity'] = str(
                (D(owner['credit'][1]) - credit[1]) / (-netrate[1]) * 10**9)
        if n == 10:
            row['compute_remaining_progress'] = str(1-p[14])
            row['missing_vec_eqops_from_progress'] = str((1-p[14])*326400)
            row['historical_stalled_progress_exactly_equal'] = (
                a[14]['curve_progress_exact'] == old['historical_stall']['activities'][1]['curve_progress_exact'])
        output['snapshots'].append(row)
    return output

report = {'scope': 'actual current-Core manual seven-epoch Runtime runs; no hardware calibration',
          'analysis': [inspect(name) for name in ['run-main-baseline', 'run-combined-ab']]}
report['baseline_ab_snapshots_byte_identical'] = all(
    (HERE / 'run-main-baseline' / f'trace/event-{n:03}.json').read_bytes() ==
    (HERE / 'run-combined-ab' / f'trace/event-{n:03}.json').read_bytes() for n in range(11))
(HERE / 'red-causal-analysis.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
