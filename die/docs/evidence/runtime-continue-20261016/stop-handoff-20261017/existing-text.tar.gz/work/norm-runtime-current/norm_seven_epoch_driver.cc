// New current-Core synthetic fixture. No historical Plan/snapshot is imported.
// Only the seven physical epoch contracts are transcribed from the immutable
// strict-projection log; validate them before submitting two owners at time 0.
#include "test_support.hh"

#include <array>
#include <cmath>
#include <filesystem>
#include <iomanip>
#include <limits>
#include <sstream>
#include <vector>

using namespace coarse_die;
using namespace coarse_die_test;
namespace fs = std::filesystem;
namespace {
constexpr std::uint64_t event_limit = 64;
constexpr std::uint64_t hidden = 65537;
constexpr std::uint64_t expected_vec = 8 * hidden;
constexpr std::uint64_t expected_read = 8 * hidden;
constexpr std::uint64_t expected_write = 4 * hidden;
// Every owner pays 524296 / 204800 = 65537 / 25600 gate seconds.
// Two owners share gate capacity 1; this lower bound is exactly integer ns.
constexpr std::uint64_t finish_lower_bound_ns = 5120078125ULL;
constexpr const char* source_log_sha =
    "0973c32fd6bdf2e891ba5c096cf3b4722440cbf710da8cbc4bfc13eaf64226c6";

std::string decimal(long double x) {
  std::ostringstream out;
  out << std::scientific << std::setprecision(std::numeric_limits<long double>::max_digits10) << x;
  return out.str();
}
void write_json(const fs::path& path, const json& value) {
  std::ofstream out(path);
  require(bool(out), "cannot open output " + path.string());
  out << value.dump(2) << '\n';
  require(bool(out), "cannot write output " + path.string());
}
Activity physical(std::uint64_t id, Role role,
                  std::array<double,resource_count> work,
                  std::array<std::array<std::uint64_t,2>,2> hbm,
                  std::uint64_t vec, double q, double private_s,
                  std::array<double,2> delta) {
  Activity a;
  a.id=id; a.role=role; a.work=work; a.hbm_bytes=hbm; a.vec_eqops=vec;
  a.canonical_q=q; a.private_time_s=private_s; a.credit_delta=delta;
  a.credit_curve={{0,{{0,0}}},{1,delta}};
  return a;
}
Epoch epoch(const std::string& suffix, std::array<double,2> capacity,
            std::array<double,2> initial, std::vector<Activity> activities) {
  Epoch e;
  e.name="norm_two_pass_single_cohort_v1_"+suffix;
  e.credit_capacity=capacity; e.credit_initial=initial;
  e.activities=std::move(activities);
  return e;
}
std::vector<Epoch> physical_epochs() {
  // The four total Cores and one active row are distinct. These are TOTAL
  // activity work/bytes/ops from the logged one-active-Core Plan, never *4.
  const std::array<std::array<std::uint64_t,2>,2> no_hbm{};
  return {
    epoch("statistics_first_input", {{512,1}}, {{0,0}}, {
      physical(1,Role::Load,
        {{0,0,512,0,256,256,0,0,0,256,0,0,768}},
        {{{256,0},{256,0}}},0,512,5.12e-10,{{256,0}})
    }),
    epoch("statistics_stream", {{512,1}}, {{256,0}}, {
      physical(4,Role::Load,
        {{0,0,130562,0,65281,65281,0,0,0,65281,0,0,195843}},
        {{{65281,0},{65281,0}}},0,130562,1.30562e-7,{{65281,0}}),
      physical(5,Role::Compute,
        {{0.9600146484375,393222,262164,655386,0,0,0,0,0,0,0,0,0}},
        no_hbm,196611,655386,0.9600146484375,{{-65537,0}})
    }),
    epoch("apply_first_input", {{2,1}}, {{0,0}}, {
      physical(7,Role::Load,
        {{0,0,1536,0,768,768,0,0,0,768,0,0,2304}},
        {{{768,0},{768,0}}},0,1536,1.536e-9,{{1,0}})
    }),
    epoch("apply_first_output_and_prefetch", {{2,1}}, {{1,0}}, {
      physical(10,Role::Load,
        {{0,0,1536,0,768,768,0,0,0,768,0,0,2304}},
        {{{768,0},{768,0}}},0,1536,1.536e-9,{{1,0}}),
      physical(11,Role::Compute,
        {{0.00625,2576,2048,4624,0,0,0,0,0,0,0,0,0}},
        no_hbm,1280,4624,0.00625,{{-1,0}})
    }),
    epoch("apply_middle_reserved_tail", {{1,1}}, {{1,1}}, {
      physical(13,Role::Load,
        {{0,0,390150,0,195075,195075,0,0,0,195075,0,0,585225}},
        {{{195075,0},{195075,0}}},0,390150,3.9015e-7,{{254,0}}),
      physical(14,Role::Compute,
        {{1.59375,652800,522240,1175040,0,0,0,0,0,0,0,0,0}},
        no_hbm,326400,1175040,1.59375,{{-255,254}}),
      physical(15,Role::Store,
        {{0,261120,0,0,130560,130560,0,0,130560,0,0,0,391680}},
        {{{0,130560},{0,130560}}},0,261120,2.6112e-7,{{0,-255}})
    }),
    epoch("apply_last_compute_and_penultimate_store", {{1,1}}, {{1,1}}, {
      physical(16,Role::Compute,
        {{2.44140625e-5,10,8,18,0,0,0,0,0,0,0,0,0}},
        no_hbm,5,18,2.44140625e-5,{{-1,0}}),
      physical(17,Role::Store,
        {{0,1024,0,0,512,512,0,0,512,0,0,0,1536}},
        {{{0,512},{0,512}}},0,1024,1.024e-9,{{0,-1}})
    }),
    epoch("apply_last_store", {{1,1}}, {{0,1}}, {
      physical(19,Role::Store,
        {{0,4,0,0,2,2,0,0,2,0,0,0,6}},
        {{{0,2},{0,2}}},0,4,4e-12,{{0,-1}})
    })
  };
}
Hardware synthetic_hardware(const json& config, const json& contract,
                            std::string& resolved_fingerprint) {
  auto input=config;
  require(!input.at("architecture").contains("core_type"),
          "current fixture must not inject or silently remove retired selectors");
  auto& arch=input["architecture"];
  arch["core_columns_nx"]=4; arch["core_rows_ny"]=1;
  // Explicit current descriptor, including its required outline. The outline
  // is fixed fixture input, not an inferred/optimized hardware configuration.
  arch["die_width_mm"]=21; arch["die_height_mm"]=29;
  auto& profile=input["performance_profile"];
  profile["eta_vec"]=1; profile["eta_hbm_vector"]=1;
  profile["launch_ns_per_macro"]=0; profile["memory_setup_ns_per_macro"]=0;
  auto hw=resolve_hardware(input);
  resolved_fingerprint=hw.fingerprint;
  const std::array<double,resource_count> rates{{
      1,4e12,4e12,4e12,204800,204800,0,0,4e12,4e12,0,0,4e12}};
  require(json(rates)==contract.at("synthetic_rates"), "logged synthetic capacities match");
  for(std::size_t r=0;r<resource_count;++r) {
    require(hw.derived.at("resources").at(r).at("enabled").get<bool>() || rates[r]==0,
            "synthetic fixture cannot enable a hardware-disabled domain");
    hw.rates[r]=rates[r]; hw.derived["resources"][r]["rate"]=rates[r];
  }
  hw.derived["core"]["P_vec_per_core_ops_per_s"]=204800;
  hw.fingerprint="synthetic_core32_norm_seven_epoch_v1:"+stable_hash(json{
      {"current_resolved_hardware_fingerprint",resolved_fingerprint},
      {"synthetic_rates",rates},{"synthetic_vec_peak_per_core",204800},
      {"numeric_contract_source_sha256",source_log_sha}}.dump());
  return hw;
}
std::shared_ptr<const Plan> make_plan(const Hardware& hw,const json& contract) {
  auto p=std::make_shared<Plan>();
  p->hardware_fingerprint=hw.fingerprint; p->epochs=physical_epochs();
  p->task={{"fixture","synthetic_current_core32_norm_seven_epoch_v1"},
           {"hidden",hidden},{"rows",1},{"total_cores",4},{"active_cores",1},
           {"roles",{{"input","bf16"},{"parameters","fp32"},{"output","fp32"}}}};
  p->summary={{"status","synthetic_runtime_only_fixture"},
              {"source_log_sha256",source_log_sha},{"hbm_workspace_peak_bytes",0},
              {"active_cores",1},{"total_cores",4},
              {"original_busy_definition_retained",true}};
  const auto wire=plan_to_json(*p);
  require(wire.at("epochs")==contract.at("epochs"),
          "manual seven-epoch Q/PRIVATE/work/bytes/credit/curve contract is verbatim");
  require(service_description_count(*p)==12,
          "all predecessor history is fixed seven epochs / twelve descriptions");
  p->fingerprint=wire.at("fingerprint").get<std::string>();
  require(p->fingerprint!=contract.at("source").at("historical_plan_fingerprint"),
          "new Plan has new canonical current-hardware identity");
  std::uint64_t read=0,write=0,vec=0;
  long double sram_read=0,sram_write=0,local=0;
  for(const auto& e:p->epochs) {
    require(e.repeat_count==1 && e.activities.size()<=3,"fixed R1, at most three activities");
    for(const auto& a:e.activities) {
      vec+=a.vec_eqops;
      for(const auto& row:a.hbm_bytes) { read+=row[0];write+=row[1]; }
      sram_read+=a.work[SRAM_READ];sram_write+=a.work[SRAM_WRITE];local+=a.work[LOCAL];
      require(a.canonical_q==canonical_basis(a),"physical normalization Q stays canonical");
    }
  }
  require(read==expected_read && write==expected_write && vec==expected_vec,
          "independent two-X-visits + one gamma + one output and 8H Vec ledger");
  require(sram_read==20*hidden+16 && sram_write==20*hidden+16 && local==28*hidden+32,
          "independent physical conversion/statistics SRAM and LOCAL totals");
  return p;
}

// Outward-rounded evaluation of the exact affine credit of REPRESENTED progress.
// This is observation only, never an epsilon, clamp or change to Runtime state.
// A strict enclosure wholly outside [0,capacity] is recorded as a physical red.
struct Interval { long double lo,hi; };
long double down(long double x) { return std::nextafter(x,-std::numeric_limits<long double>::infinity()); }
long double up(long double x) { return std::nextafter(x,std::numeric_limits<long double>::infinity()); }
Interval add(Interval a,Interval b) { return {down(a.lo+b.lo),up(a.hi+b.hi)}; }
Interval product(long double a,long double b) {
  const long double x=a*b;
  return {down(x),up(x)};
}
json credit_ledgers(const Plan& p,const json& snapshot,unsigned& violations) {
  json result=json::array();
  for(const auto& execution:snapshot.at("executions")) {
    const auto ei=execution.at("epoch_index").get<std::size_t>();
    if(execution.at("terminal").get<bool>() || ei>=p.epochs.size())continue;
    const auto& epoch=p.epochs[ei];
    json channels=json::array();
    for(unsigned channel=0;channel<2;++channel) {
      Interval value{epoch.credit_initial[channel],epoch.credit_initial[channel]};
      for(const auto& a:epoch.activities) {
        for(const auto& live:execution.at("activities")) {
          if(live.at("activity_id")==a.id) {
            const auto progress=std::stold(live.at("curve_progress_exact").get<std::string>());
            value=add(value,product(static_cast<long double>(a.credit_delta[channel]),progress));
          }
        }
      }
      const long double capacity=epoch.credit_capacity[channel];
      const bool outside=value.hi<0 || value.lo>capacity;
      if(outside)++violations;
      channels.push_back({{"channel",channel},{"lower",decimal(value.lo)},
                          {"upper",decimal(value.hi)},{"capacity",epoch.credit_capacity[channel]},
                          {"reported_credit",execution.at("credit").at(channel)},
                          {"proven_outside_capacity",outside}});
    }
    result.push_back({{"handle",execution.at("handle")},{"epoch",ei},{"channels",channels}});
  }
  return result;
}
void observe(const fs::path& directory,unsigned event,const Runtime& runtime,
             const Plan& plan,const std::vector<std::uint64_t>& handles,json& result) {
  const auto snapshot=runtime.export_snapshot();
  std::ostringstream filename;
  filename << "event-" << std::setw(3) << std::setfill('0') << event << ".json";
  write_json(directory/filename.str(),snapshot);
  const auto next=runtime.next_event();
  unsigned violations=0;
  json item={{"event",event},{"now_ns",runtime.now_ns()},
             {"next_event_ns",next?json(*next):json(nullptr)},
             {"drained",runtime.drained()},{"snapshot_file",filename.str()},
             {"counters",runtime.counters()},
             {"credit_ledgers",credit_ledgers(plan,snapshot,violations)},
             {"queries",json::array()}};
  for(auto h:handles)item["queries"].push_back(runtime.query_progress(h));
  result["credit_ledger_violation_observations"]=
      result.at("credit_ledger_violation_observations").get<unsigned>()+violations;
  result["observations"].push_back(std::move(item));
  // Keep every completed event recoverable even if a later advance throws.
  write_json(directory/"result.json",result);
}
}
int main(int argc,char** argv) {
  if(argc!=5) {
    std::cerr << "usage: norm_seven_epoch_driver CURRENT_CONFIG NUMERIC_CONTRACT OUTPUT_DIR LABEL\n";
    return 2;
  }
  const fs::path directory=argv[3];
  fs::create_directories(directory);
  json result={{"label",argv[4]},{"status","initializing"},
               {"scope","current-Core synthetic Runtime-only, no hardware calibration"},
               {"liveness_status","not_started"},{"physical_totals_status","not_checked"},
               {"event_limit",event_limit},{"credit_ledger_violation_observations",0},
               {"finish_lower_bound_ns",finish_lower_bound_ns},
               {"per_owner_expected_vec",expected_vec},
               {"per_owner_expected_hbm_read",expected_read},
               {"per_owner_expected_hbm_write",expected_write},
               {"observations",json::array()}};
  std::unique_ptr<Runtime> runtime;
  std::shared_ptr<const Plan> plan;
  std::vector<std::uint64_t> handles;
  try {
    const auto contract=read_json(argv[2]);
    require(contract.at("source").at("member_sha256")==source_log_sha,"numeric contract source identity");
    std::string resolved_fingerprint;
    auto hw=synthetic_hardware(read_json(argv[1]),contract,resolved_fingerprint);
    plan=make_plan(hw,contract);
    write_json(directory/"hardware-input.json",hw.input);
    write_json(directory/"hardware-derived-synthetic.json",hw.derived);
    write_json(directory/"plan.json",plan_to_json(*plan));
    result["current_resolved_hardware_fingerprint"]=resolved_fingerprint;
    result["synthetic_hardware_fingerprint"]=hw.fingerprint;
    result["new_plan_fingerprint"]=plan->fingerprint;
    result["numeric_provenance"]=contract.at("source");
    result["synthetic_rates"]=hw.rates;
    runtime=std::make_unique<Runtime>(hw);
    handles.push_back(runtime->submit(plan,owner(1,1,1),0));
    handles.push_back(runtime->submit(plan,owner(2,2,2),0));
    result["status"]="running";
    result["liveness_status"]="running";
    observe(directory,0,*runtime,*plan,handles,result);
    unsigned event=0;
    while(!runtime->drained()) {
      const auto next=runtime->next_event();
      if(!next)result["liveness_status"]="stalled_no_event";
      require(next.has_value(),"nonterminal two-owner Plan has no next event");
      if(event>=event_limit)result["liveness_status"]="event_limit";
      require(event<event_limit,"finite event limit exceeded");
      if(*next<=runtime->now_ns())result["liveness_status"]="nonadvancing_event";
      require(*next>runtime->now_ns(),"next public event must advance represented time");
      runtime->advance_to(*next);
      observe(directory,++event,*runtime,*plan,handles,result);
    }
    result["liveness_status"]="completed";
    for(auto h:handles) {
      const auto q=runtime->query_progress(h);
      require(q.at("served").at("vec_eqops")==expected_vec,"all 8H Vec operations are paid");
      require(q.at("served").at("int4_ops")==0,"Norm does not mint matrix service");
      for(unsigned row=0;row<2;++row) {
        require(q.at("served").at("hbm_bytes_by_row_direction").at(row).at(0)==expected_read/2,
                "each physical HBM row pays all input and gamma bytes");
        require(q.at("served").at("hbm_bytes_by_row_direction").at(row).at(1)==expected_write/2,
                "each physical HBM row pays all output bytes");
      }
      for(const auto& live:q.at("activities"))require(live.at("done").get<bool>(),"no unpaid activity closes the Plan");
      require(runtime->terminal_finish_ns(h).value()>=finish_lower_bound_ns,
              "two owners cannot finish earlier than shared physical gate work");
    }
    result["physical_totals_status"]="passed";
    require(result.at("credit_ledger_violation_observations")==0,
            "represented affine credit crossed its exact closed physical capacity");
    result["status"]="passed";
  } catch(const std::exception& error) {
    result["status"]="failed"; result["error"]=error.what();
    if(runtime) {
      write_json(directory/"failure-snapshot.json",runtime->export_snapshot());
      result["failure_counters"]=runtime->counters();
    }
  }
  if(runtime)result["runtime_drained"]=runtime->drained();
  write_json(directory/"result.json",result);
  std::cout << json{{"status",result.at("status")},{"label",argv[4]},
                    {"liveness_status",result.at("liveness_status")},
                    {"observations",result.at("observations").size()},
                    {"credit_ledger_violation_observations",result.at("credit_ledger_violation_observations")},
                    {"error",result.value("error","")}}.dump() << '\n';
  return result.at("status")=="passed"?0:1;
}
