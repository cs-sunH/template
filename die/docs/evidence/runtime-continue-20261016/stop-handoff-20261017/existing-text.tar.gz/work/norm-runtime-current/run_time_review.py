#!/usr/bin/env python3
from pathlib import Path
import argparse,hashlib,json,subprocess,time
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--label',required=True);parser.add_argument('--libraries',nargs='+',required=True)
 a=parser.parse_args();dest=HERE/('time-review-'+a.label);dest.mkdir(exist_ok=False)
 source=HERE/'time_only_review_driver.cc';obj=dest/'time_only_review_driver.o'
 compile_cmd=['c++','-std=c++17','-O2','-Wall','-Wextra','-Wpedantic','-I'+str(ROOT/'die/include'),
  '-I'+str(ROOT/'die/tests'),'-I'+str(ROOT/'astra-sim-wscllm/extern/helper'),
  '-DCOARSE_DIE_SOURCE_DIR="'+str(ROOT/'die')+'"','-DCOARSE_DIE_ROOT_DIR="'+str(ROOT)+'"',
  '-c',str(source),'-o',str(obj)]
 report={'scope':'independent current-Core time-only review controls; no hardware calibration',
  'source_sha256':sha(source),'runner_sha256':sha(Path(__file__)),'compile_command':compile_cmd,'libraries':[]}
 c=subprocess.run(compile_cmd,text=True,capture_output=True,cwd=ROOT,timeout=180)
 (dest/'compile.stdout.log').write_text(c.stdout);(dest/'compile.stderr.log').write_text(c.stderr)
 report['compile_returncode']=c.returncode
 if c.returncode:
  (dest/'identity.json').write_text(json.dumps(report,indent=2)+'\n');return 2
 report['object_sha256']=sha(obj)
 for item in a.libraries:
  label,path=item.split('=',1);archive=(ROOT/path).resolve();exe=dest/(label+'-driver')
  command=['c++',str(obj),str(archive),'-o',str(exe)]
  row={'label':label,'archive':str(archive),'archive_sha256':sha(archive),'link_command':command};report['libraries'].append(row)
  c=subprocess.run(command,text=True,capture_output=True,cwd=ROOT,timeout=60)
  (dest/(label+'.link.stdout.log')).write_text(c.stdout);(dest/(label+'.link.stderr.log')).write_text(c.stderr)
  row['link_returncode']=c.returncode
  if c.returncode==0:
   row['executable_sha256']=sha(exe);command=[str(exe),str(dest/label),label];row['run_command']=command
   try:
    c=subprocess.run(command,text=True,capture_output=True,cwd=ROOT,timeout=30)
    (dest/(label+'.run.stdout.log')).write_text(c.stdout);(dest/(label+'.run.stderr.log')).write_text(c.stderr)
    row['returncode']=c.returncode;row['status']='passed' if c.returncode==0 else 'failed'
   except subprocess.TimeoutExpired:row['status']='timeout'
  else:row['status']='link_failed'
  row['archive_sha256_after']=sha(archive)
  (dest/'identity.json').write_text(json.dumps(report,indent=2)+'\n')
 report['outputs_sha256']={str(p.relative_to(dest)):sha(p) for p in sorted(dest.rglob('*')) if p.is_file() and p.name!='identity.json' and p.suffix in ['.json','.log']}
 (dest/'identity.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps(report,indent=2));return 0
if __name__=='__main__':raise SystemExit(main())
