# Current-Core synthetic seven-epoch Runtime reproducer preparation

Prepared source only: **C++ compilation and Runtime execution have not run**.
All scratch edits are confined to `work/norm-runtime-current/`. No production
mapping/numerical implementation or old evidence was changed.

The physical source is the immutable pre-Core archive
`die/docs/analysis/pre-core-migration-20261016/unadopted-artifacts.tar.gz`:

- archive SHA256 `975e7a574f3a6ce322f340f2824c4ce12ebcaa35b0879d67e8d5612f0dee589e`
- member `work/norm-review/runtime-archive-20261016/strict-projection.stderr.log`
- member SHA256 `0973c32fd6bdf2e891ba5c096cf3b4722440cbf710da8cbc4bfc13eaf64226c6`

`prepare_contract.py` verifies the archive and all three extracted members
against the outer manifest. It extracts only the numeric physical seven-epoch
contract; the historical stalled Runtime state is **never imported**. The two
historical owners have equal Plan objects. Their physical contract is 7 epochs,
12 activities, R1, at most 3 activities per epoch, and zero startup.

The logged identity is historical `synthetic-norm-long-mixed:ffdea7...`, with
historical Plan `8f53ac7...`. It is **not** the differently named
`synthetic-long-row-credit-liveness:...` fixture identity in archived
`die/tests/norm_long_row_test.cc:synchronous_long_row_credit_liveness`.
Both point to the RMS65537 / m1 / BF16-input / FP32-parameter / FP32-output /
204800 synthetic service contract. The reproducer uses the complete **logged**
Plan numbers without inferring unlogged geometry or rebinding old fingerprints.

`norm_seven_epoch_driver.cc` manually constructs the 12 physical activities and
compares every epoch field with the extracted contract through canonical Plan
serialization. It resolves the **current** Core32 descriptor with explicit
4x1 total Cores and 21x29mm outline (one actual active Core for m1), preserves
hardware-enabled domains, then declares synthetic Vec204800/Core, COMPUTE_GATE1,
HBM row204800B/s and other enabled historical rates4e12. The new hardware identity
includes the current resolved fingerprint, changed rates, Vec override and source
hash. A new synthetic task/summary yields a new canonical Plan fingerprint.
No old hardware identity, compiled Norm builder, or historical state is reused.

Independent per-owner physical totals are:

- Vec = `8H = 524296` eqops
- HBM read = `2*(2H) + 4H = 524296B`; write = `4H = 262148B`
- each HBM row read262148/write131074B
- SRAM read/write each `20H+16 = 1310756B`
- LOCAL = `28H+32 = 1835068B`
- two owners share `2*(524296/204800)s` gate work, so neither terminal may
  precede5120078125ns (the separate historical test used the looser5.12s bound).

Both distinct owners are submitted at time0. The finite64-public-event guard,
strictly advancing public clock check and30s process timeout keep the diagnostic
bounded. Every completed public event saves an actual unmodified Runtime
snapshot, complete queries, original busy/served counters, next event and an
outward-rounded affine credit interval evaluated from the saved exact represented
progress. The independent interval diagnostic never changes Runtime state,
allocations or tolerance. Certain inventory/capacity crossings are retained and
classified separately from liveness, not erased by snapping. This enclosure is
for the represented affine contract; it is not a new production numerical proof.

The process exits nonzero on a liveness failure, unpaid physical totals, impossible
finish, or certain physical credit violation. A passing full-history result must
be retained as passing; it cannot establish that the old full Norm compiler now
works. Next dependency would be isolated adaptation of the actual current-guarded
long-row builder, not changing the constants or importing the historical stalled
snapshot.

## Reproduction after the parent's build/performance lock is released

Run serially; each label requires a new directory. Do not run these commands
until the parent explicitly releases the no-compilation/no-experiment lock.

```sh
python3 work/norm-runtime-current/prepare_contract.py
python3 work/norm-runtime-current/run_probe.py \
  --library work/build-runtime-ab-release/libcoarse_die.a \
  --compiled-source-root die \
  --label current-ab
```

For the unchanged baseline, pass its independently frozen, freshly built static
archive and exact source root with a separate label. `run_probe.py` records actual
archive and object SHA256, fixture/config/header hashes, compiler/version,
commands, executable SHA and every trace output SHA. Its source-root mapping is a
caller claim and must be bound to the parent build recorder; a library filename
alone is not evidence of the compiled source. Neither result is current-Core
hardware calibration, SDK publication, full Norm accuracy, or engineering
acceptance.
