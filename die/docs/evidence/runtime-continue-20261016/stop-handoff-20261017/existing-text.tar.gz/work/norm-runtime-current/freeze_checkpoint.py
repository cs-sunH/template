#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,shutil
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
DEST=HERE/'checkpoint-1';DEST.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths=[]
for name in ['prepare_contract.py','run_probe.py','norm_seven_epoch_driver.cc','norm-seven-epoch-contract.json',
 'extraction.json','analyze_red.py','red-causal-analysis.json','red-causal-analysis.stdout.log',
 'RED-DIAGNOSIS.md','README.md','CHECKPOINT-STATUS.md','terminal-ledger-projection.json',
 'parent-build-source-bindings.json','build_interior_candidate.py','build-interior.stdout.log',
 'run_focused_relinked.py','run_focused_relinked_attempt1.py','focused-interior.stdout.log',
 'focused-split-capi.stdout.log','freeze_checkpoint.py']:
 paths.append(HERE/name)
for name in ['run-main-baseline','run-combined-ab','run-interior-only','candidate-interior-only',
 'focused-interior-only','focused-interior-only-split-capi']:
 paths.extend(p for p in (HERE/name).rglob('*') if p.is_file())
paths.extend(ROOT/x for x in ['die/tests/runtime_subunit_credit_test.cc','die/tests/runtime_snapshot_split_owner_test.cc',
 'die/tests/service_curve_runtime_test.cc','die/tests/test_support.hh','die/tests/fixtures/snapshot_split_owner.json',
 'work/runtime-continue/baseline-build.json','work/runtime-continue/build.json','work/runtime-continue/baseline-source.json'])
rows=[]
for path in sorted(set(paths)):
 if path.suffix in ['.a','.o','.so','.pyc'] or not path.suffix:continue
 assert path.suffix in ['.json','.log','.py','.cc','.hh','.h','.md','.patch']
 relative=path.relative_to(ROOT);dest=DEST/relative;dest.parent.mkdir(parents=True,exist_ok=True)
 shutil.copy2(path,dest)
 assert sha(dest)==sha(path)
 rows.append({'original_path':str(relative),'saved_path':str(dest.relative_to(DEST)),
              'original_sha256':sha(path),'saved_sha256':sha(dest),'bytes':dest.stat().st_size})
manifest={'status':'frozen_completed_checkpoint_no_binaries','scope':'current-Core synthetic red and incomplete mixed relink causal experiment; no adoption',
 'files':rows,'excluded':['ELF','objects','archives','shared libraries','future/in-progress dyadic and internal diagnostic experiments']}
(DEST/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'files':len(rows),'bytes':sum(r['bytes'] for r in rows),'manifest_sha256':sha(DEST/'manifest.json')},indent=2))
