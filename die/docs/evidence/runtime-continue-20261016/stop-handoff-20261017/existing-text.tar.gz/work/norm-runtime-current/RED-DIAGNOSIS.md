# Actual current-Core red and minimal numerical dependency

Both fresh libraries compiled and ran the new manual fixture successfully as a
tool, then **failed Runtime liveness**. Main and A+B produced byte-identical eleven
event snapshots, with18internal events and no next event at5130029297ns. Their
actual source/library/executable identities and failed results remain separate.

The old complete Norm builder was not restored, and no old snapshot was imported.
The new current-Core synthetic seven-epoch Plan starts two distinct owners at0.
Its Compute14 exact stalled progress9.999999999997531472231e-01 equals the
historical log. Load13/Store15 are done; both owners reportcredit[0,0],rate0.
This is a current-source red, not merely historical evidence.

## First illegal step occurs before terminal closure

`python3 work/norm-runtime-current/analyze_red.py` regenerates the exact Decimal
analysis from saved progress strings and exact binary64 rate inputs. Outputs are
`red-causal-analysis.json` and the retained stdout log.

At event7, now1942529297ns, the Runtime has entered epoch4 and integrated the
remaining0.125ns of that public tick. The real represented affine inventory is:

- input0.99999999998418474678241585935735
- output0.99999999993729175326154077330025

`recompute_credit` replaces both withcapacity1 under the unchanged2e-10 guard.
The next output event therefore uses1 instead of the smaller physical inventory.
The extra integration is0.124999999551164365ns, computed from the actual outgoing
netrate−0.501665975708998346/s. Event8 already has physical output
−6.27082349642e-11 while Compute progress is only0.625367287254901952. Near-terminal
closure cannot explain the first crossing: none of the three is near1 yet.

Tangential output rate after event8 is about+6.38378e-15units/s, so it does not
repay that negative inventory before terminal service. At event10, Store reaches1
while Compute is still2.468527769e-13from1. The endpoint validation tolerates the
negative output (about−6.27006053326e-11), and positive input6.29474581095e-11 is
snapped0. The singleton boundary classifier then blocks the remaining Compute.
Its unpaid Vec amount is8.057273238016e-8eqops. Expanding progress-close or gifting
this work would hide the physical cause and is excluded.

## Minimal direction and controlled first experiment

The physical credit used for inventory, tangent classification and event timing
must be consistent and retain real positive inventory/headroom. Diagnostic wire
snapping cannot create/free physical inventory. Near-zero arithmetic uncertainty
needs a proven enclosure of the actual affine evaluation, not a larger model
capacity/progress epsilon. Every positive physical event needs either represented
clock/progress advancement or a bounded simultaneous-boundary treatment; merely
removing the1e-15ns filter can create a loop or violate capacity.

The first isolated causal experiment will change **only** interior snapping for
curved epochs: keep strictly interior physical credit instead of replacing it by
zero/capacity. Legacy trajectories, guard widths, curve/work coefficients, solver,
PRIVATE/Q, terminal-close threshold and time floor stay unchanged. This deliberately
incomplete experiment tests whether upper snapping alone explains the first
crossing; it is not asserted safe or proposed for production adoption. The same
independent physical interval guard and finite-event/process limits remain. Any
residual lower-boundary/subepsilon/physical failure will be retained.
