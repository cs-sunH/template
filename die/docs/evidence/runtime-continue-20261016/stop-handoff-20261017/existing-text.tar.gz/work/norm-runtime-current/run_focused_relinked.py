#!/usr/bin/env python3
from pathlib import Path
import argparse,hashlib,json,subprocess,time
ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 p=argparse.ArgumentParser();p.add_argument('--library',type=Path,required=True);p.add_argument('--label',required=True)
 p.add_argument('--capi-object',type=Path)
 p.add_argument('--tests',nargs='+',default=['runtime_subunit_credit_test','runtime_snapshot_split_owner_test','service_curve_runtime_test'])
 a=p.parse_args();archive=a.library.resolve();dest=HERE/('focused-'+a.label);dest.mkdir(exist_ok=False)
 report={'scope':'actual focused tests linked to isolated mixed experimental archive; no fresh adoption',
         'archive':str(archive),'archive_sha256':sha(archive),'runner_sha256':sha(Path(__file__)), 'tests':[]}
 if a.capi_object:
  report['capi_object']=str(a.capi_object.resolve());report['capi_object_sha256']=sha(a.capi_object.resolve())
 for name in a.tests:
  source=ROOT/'die/tests'/(name+'.cc');executable=dest/name
  command=['c++','-std=c++17','-O2','-Wall','-Wextra','-Wpedantic','-I'+str(ROOT/'die/include'),
           '-I'+str(ROOT/'die/tests'),'-I'+str(ROOT/'astra-sim-wscllm/extern/helper'),
           '-DCOARSE_DIE_SOURCE_DIR="'+str(ROOT/'die')+'"','-DCOARSE_DIE_ROOT_DIR="'+str(ROOT)+'"',
           str(source)]+([str(a.capi_object.resolve())] if a.capi_object else [])+[str(archive),'-o',str(executable)]
  row={'name':name,'source_sha256':sha(source),'command':command};report['tests'].append(row)
  compiled=subprocess.run(command,cwd=ROOT,text=True,capture_output=True,timeout=180)
  (dest/(name+'.compile.stdout.log')).write_text(compiled.stdout);(dest/(name+'.compile.stderr.log')).write_text(compiled.stderr)
  row['compile_returncode']=compiled.returncode
  if compiled.returncode==0:
   row['executable_sha256']=sha(executable)
   try:
    actual=subprocess.run([str(executable)],cwd=ROOT,text=True,capture_output=True,timeout=30)
    (dest/(name+'.stdout.log')).write_text(actual.stdout);(dest/(name+'.stderr.log')).write_text(actual.stderr)
    row['returncode']=actual.returncode;row['status']='passed' if actual.returncode==0 else 'failed'
   except subprocess.TimeoutExpired:
    row['status']='timeout'
  else:row['status']='compile_failed'
  (dest/'report.json').write_text(json.dumps(report,indent=2)+'\n')
 report['archive_sha256_after']=sha(archive)
 report['outputs_sha256']={str(x.relative_to(dest)):sha(x) for x in sorted(dest.glob('*.log'))}
 (dest/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
 return 0 if all(t['status']=='passed' for t in report['tests']) else 1
if __name__=='__main__':raise SystemExit(main())
