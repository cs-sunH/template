#!/usr/bin/env python3
"""Serial compile + bounded real run; use only after parent releases build/perf lock."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import subprocess
import time

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write(path, data):
    path.write_text(json.dumps(data, indent=2) + '\n')

def capture(command, **kw):
    return subprocess.run(command, text=True, capture_output=True, cwd=ROOT, **kw)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--library', required=True, type=Path)
    parser.add_argument('--label', required=True)
    parser.add_argument('--compiled-source-root', type=Path,
                        help='Caller-identified exact library source root; hashes recorded as a claim, not inferred from ELF')
    parser.add_argument('--cxx', default=os.environ.get('CXX', 'c++'))
    args = parser.parse_args()
    assert args.label and all(c.isalnum() or c in '-_' for c in args.label)
    library = args.library.resolve()
    assert library.is_file(), library
    destination = HERE / ('run-' + args.label)
    destination.mkdir(exist_ok=False)
    source = HERE / 'norm_seven_epoch_driver.cc'
    executable = destination / 'norm_seven_epoch_driver'
    contract = HERE / 'norm-seven-epoch-contract.json'
    config = ROOT / 'die/configs/example_hardware.json'
    command = [args.cxx, '-std=c++17', '-O2', '-Wall', '-Wextra', '-Wpedantic',
               '-I' + str(ROOT / 'die/include'), '-I' + str(ROOT / 'die/tests'),
               '-I' + str(ROOT / 'astra-sim-wscllm/extern/helper'),
               '-DCOARSE_DIE_SOURCE_DIR="' + str(ROOT / 'die') + '"',
               '-DCOARSE_DIE_ROOT_DIR="' + str(ROOT) + '"',
               str(source), str(library), '-o', str(executable)]
    source_root = args.compiled_source_root.resolve() if args.compiled_source_root else None
    source_files = list(source_root.rglob('*.cc')) + list(source_root.rglob('*.hh')) if source_root else []
    # Archive identity is independent of workspace source claims. Record actual
    # object bytes too; never infer a source revision solely from a library name.
    members = capture(['ar', 't', str(library)], timeout=20)
    assert members.returncode == 0, members.stderr
    object_sha = {}
    for member in members.stdout.splitlines():
        data = subprocess.check_output(['ar', 'p', str(library), member], cwd=ROOT, timeout=20)
        object_sha[member] = hashlib.sha256(data).hexdigest()
    identity = {
        'status': 'prepared', 'label': args.label, 'compile_command': command,
        'driver_sha256': sha(source), 'numeric_contract_sha256': sha(contract),
        'prepare_script_sha256': sha(HERE / 'prepare_contract.py'),
        'runner_sha256': sha(Path(__file__)), 'hardware_config_sha256': sha(config),
        'static_library': str(library), 'static_library_sha256': sha(library),
        'archive_object_sha256': object_sha,
        'caller_identified_compiled_source_root': str(source_root) if source_root else None,
        'caller_identified_compiled_source_sha256': {str(p.relative_to(source_root)): sha(p) for p in sorted(source_files)},
        'workspace_head_at_start': capture(['git', 'rev-parse', 'HEAD'], timeout=20).stdout.strip(),
        'workspace_status_at_start': capture(['git', 'status', '--short'], timeout=20).stdout,
        'compiler_version': capture([args.cxx, '--version'], timeout=20).stdout,
        'compiled_current_headers_sha256': {str(p.relative_to(ROOT)): sha(p) for p in
            sorted((ROOT / 'die/include').rglob('*.hh')) + [ROOT / 'die/tests/test_support.hh']},
        'source_identity_scope': 'Archive/object hashes are actual; source-root mapping is caller-supplied and must match the parent build recorder.',
        'timeouts_s': {'compile': 180, 'run': 30},
    }
    write(destination / 'identity.json', identity)
    started = time.monotonic()
    try:
        compiled = capture(command, timeout=180)
        (destination / 'compile.stdout.log').write_text(compiled.stdout)
        (destination / 'compile.stderr.log').write_text(compiled.stderr)
        identity['compile_returncode'] = compiled.returncode
        identity['compile_wall_s'] = time.monotonic() - started
        if compiled.returncode:
            identity['status'] = 'compile_failed'
            return 1
        identity['executable_sha256'] = sha(executable)
        run_command = [str(executable), str(config), str(contract), str(destination / 'trace'), args.label]
        identity['run_command'] = run_command
        identity['status'] = 'running'
        write(destination / 'identity.json', identity)
        started = time.monotonic()
        actual = capture(run_command, timeout=30)
        (destination / 'run.stdout.log').write_text(actual.stdout)
        (destination / 'run.stderr.log').write_text(actual.stderr)
        identity['run_returncode'] = actual.returncode
        identity['run_wall_s'] = time.monotonic() - started
        identity['status'] = 'executed'
        result = destination / 'trace/result.json'
        if result.exists():
            raw = json.loads(result.read_text())
            identity['driver_status'] = raw['status']
            identity['liveness_status'] = raw['liveness_status']
            identity['credit_ledger_violation_observations'] = raw['credit_ledger_violation_observations']
        return 0 if actual.returncode == 0 else 1
    except subprocess.TimeoutExpired as error:
        identity['status'] = 'timeout'
        identity['timeout_command'] = error.cmd
        identity['timeout_s'] = error.timeout
        identity['timeout_partial_stdout'] = (error.stdout or b'').decode(errors='replace') if isinstance(error.stdout, bytes) else error.stdout
        identity['timeout_partial_stderr'] = (error.stderr or b'').decode(errors='replace') if isinstance(error.stderr, bytes) else error.stderr
        return 1
    finally:
        identity['static_library_sha256_after'] = sha(library)
        identity['static_library_unchanged'] = identity['static_library_sha256_after'] == identity['static_library_sha256']
        identity['outputs_sha256'] = {str(p.relative_to(destination)): sha(p) for p in sorted(destination.rglob('*'))
                                      if p.is_file() and p.name != 'identity.json' and p != executable}
        write(destination / 'identity.json', identity)
        print(json.dumps({'label': args.label, 'status': identity['status'],
                          'liveness_status': identity.get('liveness_status'),
                          'driver_status': identity.get('driver_status'),
                          'result_directory': str(destination.relative_to(ROOT))}, indent=2))

if __name__ == '__main__':
    raise SystemExit(main())
