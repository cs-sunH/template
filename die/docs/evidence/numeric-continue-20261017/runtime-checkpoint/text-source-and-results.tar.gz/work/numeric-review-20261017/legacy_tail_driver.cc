#include "test_support.hh"
#include <filesystem>
using namespace coarse_die;using namespace coarse_die_test;
int main(int argc,char**argv) {
 if(argc!=3)return 2;namespace fs=std::filesystem;fs::create_directories(argv[1]);
 std::array<double,resource_count> rates{};rates[COMPUTE_GATE]=1;
 auto hw=manual_hardware(rates);hw.fingerprint="synthetic_current_core_legacy_tail_review:"+stable_hash(json(rates).dump());
 Epoch e;e.name="pure_legacy_positive_tail";const double seconds=std::nextafter(1e-9,std::numeric_limits<double>::infinity());
 auto a=activity(1,Role::Compute,COMPUTE_GATE,seconds);a.private_time_s=seconds;a.canonical_q=1;a.vec_eqops=1000000000000ULL;e.activities={a};
 Runtime r(hw);json report={{"label",argv[2]},{"scope","independent synthetic pure legacy target boundary control"}};
 try {
  auto h=r.submit(manual_plan(hw,{e},"legacy_positive_tail"),owner(1,1,1),0);report["before"]=r.export_snapshot();
  r.advance_to(1);report["at_one"]=r.export_snapshot();report["query_at_one"]=r.query_progress(h);
  const bool live=!r.drained();bool imported=false;std::string import_error;
  try {auto fork=Runtime::import_snapshot(hw,r.export_snapshot());imported=true;}catch(const std::exception& ex){import_error=ex.what();}
  report["snapshot_reimported_at_one"]=imported;report["snapshot_import_error"]=import_error;
  r.advance_to(2);report["at_two"]=r.export_snapshot();report["query_at_two"]=r.query_progress(h);
  report["passed"]=live&&imported&&r.terminal_finish_ns(h)==2;
 }catch(const std::exception& ex){report["error"]=ex.what();report["passed"]=false;report["after"]=r.export_snapshot();}
 std::ofstream out(fs::path(argv[1])/"report.json");out<<report.dump(2)<<'\n';std::cout<<report.dump(2)<<'\n';return report.at("passed").get<bool>()?0:1;
}
