# Capacity1 Norm: narrow next step after the positive-time work

2026-10-17, Asia/Shanghai. Independent read-only source/evidence review. No
candidate was applied, no C++ was compiled, and no new Runtime result is claimed
in this note. Existing current-Core synthetic results remain synthetic.

## Conclusion

Do not resume candidate2 wholesale or increase terminal closure. The smallest
useful next step is a **standalone, fixed-size affine credit evaluator**, checked
against the saved exact represented progress before it is used by Runtime.
Evaluate inventory and headroom separately, using endpoint residuals and paired
progress differences; distinguish arithmetic uncertainty from real interior
slack. Stable summation alone cannot repair a snapped physical balance, and
terminal residuals cannot repair an earlier negative inventory.

Only after this evaluator passes independent arithmetic checks should a scratch
Runtime candidate use one common physical view for classification/event timing.
The current one-ULP snapshot witness remains an independent gate: a numerical
candidate that changes the accepted negative-four-ULP probe is still rejected.

## Actual first cause and the irreparable late state

`NORM-CAPACITY1.md`, `RED-DIAGNOSIS.md`, and `red-causal-analysis.json` agree:

- Event7: physical input/output are approximately
  `0.9999999999841847467824` / `0.9999999999372917532615`; diagnostic credit is
  snapped to `[1,1]` by the original `2e-10` rule.
- Using the snapped output balance adds approximately `0.124999999551ns` to the
  next outgoing interval. Event8 already has negative output near `-6.27082e-11`
  while Compute is only `0.625367...` complete. This precedes terminal roundoff.
- The eventual stall has Load13=Store15=1 and Compute14
  `0.9999999999997531472231`. Unpaid Compute work is about `8.05727e-8 eqops`.

The immutable epoch4 contract in `run-combined-ab/trace/plan.json` gives exactly

```
input  = 1 + 254*L - 255*C
output = 1 + 254*C - 255*S
```

At the stall, with `r=1-C>0`, these reduce to `input=255*r`,
`output=-254*r`. No more accurate sum can turn that output into legal positive
inventory. Completing Compute would repay a prior illegal borrow; it does not
make the preceding trajectory correct. The new run must start before event7,
from the original arrivals and unchanged physical work.

## What candidate2 actually failed

`candidate-physical-enclosure/die/src/Execution.cc:120` derives a physical view
from progress, keeps diagnostic wire snapping, and uses outward expression
enclosures. Its successful 912 sampled arithmetic comparisons cover evaluation
at supplied progress, not multi-role integration.

1. **Snapshot allocation ambiguity.** The frozen negative-four-ULP probe uses
   source rate `7862645.685395651`, tampered saved rate `...647`, and a redundant
   reconstruction `...646`. The tamper is within one ULP of that second
   reconstruction and is accepted. The guard checks at lines3094–3134 can choose
   either ordinary or redundant-row canonical allocation. A more stable credit
   expression cannot prove which historical row context published the source.
   Fresh A+B separately accepts tested source+4/+5 ULP through its ordinary
   reconstruction; do not attribute that pre-existing scope to candidate2 or
   silently redefine the frozen negative-direction test.
2. **Per-role representation.** The unchanged service-curve case reaches
   Compute progress exactly `.5`, rate1, while Store advances
   `3.63797880709171295158926e-21`, rate.5. Output is independently certified
   negative near `-7.2759576141834259e-21`. “At least one progress changed” is
   insufficient. The positive-time work must first supply the reviewed
   pre-mutation participant/represented-credit checks, including ready ticks.
   A fail-closed result preserves correctness but is not availability success.

Do not repeat candidate2's full LP/clock/witness replacement to rediscover these
failures. Keep the exact original guards and failures in the next result matrix.

## Small formula experiment

Start with a mechanically selected domain, not a task-name special case:

- a current epoch has at most three activities and two credit channels;
- each participating credit curve is affine from `(0,0)` to `(1,d_i)`;
- progress lies in `[0,1]`, all constants are finite, and the endpoint constant
  `E=I+sum(d_i)` can be certified by fixed-size arithmetic;
- the saved seven-epoch Norm and dyadic singleton cases are included;
- arbitrary piecewise knots, unknown endpoint constant accuracy, overflow, and
  unresolved sign intervals are explicitly unsupported by this first evaluator.

For a chosen participating pivot `p_j`, the exact same ledger has the identity

```
q = I*(1-p_j) + E*p_j + sum(i != j, d_i*(p_i-p_j))
h = (H-I)*(1-p_j) + (H-E)*p_j - sum(i != j, d_i*(p_i-p_j))
```

Here `q` is inventory, `h` is headroom, `H` is capacity. Evaluate both directly;
do not compute tiny headroom as a subtraction from a rounded near-capacity q.
At most three pivots and the original direct expression can be evaluated with a
fixed operation count; a deterministic structural choice or the narrowest
certified enclosure is acceptable to investigate. Do not choose a result by
reference timing or alter the physical coefficients.

For epoch4 these simplify without large cumulative products:

```
input  = (1-C) + 254*(L-C)
output = (1-S) + 254*(C-S)
```

For the statistics-stream epoch the analogous identity is
`input = 256*(1-C) + 65281*(L-C)`. When Load is done this becomes
`65537*(1-C)`. These are actual remaining curve contributions, rather than
`endpoint - rounded_cumulative` or a progress-close allowance.

Use fixed-size compensated summation for the few signed terms. Plain Kahan over
already rounded `d_i*p_i` cannot recover product/interpolation error: the saved
interior-only diagnostic has raw stats credit exactly512 while independent
Fraction evaluation is above512 by as much as `1.2620685e-17`. For this affine
domain, an FMA product residual plus compensated fixed-size sum is another
small arithmetic variant to compare offline. It needs finite-range/error
certification and actual cost measurements before production use. Neither form
is assumed exact merely because its result looks stable.

Outward bounds must be for the chosen algebraic formula and existing represented
progress. Exact endpoint identities, e.g. all p=1 and E=0, may establish a true
boundary. An interval that straddles zero does not establish zero; keep it
uncertain/unsupported rather than minting credit, widening a tolerance, or
claiming liveness. The old 912-point oracle may be reused as arithmetic input,
but its pass cannot be extrapolated to integration or snapshot acceptance.

## Runtime integration only after the arithmetic checkpoint

The diagnostic `execution.credit` can retain its original wire representation
and exact-credit1 reachability. A local, uncached physical view rebuilt from the
canonical progress can serve inventory/headroom, boundary classification,
singleton/LP tangent rows, event timing, and restored published-rate checks.
All those consumers must use the same view. Changing only recompute snapping
repeats checkpoint1; changing only singleton classification leaves the earlier
multi-role crossing intact.

This is still a proposed experiment, not an adoption recommendation. Restrict
it to the certified affine domain and retain existing behavior/availability
disclosures elsewhere. Do not silently route a supported legal case to a path
known to invent inventory, nor claim the full Norm builder is fixed by the
manual seven-epoch fixture.

Preserve the reviewed time/clock guards, the original busy definition, Q/PRIVATE
and physical work rows, fixed event bounds, and one-ULP checks. If the frozen
snapshot probe changes acceptance, stop this candidate rather than tuning its
formula or deleting the witness. Binding reconstruction to an explicit,
validated allocation row context/version is then a separate design dependency.
The present v3 wire cannot distinguish all historical publishing contexts;
selecting whichever reconstruction is nearest to supplied rates cannot certify
distance from that unknown source vector.

## Concrete next checks, in order

1. Standalone arithmetic only: use all saved internal recompute observations,
   public snapshots, dyadic endpoints, near-zero/headroom cases, and the 912
   existing oracle inputs. Compare direct, residual/difference, and compensated
   forms with exact Fraction evaluation. Report maximum enclosure width and
   unresolved/incorrect sign classifications; do not modify the saved samples.
2. Only a successful arithmetic form merits a scratch Runtime candidate.
   Run exact capacity1 filling/emptying half-second controls first: 250ms earns
   .25 and 250e9 ops, 500ms earns .5 and 500e9, then real blocking, unchanged
   busy, restore, and cancel. They distinguish actual slack from boundary
   epsilon without relying on a complicated Norm schedule.
3. Run the original full seven-epoch/two-arrival case from zero with independent
   checks at every internal integration, not just public ticks. Require paid
   work, no certified negative inventory, fixed event count, and the original
   shared-gate lower bound. Keep global cumulative summation residue separate
   from per-activity integer terminal endpoints.
4. Immediately run unchanged service-curve and split-owner probes, including
   negative4ULP, outward one-ULP tangent and structural-zero rate. Re-run the
   new paired-participant OR counterexample and tiny-ready participant control.
   A conservative representability rejection is a documented unavailable case,
   not a liveness pass; a changed snapshot acceptance is a rejection.
5. Only after those gates: consistent whole-source regression/API comparison,
   ordinary speed budgets, actual guarded long-row compiler, and consumers.
   No SDK publication, R>1 release, busy-accuracy or hardware-calibration claim
   follows from this proposed affine arithmetic checkpoint.
