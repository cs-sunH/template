# Independent numerical review (2026-10-17, Asia/Shanghai)

These are current-Core synthetic controls, not measured hardware calibration,
SDK acceptance, or production adoption. No production source was edited and no
all-source build or performance run was started by this reviewer. The parent
agent supplied independently fresh baseline/C2/C3/C4 libraries. Library hashes,
commands, source hashes, executable hashes, and original output are retained.

## Results so far

| Control | Library | Result |
|---|---|---|
| `credit_or_driver.cc` | baseline | Red: finite-credit negative crossing after mutation. |
| same | C2 | Red: one producer advances, consumer at progress .5 cannot; OR preflight accepts, credit eventually crosses capacity after mutation. |
| same | C3 | Pass: participant preflight rejects before the first tiny mutation; snapshot exactly unchanged. |
| `clock_snapshot_driver.cc` | C3 | Red: genuine clock representability failure leaves now=0, completed A finish=1; exported snapshot rejects its own lifecycle on import. |
| `legacy_tail_driver.cc` | C4 | Red: true ceil plus old target+epsilon lets advance_to(1) return now=1, terminal finish=2; snapshot rejects its own lifecycle. |
| `tiny_ready_participant_driver.cc` | C4 | Red: `buffer==3` early return skips an unrelated active curved role whose progress cannot advance at the tiny ready boundary. |

The first baseline/C2 runs are under `baseline/`, `c2/`, with shared
`identity.json`. Later runs use `{driver}-{label}/identity.json` and
`observations/report.json`. Every failure is preserved.

`legacy_tail_driver.cc` deliberately records a stronger strict-positive-tail
predicate (live at 1ns and finished at 2ns). Its minimum regression predicate is
separate: at 1ns all terminal finish times must be <= public now, and the actual
snapshot must import. Keeping the existing legacy progress closure tolerance
may restore this minimum predicate while leaving the stronger strict-tail
predicate red. Do not conflate those outcomes or alter the old report.

## Reproduction

```
python3 work/numeric-review-20261017/run.py --driver credit_or --label NEW_LABEL --library work/BUILD/libcoarse_die.a
python3 work/numeric-review-20261017/run.py --driver clock_snapshot --label NEW_LABEL --library work/BUILD/libcoarse_die.a
python3 work/numeric-review-20261017/run.py --driver legacy_tail --label NEW_LABEL --library work/BUILD/libcoarse_die.a
python3 work/numeric-review-20261017/run.py --driver tiny_ready_participant --label NEW_LABEL --library work/BUILD/libcoarse_die.a
```

The runner creates a new destination and refuses to overwrite prior results.
Each driver accepts exactly two arguments: output directory and library label.

## Scope of the proposed narrow guards

Exact integer readiness must apply to mixed curved/legacy worlds. Tiny-step
participant and represented-credit preflight must run at ready boundaries too;
the queued owner itself need not receive service. True ceil for a positive
internal fraction requires a strict target comparison, otherwise the Runtime
can integrate beyond an external target and then reset its clock backwards.

Checking every positively served curved participant is a conservative
availability restriction: an unrelated slow participant may make a tiny event
unsupported even when another participant could advance. This is fail-closed,
not evidence that all shapes are available. A positive represented increment
alone is not a capacity proof; predicted credit must use the exact existing
integration projection, cumulative-credit arithmetic/order, and original bounds
before state is mutated.

True ceil also rejects historical fractional v2/v3 snapshots whose positive
fraction <=1e-15ns was paired with a floor-valued public now. Ordinary public
calls end at integer ticks. This compatibility tightening needs explicit scope,
not relaxed LP/one-ULP validation or silent clock repair.
