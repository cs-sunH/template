#!/usr/bin/env python3
import argparse,hashlib,json,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
ap=argparse.ArgumentParser();ap.add_argument('--driver',required=True);ap.add_argument('--label',required=True);ap.add_argument('--library',required=True)
a=ap.parse_args();source=HERE/(a.driver+'_driver.cc');dest=HERE/(a.driver+'-'+a.label);dest.mkdir(exist_ok=False)
obj=dest/'driver.o';exe=dest/'driver';lib=(ROOT/a.library).resolve()
meta={'scope':'independent synthetic numerical review; not production adoption or hardware validation','driver':str(source),'source_sha256':sha(source),'archive':str(lib),'archive_sha256':sha(lib),'commands':[]}
cmd=['c++','-std=c++17','-O2','-I'+str(ROOT/'die/include'),'-I'+str(ROOT/'die/tests'),'-I'+str(ROOT/'astra-sim-wscllm/extern/helper'),'-DCOARSE_DIE_SOURCE_DIR="'+str(ROOT/'die')+'"','-DCOARSE_DIE_ROOT_DIR="'+str(ROOT)+'"','-c',str(source),'-o',str(obj)]
steps=[('compile',cmd),('link',['c++',str(obj),str(lib),'-o',str(exe)]),('run',[str(exe),str(dest/'observations'),a.label])]
for label,cmd in steps:
 row={'step':label,'command':cmd};meta['commands'].append(row)
 r=subprocess.run(cmd,capture_output=True,text=True,timeout=45,cwd=ROOT);row['returncode']=r.returncode
 (dest/(label+'.stdout.log')).write_text(r.stdout);(dest/(label+'.stderr.log')).write_text(r.stderr)
 if r.returncode and label!='run':break
meta['archive_sha256_after']=sha(lib)
for name,p in [('object_sha256',obj),('executable_sha256',exe)]:
 if p.exists():meta[name]=sha(p)
meta['evidence_sha256']={str(p.relative_to(dest)):sha(p) for p in dest.rglob('*') if p.is_file() and p.suffix in ['.json','.log']}
(dest/'identity.json').write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps({'dest':str(dest),'steps':[(r['step'],r['returncode']) for r in meta['commands']]}))
