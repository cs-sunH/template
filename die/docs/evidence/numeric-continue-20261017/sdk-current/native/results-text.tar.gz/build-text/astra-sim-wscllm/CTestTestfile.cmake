# CMake generated Testfile for 
# Source directory: /workspace/template/work/sdk-numeric-current-20261017/aggregate
# Build directory: /workspace/template/work/sdk-numeric-current-20261017/build-native/astra-sim-wscllm
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
subdirs("AstraSim")
subdirs("backend")
subdirs("frontend")
