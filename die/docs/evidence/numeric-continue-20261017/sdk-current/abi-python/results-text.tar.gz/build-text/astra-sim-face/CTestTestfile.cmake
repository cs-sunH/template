# CMake generated Testfile for 
# Source directory: /workspace/template/work/sdk-numeric-current-20261017/stage-root/astra-sim-face/extern/die_model
# Build directory: /workspace/template/work/sdk-numeric-current-20261017/build-abi/astra-sim-face
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test([=[tx8_reference_test]=] "/workspace/template/work/sdk-numeric-current-20261017/build-abi/astra-sim-face/tx8_reference_test")
set_tests_properties([=[tx8_reference_test]=] PROPERTIES  _BACKTRACE_TRIPLES "/workspace/template/work/sdk-numeric-current-20261017/stage-root/astra-sim-face/extern/die_model/CMakeLists.txt;85;add_test;/workspace/template/work/sdk-numeric-current-20261017/stage-root/astra-sim-face/extern/die_model/CMakeLists.txt;0;")
add_test([=[hardware_test]=] "/workspace/template/work/sdk-numeric-current-20261017/build-abi/astra-sim-face/hardware_test")
set_tests_properties([=[hardware_test]=] PROPERTIES  _BACKTRACE_TRIPLES "/workspace/template/work/sdk-numeric-current-20261017/stage-root/astra-sim-face/extern/die_model/CMakeLists.txt;85;add_test;/workspace/template/work/sdk-numeric-current-20261017/stage-root/astra-sim-face/extern/die_model/CMakeLists.txt;0;")
add_test([=[spec_parse_test]=] "/workspace/template/work/sdk-numeric-current-20261017/build-abi/astra-sim-face/spec_parse_test")
set_tests_properties([=[spec_parse_test]=] PROPERTIES  _BACKTRACE_TRIPLES "/workspace/template/work/sdk-numeric-current-20261017/stage-root/astra-sim-face/extern/die_model/CMakeLists.txt;85;add_test;/workspace/template/work/sdk-numeric-current-20261017/stage-root/astra-sim-face/extern/die_model/CMakeLists.txt;0;")
add_test([=[configs_consistency_test]=] "/workspace/template/work/sdk-numeric-current-20261017/build-abi/astra-sim-face/configs_consistency_test")
set_tests_properties([=[configs_consistency_test]=] PROPERTIES  _BACKTRACE_TRIPLES "/workspace/template/work/sdk-numeric-current-20261017/stage-root/astra-sim-face/extern/die_model/CMakeLists.txt;85;add_test;/workspace/template/work/sdk-numeric-current-20261017/stage-root/astra-sim-face/extern/die_model/CMakeLists.txt;0;")
add_test([=[workload_test]=] "/workspace/template/work/sdk-numeric-current-20261017/build-abi/astra-sim-face/workload_test")
set_tests_properties([=[workload_test]=] PROPERTIES  _BACKTRACE_TRIPLES "/workspace/template/work/sdk-numeric-current-20261017/stage-root/astra-sim-face/extern/die_model/CMakeLists.txt;85;add_test;/workspace/template/work/sdk-numeric-current-20261017/stage-root/astra-sim-face/extern/die_model/CMakeLists.txt;0;")
add_test([=[mapping_test]=] "/workspace/template/work/sdk-numeric-current-20261017/build-abi/astra-sim-face/mapping_test")
set_tests_properties([=[mapping_test]=] PROPERTIES  _BACKTRACE_TRIPLES "/workspace/template/work/sdk-numeric-current-20261017/stage-root/astra-sim-face/extern/die_model/CMakeLists.txt;85;add_test;/workspace/template/work/sdk-numeric-current-20261017/stage-root/astra-sim-face/extern/die_model/CMakeLists.txt;0;")
add_test([=[costmodel_test]=] "/workspace/template/work/sdk-numeric-current-20261017/build-abi/astra-sim-face/costmodel_test")
set_tests_properties([=[costmodel_test]=] PROPERTIES  _BACKTRACE_TRIPLES "/workspace/template/work/sdk-numeric-current-20261017/stage-root/astra-sim-face/extern/die_model/CMakeLists.txt;85;add_test;/workspace/template/work/sdk-numeric-current-20261017/stage-root/astra-sim-face/extern/die_model/CMakeLists.txt;0;")
add_test([=[tx8_compile_test]=] "/workspace/template/work/sdk-numeric-current-20261017/build-abi/astra-sim-face/tx8_compile_test")
set_tests_properties([=[tx8_compile_test]=] PROPERTIES  _BACKTRACE_TRIPLES "/workspace/template/work/sdk-numeric-current-20261017/stage-root/astra-sim-face/extern/die_model/CMakeLists.txt;85;add_test;/workspace/template/work/sdk-numeric-current-20261017/stage-root/astra-sim-face/extern/die_model/CMakeLists.txt;0;")
add_test([=[execution_test]=] "/workspace/template/work/sdk-numeric-current-20261017/build-abi/astra-sim-face/execution_test")
set_tests_properties([=[execution_test]=] PROPERTIES  _BACKTRACE_TRIPLES "/workspace/template/work/sdk-numeric-current-20261017/stage-root/astra-sim-face/extern/die_model/CMakeLists.txt;85;add_test;/workspace/template/work/sdk-numeric-current-20261017/stage-root/astra-sim-face/extern/die_model/CMakeLists.txt;0;")
add_test([=[selection_fuzz_test]=] "/workspace/template/work/sdk-numeric-current-20261017/build-abi/astra-sim-face/selection_fuzz_test")
set_tests_properties([=[selection_fuzz_test]=] PROPERTIES  _BACKTRACE_TRIPLES "/workspace/template/work/sdk-numeric-current-20261017/stage-root/astra-sim-face/extern/die_model/CMakeLists.txt;85;add_test;/workspace/template/work/sdk-numeric-current-20261017/stage-root/astra-sim-face/extern/die_model/CMakeLists.txt;0;")
add_test([=[capi_test]=] "/workspace/template/work/sdk-numeric-current-20261017/build-abi/astra-sim-face/capi_test")
set_tests_properties([=[capi_test]=] PROPERTIES  _BACKTRACE_TRIPLES "/workspace/template/work/sdk-numeric-current-20261017/stage-root/astra-sim-face/extern/die_model/CMakeLists.txt;95;add_test;/workspace/template/work/sdk-numeric-current-20261017/stage-root/astra-sim-face/extern/die_model/CMakeLists.txt;0;")
subdirs("coarse")
