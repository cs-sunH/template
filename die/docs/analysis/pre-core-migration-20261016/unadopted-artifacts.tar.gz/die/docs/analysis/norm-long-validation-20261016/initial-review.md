# Read-only review of archived Norm long-row implementation

Review base: main d16b5459a46df7f54d6e4afa36e2a5debd947690. No die/ files changed
by this review. Work files here are drafts, not production evidence.

No definite BF16/FP32 workload, SRAM, or statistics-barrier violation was found
by inspection. The seven epochs contain a complete first-pass Compute terminal
before the first apply input can start. For rows <= Core count, all consuming
Cores have the same full row, so the two-slot proof can be done per Core rather
than borrowing another Core's capacity. In the apply middle (T tiles), physical
input bytes are B_full*q_in + B_tail*p_Load <= 2*B_full, and physical output
bytes are B_full*(q_out + p_Compute) <= 2*B_full. The terminal transition then
exposes the reserved last input and penultimate output. These statements apply
to the declared affine approximation; they do not prove discrete timing error.

The new INT4 scope has a material contract gap. Root design sections 5.2, 6.1,
6.3 require scale capacity/traffic. NormLongRow.hh:18-20,36-38,55-67,139-156
contains tensor bytes and conversion ops, but no explicit scale allocation or
traffic. The independent ledger test repeats this omission. Existing GEMM
Mapping.cc:1039-1054 reserves local 4-byte scales per conversion/output buffer,
and 1155-1171 charges their on-chip traffic. Its HBM tensor payload at1092-1099
does not guess externally stored INT4 scale format. Existing elementwise peak
1624-1634 and row-Norm likewise lack explicit scales; that existing gap should
be recorded separately, not silently copied as proof for the new scope.
Minimal next step: constrain newly added long-row mapping to all three roles
in {BF16, FP32}; leave pre-existing row behavior untouched pending its own
format/accounting investigation.

The archive's 24 ledger cases use one wide h=1048577 and four dtype tuples;
the timing oracle only covers one Core, one BF16 row. It does not certify mixed
roles, 2/4 Cores, odd-tail capacity grids, fractional INT4 coefficients, binding
NoC, or nonzero region startup. Keep R>1 and rows>Core explicitly unsupported.
The 36 original joint failures must remain failed: finite smooth service
intervals can closely predict completion while spreading busy time far more
widely than discrete bursts. Do not fit eta to remove that mismatch.

## Draft expanded offline tools

`norm_long_oracle.py` independently derives BF16/FP32 per-tile physical work
from normalized task shape/types, not production curves or activity durations.
It supports 1/2/4 Cores and rows<=Cores. Identical per-Core rows run in lockstep;
one cohort activity aggregates their physical bytes, while PRIVATE uses one
Core's service rate. The existing independent grouped allocator retains Q per
owner. All 13 rows exist but routing work is zero: synthetic nonbinding routing
only, not binding-route validation. INT4 is rejected.

`norm_long_oracle_driver.cc` is a standalone proposed driver supporting
--cores/--rows and --activation-dtype/--parameter-dtype/--output-dtype. Build with
the die/tests include directory, normal die includes/helper JSON and source-dir
macro; link against a fresh actual production library after adopting changes.
It has been syntax-checked but has not been linked or executed.

Executed checks:

- Python py_compile succeeded.
- C++17 g++ -fsyntax-only succeeded; driver-syntax.log is empty (exit0).
- Recomputed archived layernorm-h65537-balanced solo/sync/offset using draft
  oracle. Completion, first-output, busy counters equal the original independent
  oracle exactly. All three joint classifications remain failed. Fresh result:
  baseline-layernorm-h65537-balanced.report.json.
- Draft-only smoke sweep: both Norm types, Cores1/2/4, rows in unique {1,Cores},
  every 2^3 mixed BF16/FP32 role tuple at hidden769 with two offset owners:
  80 cases complete; max41 discrete reference events. This is a reference
  consistency smoke check, not a production comparison or timing certificate.

Recommended adoption verification: explicit INT4 long-row rejection tests;
all 8 BF16/FP32 dtype tuples and 1/2/4 Core partial/full consumer prefixes;
hidden around multiples of256 and around the row-resident SRAM threshold;
pause compute and check per-Core input occupancy; pause Store and check output
occupancy; snapshot/cancel during both phases; nonzero startup/setup; fresh
full public suite and actual query/cold/arbitration budget. Compare completion,
first output, and unchanged busy independently. Add binding-route tests only
after deriving explicit route work rather than claiming this draft covers it.
