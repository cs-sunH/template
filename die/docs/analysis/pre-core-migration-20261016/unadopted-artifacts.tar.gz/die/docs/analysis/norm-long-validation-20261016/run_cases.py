#!/usr/bin/env python3
"""Actual driver and independent discrete reference; retain all metric failures."""
import argparse
import concurrent.futures
import gzip
import hashlib
import itertools
import json
import pathlib
import subprocess
import sys
import time

p=argparse.ArgumentParser()
p.add_argument('--driver',required=True);p.add_argument('--output',required=True)
p.add_argument('--jobs',type=int,choices=[1,2],default=2)
p.add_argument('--matrix',choices=['mixed','profiles','all'],default='all')
a=p.parse_args()
root=pathlib.Path(__file__).resolve().parents[4]
driver=pathlib.Path(a.driver).resolve();out=pathlib.Path(a.output).resolve()
out.mkdir(parents=True,exist_ok=False)
oracle=root/'die/validation/norm_long_oracle.py'
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
cases=[]
if a.matrix in ['mixed','all']:
    for norm,cores in itertools.product(['rmsnorm','layernorm'],[1,2,4]):
        for rows in sorted({1,cores}):
            for x,parameter,y in itertools.product(['bf16','fp32'],repeat=3):
                cases.append((65537,norm,'balanced',cores,rows,x,parameter,y))
if a.matrix in ['profiles','all']:
    for h,norm,profile in itertools.product([65537,131073],['rmsnorm','layernorm'],['memory','compute','local']):
        cases.append((h,norm,profile,1,1,'bf16','bf16','bf16'))

def invoke(command,stdout,stderr):
    with stdout.open('w') as log,stderr.open('w') as err:
        try:return subprocess.run(command,cwd=root,stdout=log,stderr=err).returncode
        except OSError as error:err.write(str(error)+'\n');return 127

def run(case):
    h,norm,profile,cores,rows,x,parameter,y=case
    name=f'{norm}-h{h}-{profile}-c{cores}-r{rows}-{x}-{parameter}-{y}'
    raw=out/(name+'.raw.json');report=out/(name+'.report.json')
    command=[str(driver),'--hidden',str(h),'--norm',norm,'--profile',profile,'--cores',str(cores),
        '--rows',str(rows),'--activation-dtype',x,'--parameter-dtype',parameter,'--output-dtype',y]
    row={'case':name,'driver_command':command,'started_unix':time.time()}
    row['driver_return_code']=invoke(command,raw,out/(name+'.driver.stderr.txt'))
    if row['driver_return_code']==0:
        command=[sys.executable,str(oracle),'--raw',str(raw),'--output',str(report)]
        row['oracle_command']=command
        row['oracle_return_code']=invoke(command,out/(name+'.oracle.log'),out/(name+'.oracle.stderr.txt'))
        if row['oracle_return_code']==0:
            result=json.loads(report.read_text())
            row['scenarios']={key:value['comparison']['status'] for key,value in result['scenarios'].items()}
    row['artifacts']={}
    for path in [raw,report]:
        if not path.exists():continue
        data=path.read_bytes();compressed=path.with_suffix(path.suffix+'.gz')
        compressed.write_bytes(gzip.compress(data,mtime=0))
        assert gzip.decompress(compressed.read_bytes())==data
        row['artifacts'][path.name]={'retained':compressed.name,'raw_sha256':hashlib.sha256(data).hexdigest(),
            'gzip_sha256':sha(compressed),'raw_bytes':len(data)}
        path.unlink()  # only this fresh run's exact bytes, fully retained as gzip
    row['finished_unix']=time.time()
    return row

with concurrent.futures.ThreadPoolExecutor(max_workers=a.jobs) as pool:
    results=list(pool.map(run,cases))
summary={'scope':'BF16/FP32 R1 one row per consumer Core; nonbinding routing synthetic reference; no fitting/hardware calibration',
    'driver_sha256':sha(driver),'oracle_sha256':sha(oracle),'runner_sha256':sha(pathlib.Path(__file__)),
    'jobs':a.jobs,'cases':results}
(out/'suite.json').write_text(json.dumps(summary,indent=2)+'\n')
process_failures=sum(row['driver_return_code']!=0 or row.get('oracle_return_code')!=0 for row in results)
statuses={}
for row in results:
    for status in row.get('scenarios',{}).values():statuses[status]=statuses.get(status,0)+1
print(json.dumps({'cases':len(results),'process_failures':process_failures,'completion_and_original_busy':statuses}))
raise SystemExit(bool(process_failures))
