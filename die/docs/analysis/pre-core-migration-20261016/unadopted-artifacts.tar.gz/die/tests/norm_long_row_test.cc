#include "test_support.hh"
#include <array>
#include <set>
using namespace coarse_die;
using namespace coarse_die_test;
using u64=std::uint64_t;
namespace {
Hardware hardware(u64 cores) {
  auto c=read_json(std::string(COARSE_DIE_SOURCE_DIR)+"/configs/example_hardware_explicit.json");
  c["architecture"]["core_columns_nx"]=cores;c["architecture"]["core_rows_ny"]=1;
  return resolve_hardware(c);
}
json task(u64 rows,u64 h,bool layer,const std::string& x,const std::string& p,const std::string& y) {
  return {{"op_kind","norm"},{"tensor_shapes",{{"m",rows},{"hidden",h},{"norm_type",layer ? "layernorm" : "rmsnorm"}}},
      {"storage_dtype",{{"activations",x},{"parameters",p},{"output",y}}}};
}
u64 bytes(u64 n,const std::string& dt){return dt=="int4" ? (n+1)/2 : n*(dt=="bf16" ? 2 : 4);}
void independent_two_pass_ledger() {
  constexpr u64 h=1048577;
  for(bool layer:{false,true})for(u64 cores:{1,3,4})for(u64 rows:std::set<u64>{1,cores})
      for(const auto types:{std::array<std::string,3>{{"bf16","bf16","bf16"}},
          {{"bf16","bf16","fp32"}},{{"bf16","fp32","bf16"}},{{"bf16","fp32","fp32"}},
          {{"fp32","bf16","bf16"}},{{"fp32","bf16","fp32"}},{{"fp32","fp32","bf16"}},{{"fp32","fp32","fp32"}}}) {
    const auto hw=hardware(cores);const auto plan=compile(hw,task(rows,h,layer,types[0],types[1],types[2]));
    const auto& s=plan->summary;const u64 vectors=layer ? 2 : 1;
    const auto& x=types[0];const auto& p=types[1];const auto& y=types[2];
    u64 read=0,write=0,math=0,converted=0,eq=0,sr=0,sw=0,local=0;
    const auto cost=[](const std::string& dt){return dt=="int4" ? 4 : dt=="bf16" ? 1 : 0;};
    for(u64 row=0;row<rows;++row) {
      require(row%cores==row,"each row owns a distinct consumer Core");
      const u64 xb=bytes(h,x),yb=bytes(h,y),pb=vectors*bytes(h,p);
      const u64 xc=x=="fp32" ? 0 : 4*h,pc=p=="fp32" ? 0 : 4*h*vectors;
      const u64 stat_r=xb+xc,stat_w=xc+16;
      const u64 apply_r=xb+xc+4*h*vectors+(p=="fp32" ? 0 : pb)+(y=="fp32" ? 0 : 4*h)+16;
      const u64 apply_w=xc+pc+4*h+(y=="fp32" ? 0 : yb);
      read+=2*xb+pb;write+=yb;math+=(layer ? 8 : 6)*h;
      eq+=(layer ? 8 : 6)*h+h*(2*cost(x)+vectors*cost(p)+cost(y));
      converted+=h*(2*(x!="fp32")+vectors*(p!="fp32")+(y!="fp32"));
      sr+=stat_r+apply_r+yb;sw+=2*xb+pb+stat_w+apply_w;local+=stat_r+stat_w+apply_r+apply_w;
    }
    require(s.at("template_id")=="norm_two_pass_single_cohort_v1","long rows use an actual bounded two-pass mapping");
    require(s.at("hbm_read_bytes_total")==read && s.at("hbm_write_bytes_total")==write,
        "each Core rereads its input from HBM and loads its own separately packed gamma/beta");
    require(s.at("source_vec_ops")==math && s.at("vec_equivalent_ops")==eq && s.at("conversion_elements")==converted,
        "two passes preserve math and charge every conversion");
    require(s.at("sram_read_bytes")==sr && s.at("sram_write_bytes")==sw && s.at("local_bus_bytes")==local,
        "tile conversion, input reload and retained statistics have physical SRAM/LOCAL service");
    require(s.at("hbm_workspace_peak_bytes")==0,"one row per Core retains statistics on-chip without a fictitious HBM tensor");
    const auto& ledger=s.at("norm_long_row_ledger");
    const u64 peak=2*ledger.at("input_slot_bytes_per_core").get<u64>()+
        2*ledger.at("output_slot_bytes_per_core").get<u64>()+ledger.at("working_bytes_per_core").get<u64>()+16+64;
    require(s.at("sram_peak_bytes_per_core")==peak && peak<10000,"long row SRAM is a real fixed tile allocation");
    require(plan->epochs.size()==7 && s.at("service_description_count").get<u64>()<=16,
        "row width cannot create tile-linear epochs or service descriptors");
    u64 ar=0,aw=0;long double ae=0,asr=0,asw=0,al=0;
    for(const auto& e:plan->epochs) {
      require(e.activities.size()<=3,"each epoch retains at most three independent activities");
      for(const auto& a:e.activities){
        for(const auto& row:a.hbm_bytes){ar+=row[0];aw+=row[1];}
        ae+=planned_vec_eqops(a);asr+=a.work[SRAM_READ];asw+=a.work[SRAM_WRITE];al+=a.work[LOCAL];
      }
    }
    require(ar==read && aw==write && ae==eq && asr==sr && asw==sw && al==local,
        "actual activities conserve the independently derived two-pass ledger");
    Runtime runtime(hw);const auto handle=runtime.submit(plan,{1,2,3,1},0);unsigned events=0;
    while(!runtime.drained()){require(++events<=32,"width must not create tile-linear events");runtime.advance_to(*runtime.next_event());}
    require(runtime.terminal_finish_ns(handle).has_value(),"the last apply output must actually complete");
  }
}
void statistics_barrier_pause_restore() {
  const auto hw=hardware(2);const auto plan=compile(hw,task(2,131073,false,"bf16","bf16","bf16"));
  Runtime runtime(hw);const auto handle=runtime.submit(plan,{1,2,3,1},0);
  runtime.advance_to(*runtime.next_event()); // launch
  runtime.advance_to(*runtime.next_event()); // statistics first input tile
  runtime.update_capacity(COMPUTE_GATE,0,runtime.now_ns());
  unsigned events=0;
  while(runtime.next_event()){require(++events<=4,"only finite statistics input prefetch is allowed");runtime.advance_to(*runtime.next_event());}
  auto counters=runtime.counters();const auto& served=counters.at("hbm_served_bytes_by_row_direction");
  require(served[0][1].get<double>()+served[1][1].get<double>()==0,
      "no output may be written while full-row statistics are blocked");
  // next_event() is publicly ceiled to integer ns. Statistics may consume a
  // tiny input prefix before that tick is returned; bound unconsumed bytes,
  // not all bytes ever loaded. RMS BF16 statistics costs 3 eqops/element.
  const auto progress=runtime.query_progress(handle);
  const double consumed=progress.at("served").at("vec_eqops").get<double>()/3.0*2.0;
  const double resident=served[0][0].get<double>()+served[1][0].get<double>()-consumed;
  require(resident<=2*512*2+1e-6 && resident>=-1e-6,
      "statistics prefetch respects two source tiles per Core after subtracting actual consumption");
  const auto snapshot=runtime.export_snapshot();auto resumed=Runtime::import_snapshot(hw,snapshot);
  auto cancelled=Runtime::import_snapshot(hw,snapshot);cancelled->cancel(handle,cancelled->now_ns());
  require(cancelled->drained() && cancelled->query_progress(handle).at("cancelled")==true,
      "long-row cancellation retains the public terminal semantics");
  runtime.update_capacity(COMPUTE_GATE,hw.rates[COMPUTE_GATE],runtime.now_ns());
  resumed->update_capacity(COMPUTE_GATE,hw.rates[COMPUTE_GATE],resumed->now_ns());
  events=0;while(!runtime.drained()){require(++events<=32,"resumed long row remains bounded");runtime.advance_to(*runtime.next_event());}
  while(!resumed->drained())resumed->advance_to(*resumed->next_event());
  require(runtime.counters()==resumed->counters() && runtime.query_progress(handle)==resumed->query_progress(handle),
      "both passes and retained statistics restore without replay or duplicate work");
}
void unsupported_multirow_and_repeats() {
  const auto hw=hardware(2);
  for(auto spec:{task(3,1048577,false,"bf16","bf16","bf16"),task(1,1048577,true,"bf16","bf16","bf16")}) {
    if(spec["tensor_shapes"]["m"]==1)spec["layer_instances"]=2;
    bool rejected=false;try{(void)compile(hw,spec);}catch(const std::invalid_argument& e){rejected=std::string(e.what()).find("unsupported_workspace")!=std::string::npos;}
    require(rejected,"the new subset cannot silently aggregate repeated or multiple per-Core rows");
  }
}
void exact_tile_capacity_boundary() {
  for(bool layer:{false,true})for(const auto x:{"bf16","fp32"})
      for(const auto p:{"bf16","fp32"})for(const auto y:{"bf16","fp32"}) {
    const u64 parameters=layer ? 2 : 1;
    const u64 peak=2*(bytes(256,x)+parameters*bytes(256,p))+2*bytes(256,y)+1024+
        (std::string(p)=="fp32" ? 0 : parameters*1024)+16+64;
    auto config=hardware(1).input;
    config["performance_profile"]["rho_sram"]=static_cast<double>(peak)/262144;
    const auto hw=resolve_hardware(config);const auto spec=task(1,1048577,layer,x,p,y);
    const auto plan=compile(hw,spec);
    require(plan->summary.at("sram_peak_bytes_per_core")==peak,
        "both raw slots, output slots, converted working tiles, statistics and metadata fit exactly");
    config["performance_profile"]["rho_sram"]=std::nextafter(static_cast<double>(peak)/262144,0.0);
    bool rejected=false;
    try{(void)compile(resolve_hardware(config),spec);}catch(const std::invalid_argument& e) {
      rejected=std::string(e.what()).find("unsupported_workspace")!=std::string::npos;
    }
    require(rejected,"one representable step below required tile capacity must reject without changing hardware");
  }
}
void width_scaling_and_apply_restore() {
  const auto hw=hardware(3);
  for(u64 hidden:{65537ULL,1048577ULL,1099511627777ULL}) {
    const auto plan=compile(hw,task(2,hidden,true,"fp32","bf16","fp32"));
    Runtime runtime(hw);const auto h=runtime.submit(plan,owner(1,1,1),0);unsigned events=0;
    while(!runtime.drained()) {
      require(++events<=32 && runtime.next_event().has_value(),"large width has a bounded advancing event sequence");
      runtime.advance_to(*runtime.next_event());
    }
    require(runtime.query_progress(h).at("served").at("vec_eqops")==20*hidden,
        "wide mixed-role layers conserve all math and parameter conversion work");
    require(plan->epochs.size()==7 && service_description_count(*plan)<=16,
        "one million and one trillion elements use the same finite service budget");
  }
  const auto plan=compile(hw,task(2,1048577,true,"fp32","bf16","fp32"));
  Runtime source(hw);const auto h=source.submit(plan,owner(2,2,2),0);
  while(source.query_progress(h).at("epoch_index").get<unsigned>()<4)source.advance_to(*source.next_event());
  const auto start=source.now_ns(),end=*source.next_event();
  require(end>start+1,"fixture exposes fractional progress inside apply");source.advance_to(start+(end-start)/2);
  auto imported=Runtime::import_snapshot(hw,source.export_snapshot());
  for(auto* runtime:{&source,imported.get()}) {
    runtime->update_capacity(HBM0,0,runtime->now_ns());runtime->update_capacity(HBM1,0,runtime->now_ns());
    unsigned events=0;
    while(runtime->next_event()) {
      require(++events<=8,"blocked apply has only finite input/output credit transitions");
      runtime->advance_to(*runtime->next_event());
    }
    const auto progress=runtime->query_progress(h);
    const auto& credits=progress.at("credit");
    for(const auto& value:credits)require(value.at("value").get<double>()>=0 && value.at("value").get<double>()<=1 &&
        value.at("capacity")==1,
        "paused apply cannot create more resident input/output than its middle slots");
  }
  auto cancelled=Runtime::import_snapshot(hw,source.export_snapshot());cancelled->cancel(h,cancelled->now_ns());
  require(cancelled->drained() && cancelled->query_progress(h).at("cancelled")==true,
      "cancellation during apply preserves partial two-pass work without a successful terminal");
  for(auto* runtime:{&source,imported.get()}) {
    runtime->update_capacity(HBM0,hw.rates[HBM0],runtime->now_ns());runtime->update_capacity(HBM1,hw.rates[HBM1],runtime->now_ns());
    unsigned events=0;
    while(!runtime->drained()) {
      require(++events<=32 && runtime->next_event().has_value(),"resumed mixed-role apply remains bounded");
      runtime->advance_to(*runtime->next_event());
    }
  }
  require(source.counters()==imported->counters() && source.query_progress(h)==imported->query_progress(h),
      "fractional apply snapshot, HBM pause and resumed terminal preserve complete physical counters");
}
void unsupported_int4_scale_contract() {
  const auto hw=hardware(1);
  for(const auto role:{"activations","parameters","output"}) {
    auto spec=task(1,1048577,false,"bf16","bf16","bf16");spec["storage_dtype"][role]="int4";
    bool rejected=false;try{(void)compile(hw,spec);}catch(const std::invalid_argument& e) {
      rejected=std::string(e.what()).find("INT4 scale accounting")!=std::string::npos;
    }
    require(rejected,"new long-row support cannot silently claim INT4 correctness without scale capacity and traffic");
  }
}
void independent_prefix_routes() {
  for(const auto grid:{std::array<u64,2>{{3,2}},{{2,3}}})
      for(const std::string profile:{"distributed_ideal_v2","edge_single_word_v2"})
      for(u64 rows:{1,5,6}) {
    auto config=hardware(1).input;const u64 nx=grid[0],ny=grid[1];
    config["architecture"]["core_columns_nx"]=nx;config["architecture"]["core_rows_ny"]=ny;
    config["performance_profile"]["timing_topology_profile"]=profile;
    const auto hw=resolve_hardware(config);
    const auto plan=compile(hw,task(rows,131073,true,"bf16","fp32","bf16"));
    for(const auto& epoch:plan->epochs)for(const auto& activity:epoch.activities) {
      if(activity.role==Role::Compute)continue;
      const bool writing=activity.role==Role::Store;std::array<long double,resource_count> expected{};
      for(u64 row=0;row<2;++row) {
        const long double payload=activity.hbm_bytes[row][writing ? 1 : 0];
        const u64 source_rows=profile=="distributed_ideal_v2" ? ny : 1;
        for(u64 core=0;core<rows;++core)for(u64 sx=0;sx<nx;++sx)for(u64 sy0=0;sy0<source_rows;++sy0) {
          const u64 sy=source_rows==ny ? sy0 : row==0 ? 0 : ny-1;
          u64 x0=sx,y0=sy,x1=core%nx,y1=core/nx;
          if(writing){std::swap(x0,x1);std::swap(y0,y1);}
          const long double amount=payload/(rows*nx*source_rows);
          if(x0<nx/2 && x1>=nx/2)expected[XPOS]+=amount;
          if(x0>=nx/2 && x1<nx/2)expected[XNEG]+=amount;
          if(y0<ny/2 && y1>=ny/2)expected[YPOS]+=amount;
          if(y0>=ny/2 && y1<ny/2)expected[YNEG]+=amount;
          expected[HOP]+=amount*(std::abs(static_cast<long double>(x0)-x1)+std::abs(static_cast<long double>(y0)-y1));
        }
        if(profile=="edge_single_word_v2")expected[row==0 ? INJECT0 : INJECT1]+=payload;
      }
      for(std::size_t r=INJECT0;r<resource_count;++r)
        require_close(activity.work[r],static_cast<double>(expected[r]),1e-12*std::max(1.0L,expected[r]),
            "long-row IO follows the actual partial Core prefix and physical source-to-Core route");
    }
  }
}
void synchronous_long_row_credit_liveness() {
  auto config=hardware(4).input;
  config["architecture"]["core_type"]="small";
  config["performance_profile"]["eta_vec"]=1;
  config["performance_profile"]["eta_hbm_vector"]=1;
  config["performance_profile"]["launch_ns_per_macro"]=0;
  auto hw=resolve_hardware(config);hw.derived["core"]["P_vec_per_core_ops_per_s"]=204800;
  for(std::size_t r=0;r<resource_count;++r) {
    double rate=hw.derived["resources"][r]["enabled"].get<bool>() ? 4e12 : 0;
    if(r==COMPUTE_GATE)rate=1;
    if(r==HBM0 || r==HBM1)rate=204800;
    hw.rates[r]=rate;hw.derived["resources"][r]["rate"]=rate;
  }
  hw.fingerprint="synthetic-long-row-credit-liveness:"+stable_hash(hw.fingerprint);
  const auto plan=compile(hw,task(1,65537,false,"bf16","fp32","fp32"));
  Runtime runtime(hw);
  const auto first=runtime.submit(plan,owner(1,1,1),0),second=runtime.submit(plan,owner(2,2,2),0);
  unsigned events=0;
  while(!runtime.drained()) {
    const auto next=runtime.next_event();
    require(next.has_value() && ++events<=64,
        "synchronous curved owners cannot lose their last positive input slack and deadlock");
    runtime.advance_to(*next);
  }
  for(auto handle:{first,second}) {
    require(runtime.query_progress(handle).at("served").at("vec_eqops")==8*65537 &&
        *runtime.terminal_finish_ns(handle)>=5120000000ULL,
        "both owners pay all physical compute work before the final two-pass terminal");
  }
}
void run(){independent_two_pass_ledger();statistics_barrier_pause_restore();unsupported_multirow_and_repeats();
  exact_tile_capacity_boundary();width_scaling_and_apply_restore();unsupported_int4_scale_contract();independent_prefix_routes();
  synchronous_long_row_credit_liveness();}
}
int main(){return run_test("norm_long_row_test",run);}
