# Inactive Norm statistics prefix/tail candidate

This directory is an experiment prepared for review. Production die source was
not edited. No compiled-model timing comparison, CTest, benchmark, adoption,
hardware calibration, or five-repository publishing was performed here. The
reported six first-output cases motivating this experiment came from the parent
agent's 92-case trial, not an independently run result in this directory. No
improvement is claimed.

`NormLongRow.baseline.hh` is the observed current header. Its SHA-256 is
`16b428bdbb8a7ae622b391dedf0ff3d9d9f4bb1e26c1f0954cddd4c431020ff7`.
`NormLongRow.candidate.hh` changes only the statistics construction and its
diagnostics. `statistics-prefix-tail.patch` is a unified patch against that
baseline; `manifest.json` binds both headers and the patch. The generator
`prepare_candidate.py` writes only this directory, checks its expected baseline
fragments, and never applies the candidate to production source. Preserve these
artifacts before any later regeneration, because regeneration observes the then
current production header.

## Proposed fixed partition

For hidden H>512, define T=256, N=ceil(H/T), t=H-(N-1)T. N>=3 and 1<=t<=256.
One input credit means one input element at each consuming Core. The input
capacity remains two physical source tiles (512 elements per Core); the
unchanged static SRAM check accounts for the actual raw slots, conversion
scratch, output slots, 16-byte retained statistics, and 64-byte metadata.

| Statistics epoch | Active flows and signed input credit | Entry credit | Exit credit | Actual descriptions |
|---|---|---:|---:|---:|
| First input | L(T) | 0 | T | 1 |
| First compute and next input | L(T), C(-T) | T | T | 2 |
| Middle with final input retained | L(H-2T), C(-(H-T-t)) | T | t | 2 |
| Last tail compute | C(-t) | t | 0 | 1 |

All these epochs use input capacity 2T. The middle C represents exactly N-2
identical full statistic tiles. Its paired L includes N-3 full tiles plus the
last tail. There is no tile/Core/repeat-controlled C++ loop or hidden per-tile
activity switch. The unused output credit remains zero. Six affine activity
descriptions occupy the statistics budget of 8; the existing initial launch
gate, when present, makes that primitive's charged description count seven.

The application kernel remains its original five epochs and nine descriptions.
Its source helper functions and entire execution-construction block are left
unchanged. Their absolute epoch indices and activity IDs naturally shift by two
because statistics now has four epochs rather than two. The complete Plan has
nine epochs and 15 physical service descriptions; one initial launch gate makes
16. The existing maximum-three-activities and 13-domain allocator are untouched.

## Bytes, equivalent operations, and PRIVATE

For a statistic segment of n elements, let b=2 for BF16 X or 4 for FP32 X, and
let c=4n for BF16 X or zero for FP32 X. Per consuming Core:

- SRAM reads = bn+c.
- SRAM writes = c plus 16 only in the final tail C.
- LOCAL bytes = SRAM reads + SRAM writes.
- Equivalent operations = n*(2 for RMSNorm or 3 for LayerNorm) plus n only
  for BF16 X conversion.

The first and middle C do not materialize the final retained 16-byte state.
The last tail C owns that complete write. Epoch ordering prevents every apply
load/compute/store from entering before the final statistic C completes; the
statistics-ready epoch and activity ID now point to this real final C. The
same Core retains its own state, with zero statistics HBM workspace. Total
physical bytes, equivalent operations, conversion counts, source math,
parameter traffic, and SRAM peak are unchanged from the baseline equations.
The helper `statistics` aggregate is retained for the exact total-metrics
ledger; only first/middle/last statistics flows become activities.

For one full statistic tile, use the existing physical per-Core maximum:

`M=max(eqops/Pvec, SRAM_reads/Rread, SRAM_writes/Rwrite, LOCAL/Rlocal)`.

The middle PRIVATE service is `(N-2)*M`, derived from identical full tiles;
the last tail uses its own maximum including the sole 16-byte write. Thus total
statistics PRIVATE is `M+(N-2)*M+M_tail`, rather than the maximum after merging
heterogeneous full/tail work. `seal_activity` retains its normal physical lower
bounds and binary floating-point arithmetic. No extra coefficient, fake
resource, or changed fairness weight is introduced; Q is sealed from each real
partition using the existing canonical basis.

## Checks actually run

`python3 work/norm-statistics-variant/validate_partition.py` passed 36 static
integer ledger cases (RMS/Layer, BF16/FP32 X, nine widths), 144 exact Fraction
PRIVATE checks with four different limiting-rate regimes, and 112 offline
per-tile enumerations for small widths. The result and script SHA are in
`partition-validation.json`. The huge-width cases are analytic only. The
offline tile loop is a validation oracle and is absent from candidate C++.

These checks establish integer partition sums, credit endpoints, one final
state write, fixed description arithmetic, and the proposed per-tile PRIVATE
formula. They do not execute Runtime, establish timing accuracy, verify
floating-point dynamic credit integration, prove busy accuracy, or establish
performance budgets.

## Checks required before adoption

Use a separate candidate build/source identity after the common Runtime
positive-slack fix is settled. Existing long-row tests hard-code seven epochs
and apply indices; a nine-epoch candidate needs derived statistics/apply indices
in the experimental test variant. Do not silently relabel historical baseline
test passes as candidate verification. Check actual service descriptions,
full/tail/513-width partitions, only-final-C 16-byte state writing, zero apply
service before complete statistics, exact integer ledgers, PRIVATE, physical
routes, compute/HBM pauses, terminal/credit boundaries, snapshot/cancel, and
large-width constant event counts. Then compare the same frozen 92-case matrix
with the same full raw outputs, first-output/completion/busy definitions and
unchanged hardware/calibration. Original busy failures remain failures unless
new evidence proves otherwise. Preserve baseline and candidate outcomes; no
decision to adopt has been made here.
