#!/usr/bin/env python3
"""Static integer/Fraction ledger checks only; no compiled model comparison."""
from fractions import Fraction as F
import datetime
import hashlib
import json
from pathlib import Path

directory=Path(__file__).resolve().parent
widths=(513,768,769,1024,1025,65536,65537,1048577,1099511627777)
rates=((F(1),F(7),F(11),F(13)),(F(13),F(1),F(17),F(29)),
       (F(31),F(37),F(1),F(41)),(F(43),F(47),F(53),F(1)))
cases=[]
private_checks=0
brute_checks=0
for layer in (False,True):
    for dtype in ('bf16','fp32'):
        for hidden in widths:
            tiles=(hidden+255)//256
            tail=hidden-(tiles-1)*256
            middle=hidden-256-tail
            def cost(n,last):
                source=n*(2 if dtype=='bf16' else 4)
                converted=4*n if dtype=='bf16' else 0
                sr=source+converted
                sw=converted+(16 if last else 0)
                eq=n*((3 if layer else 2)+(dtype=='bf16'))
                return sr,sw,sr+sw,eq
            first=cost(256,False)
            center=cost(middle,False)
            last=cost(tail,True)
            assert tuple(a+b+c for a,b,c in zip(first,center,last))==cost(hidden,True)
            assert middle==(tiles-2)*256
            assert hidden-512==(tiles-3)*256+tail
            assert [256,256,tail,0]==[256,256+256-256,256+(hidden-512)-middle,tail-tail]
            assert all(0<=n<=512 for n in (0,256,tail))
            assert first[1]-(4*256 if dtype=='bf16' else 0)==0
            assert center[1]-(4*middle if dtype=='bf16' else 0)==0
            assert last[1]-(4*tail if dtype=='bf16' else 0)==16
            assert 1+2+2+1==6 and 6+9+1==16 and 6+1<=8
            for pvec,rsr,rsw,rlocal in rates:
                def tile_private(n,is_last):
                    sr,sw,local,eq=cost(n,is_last)
                    return max(F(eq)/pvec,F(sr)/rsr,F(sw)/rsw,F(local)/rlocal)
                first_private=tile_private(256,False)
                last_private=tile_private(tail,True)
                analytic=first_private+(tiles-2)*first_private+last_private
                middle_private=max(F(center[3])/pvec,F(center[0])/rsr,
                                   F(center[1])/rsw,F(center[2])/rlocal)
                assert middle_private==(tiles-2)*first_private
                private_checks+=1
                if hidden<=65537:
                    # Offline independent enumeration only; candidate C++ has
                    # no loop controlled by hidden/tile/Core/repeat.
                    sizes=[min(256,hidden-begin) for begin in range(0,hidden,256)]
                    brute=sum((tile_private(n,index==len(sizes)-1)
                               for index,n in enumerate(sizes)),F(0))
                    assert analytic==brute
                    brute_checks+=1
            cases.append({'norm_type':'layernorm' if layer else 'rmsnorm','input_dtype':dtype,
                'hidden':hidden,'tiles':tiles,'tail':tail,'statistics_sram_read_bytes_per_core':cost(hidden,True)[0],
                'statistics_sram_write_bytes_per_core':cost(hidden,True)[1],
                'statistics_local_bytes_per_core':cost(hidden,True)[2],
                'statistics_eqops_per_core':cost(hidden,True)[3]})
report={'utc_run':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'validation_kind':'static_integer_and_Fraction_partition_only',
    'model_comparison':'not_run','static_partition':'passed','ledger_cases':len(cases),
    'private_exact_fraction_checks':private_checks,'offline_tile_enumeration_checks':brute_checks,
    'statistics_descriptions':6,'apply_descriptions':9,'launch_descriptions':1,
    'final_statistics_write_bytes_per_core':16,'cases':cases,
    'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(directory/'partition-validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='cases'},indent=2))
