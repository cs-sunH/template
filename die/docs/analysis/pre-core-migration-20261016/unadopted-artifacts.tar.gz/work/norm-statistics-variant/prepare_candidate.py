#!/usr/bin/env python3
"""Prepare an inactive statistics curve candidate; never edit die source."""
import datetime
import difflib
import hashlib
import json
from pathlib import Path

directory=Path(__file__).resolve().parent
root=directory.parents[1]
source=root/'die/src/NormLongRow.hh'
baseline=source.read_text()
candidate=baseline

old='''  Flow statistics=comp(stat_sr,stat_sw,
      EqWork(mul128(layernorm ? 3 : 2,hidden,"Norm long statistics math"))+conversion(hidden,ad));
'''
new='''  const auto stat_compute=[&](u64 n,bool last) {
    const u128 converted=ad=="fp32" ? 0 : mul128(4,n,"Norm long statistics conversion");
    return comp(add128(bytes(n,ad),converted,"Norm long statistics reads"),
        add128(converted,last ? 16 : 0,"Norm long retained statistics write"),
        EqWork(mul128(layernorm ? 3 : 2,n,"Norm long statistics math"))+conversion(n,ad));
  };
  // Only the final tail materializes the retained 16 B statistics. Full
  // statistic tiles have identical per-Core read/write/LOCAL/eq-op ratios;
  // their serial PRIVATE bound is the count times one true tile maximum.
  // Keep the tail separate because its one-time 16 B can change that maximum.
  Flow first_statistics=stat_compute(tile,false),last_statistics=stat_compute(tail,true);
  const u64 middle_stat_elements=hidden-tile-tail;
  Flow middle_statistics=stat_compute(middle_stat_elements,false);
  middle_statistics.private_s=(tiles-2)*first_statistics.private_s;
  Flow statistics=stat_compute(hidden,true);
  statistics.private_s=first_statistics.private_s+middle_statistics.private_s+last_statistics.private_s;
'''
if candidate.count(old)!=1:raise RuntimeError('statistics builder baseline changed')
candidate=candidate.replace(old,new)

old='''  Flow first_stat_load=io(bytes(tile,ad),false),stat_load=io(bytes(hidden,ad),false);
  first_stat_load.credit={{tile,0}};
  append("_statistics_first_input",first_stat_load,{}, {},{{0,0}},{{2*tile,1}});
  Flow remaining_stat_load=subtract_io_flow(stat_load,first_stat_load);
  remaining_stat_load.credit={{static_cast<long double>(hidden-tile),0}};
  statistics.credit={{-static_cast<long double>(hidden),0}};
  append("_statistics_stream",remaining_stat_load,statistics,{},{{tile,0}},{{2*tile,1}});
  const auto statistics_activity=plan.epochs.back().activities.back().id;
'''
new='''  Flow first_stat_load=io(bytes(tile,ad),false),stat_load=io(bytes(hidden,ad),false);
  Flow second_stat_load=first_stat_load;
  first_stat_load.credit={{tile,0}};
  append("_statistics_first_input",first_stat_load,{}, {},{{0,0}},{{2*tile,1}});
  second_stat_load.credit={{tile,0}};first_statistics.credit={{-static_cast<long double>(tile),0}};
  append("_statistics_first_compute_and_prefetch",second_stat_load,first_statistics,{},{{tile,0}},{{2*tile,1}});
  Flow remaining_stat_load=subtract_io_flow(subtract_io_flow(stat_load,first_stat_load),second_stat_load);
  remaining_stat_load.credit={{static_cast<long double>(hidden-2*tile),0}};
  middle_statistics.credit={{-static_cast<long double>(middle_stat_elements),0}};
  append("_statistics_middle_reserved_tail",remaining_stat_load,middle_statistics,{},{{tile,0}},{{2*tile,1}});
  // The middle ends with exactly the final tail input retained. The last
  // Compute owns the sole final-state write; apply cannot enter before this
  // activity has physically completed all of its work.
  last_statistics.credit={{-static_cast<long double>(tail),0}};
  append("_statistics_last_compute",{},last_statistics,{},{{static_cast<double>(tail),0}},{{2*tile,1}});
  const auto statistics_activity=plan.epochs.back().activities.back().id;
'''
if candidate.count(old)!=1:raise RuntimeError('statistics epochs baseline changed')
candidate=candidate.replace(old,new)

old='''  plan.summary["service_curves"].push_back({{"model","analytical_cumulative_norm_long_statistics_v1"},
      {"epoch_begin",begin},{"epoch_count",2},{"description_count",3},{"description_budget",5},
      {"input_unit","one_input_element_at_each_consumer_core"},{"input_units",hidden},
      {"input_capacity_units",2*tile},{"statistics_ready_epoch",begin+1},
      {"statistics_activity_id",statistics_activity},{"statistics_retention","16_bytes_per_core_across_kernel_barrier"}});
'''
new='''  plan.summary["service_curves"].push_back({{"model","analytical_cumulative_norm_long_statistics_v2"},
      {"epoch_begin",begin},{"epoch_count",4},{"description_count",6},{"description_budget",8},
      {"input_unit","one_input_element_at_each_consumer_core"},{"input_units",hidden},
      {"input_capacity_units",2*tile},{"statistics_ready_epoch",begin+3},
      {"statistics_activity_id",statistics_activity},{"statistics_retention","16_bytes_per_core_across_kernel_barrier"},
      {"final_statistics_write_bytes_per_core",16},{"reserved_tail_input_elements_per_core",tail},
      {"statistics_private_bound","sum_of_full_tile_maxima_plus_final_tail_maximum"},
      {"readiness_approximation","first_tile_then_affine_middle_with_terminal_tail_statistics_write"}});
'''
if candidate.count(old)!=1:raise RuntimeError('statistics audit baseline changed')
candidate=candidate.replace(old,new)

old='''      {"metadata_bytes_per_core",64},{"statistics_epoch",begin+1},{"apply_epoch_begin",apply_begin},'''
new='''      {"metadata_bytes_per_core",64},{"statistics_epoch",begin+3},{"apply_epoch_begin",apply_begin},'''
if candidate.count(old)!=1:raise RuntimeError('statistics ledger baseline changed')
candidate=candidate.replace(old,new)

(directory/'NormLongRow.baseline.hh').write_text(baseline)
(directory/'NormLongRow.candidate.hh').write_text(candidate)
patch=''.join(difflib.unified_diff(baseline.splitlines(keepends=True),candidate.splitlines(keepends=True),
    fromfile='a/die/src/NormLongRow.hh',tofile='b/die/src/NormLongRow.hh'))
(directory/'statistics-prefix-tail.patch').write_text(patch)
sha=lambda b:hashlib.sha256(b).hexdigest()
manifest={
    'utc_prepared':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'production_source_modified':False,'model_comparison':'not_run','adoption_status':'inactive_candidate',
    'source_path':'die/src/NormLongRow.hh','baseline_sha256':sha(baseline.encode()),
    'candidate_sha256':sha(candidate.encode()),'patch_sha256':sha(patch.encode()),
    'statistics_descriptions':6,'statistics_budget':8,'apply_descriptions':9,
    'total_without_launch':15,'total_with_launch':16,
    'scope':'BF16/FP32 all roles; R1; 1<=rows<=Core; hidden>512; tile256; unchanged SRAM feasibility',
}
(directory/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))
