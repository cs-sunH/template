from pathlib import Path
import difflib
base=Path('die/src/Execution.cc').read_text();p=Path('work/norm-review/Execution-curved-roundoff-slack.cc').read_text()
needle='void recompute_credit(Execution& execution);';assert p.count(needle)==1
p=p.replace(needle,needle+'\nstd::array<long double, 2> exact_credit(const Execution& execution);')
start=p.index('void recompute_credit(Execution& execution) {')
end=p.index('\nvoid Runtime::advance_to(',start)
body=p[start:end]
body=body.replace('void recompute_credit(Execution& execution) {','std::array<long double, 2> exact_credit(const Execution& execution) {')
body=body.replace('if (execution.epoch >= execution.plan->epochs.size()) return;','if (execution.epoch >= execution.plan->epochs.size()) return {{0,0}};')
body=body.replace('  execution.credit_capacity = epoch.credit_capacity;\n','')
body=body.replace('''    const long double roundoff = curved ? std::min(tolerance,
        16 * std::numeric_limits<long double>::epsilon() * (magnitude[buffer] + std::abs(capacity))) : tolerance;''','''    constexpr long double unit_roundoff = std::numeric_limits<long double>::epsilon()/2;
    constexpr long double gamma32 = (32*unit_roundoff)/(1-32*unit_roundoff);
    const long double roundoff = curved ? std::min(tolerance,
        gamma32 * (magnitude[buffer] + std::abs(capacity))) : tolerance;''')
body=body.replace('    execution.credit[buffer] = static_cast<double>(credit[buffer]);\n','')
body=body.rstrip()[:-1]+'''  return credit;
}

void recompute_credit(Execution& execution) {
  if (execution.epoch >= execution.plan->epochs.size()) return;
  execution.credit_capacity=execution.plan->epochs[execution.epoch].credit_capacity;
  const auto values=exact_credit(execution);
  for (std::size_t buffer=0;buffer<2;++buffer) execution.credit[buffer]=static_cast<double>(values[buffer]);
}
'''
p=p[:start]+body+p[end:]
# Boundary classification in symmetry mask.
p=p.replace('''      unsigned mask = 0;
      for (std::size_t b = 0; b < 2; ++b) {''','''      unsigned mask = 0;
      const auto values=exact_credit(execution);
      for (std::size_t b = 0; b < 2; ++b) {''',1)
p=p.replace('if (execution.credit[b] <= tolerance) mask', 'if (values[b] <= tolerance) mask')
p=p.replace('if (execution.credit[b] >= execution.credit_capacity[b] - tolerance)','if (values[b] >= execution.credit_capacity[b] - tolerance)')
# Singleton.
p=p.replace('''    for(std::size_t b=0;b<2;++b) {
      const double tolerance=curved_epoch(*ref.execution)''','''    const auto values=exact_credit(*ref.execution);
    for(std::size_t b=0;b<2;++b) {
      const double tolerance=curved_epoch(*ref.execution)''')
p=p.replace('const double credit=ref.execution->credit[b];','const long double credit=values[b];')
# General allocation.
p=p.replace('''    (void)execution_handle;
    for (std::size_t buffer = 0; buffer < 2; ++buffer) {
      const double credit = execution->credit[buffer];''','''    (void)execution_handle;
    const auto values=exact_credit(*execution);
    for (std::size_t buffer = 0; buffer < 2; ++buffer) {
      const long double credit = values[buffer];''')
# Both advancement and next_event.
p=p.replace('''      for (std::size_t buffer = 0; buffer < 2; ++buffer) {
        const long double rate = credit_rate[buffer];
        const long double credit = execution.credit[buffer];''','''      const auto values=exact_credit(execution);
      for (std::size_t buffer = 0; buffer < 2; ++buffer) {
        const long double rate = credit_rate[buffer];
        const long double credit = values[buffer];''')
p=p.replace('''    for (std::size_t buffer = 0; buffer < 2; ++buffer) {
      const long double rate = credit_rate[buffer];
      const long double credit = execution.credit[buffer];''','''    const auto values=exact_credit(execution);
    for (std::size_t buffer = 0; buffer < 2; ++buffer) {
      const long double rate = credit_rate[buffer];
      const long double credit = values[buffer];''')
# Saved published rates tangent validation.
p=p.replace('''      for (std::size_t buffer = 0; buffer < 2; ++buffer) {
        const long double capacity = execution.credit_capacity[buffer];
        const long double tolerance = curved_epoch(execution)''','''      const auto values=exact_credit(execution);
      for (std::size_t buffer = 0; buffer < 2; ++buffer) {
        const long double capacity = execution.credit_capacity[buffer];
        const long double tolerance = curved_epoch(execution)''')
p=p.replace('const bool at_low = execution.credit[buffer] <= tolerance;','const bool at_low = values[buffer] <= tolerance;')
p=p.replace('const bool at_high = execution.credit[buffer] >= capacity - tolerance;','const bool at_high = values[buffer] >= capacity - tolerance;')
# Legacy boundary/event arithmetic keeps its historical binary64 credit view.
p=p.replace('const auto values=exact_credit(', 'const auto values=boundary_credit(')
p=p.replace('const auto values=boundary_credit(execution);\n  for (std::size_t buffer=0;buffer<2;++buffer)', 'const auto values=exact_credit(execution);\n  for (std::size_t buffer=0;buffer<2;++buffer)')
p=p.replace('std::array<long double, 2> exact_credit(const Execution& execution);', 'std::array<long double, 2> exact_credit(const Execution& execution);\nstd::array<long double, 2> boundary_credit(const Execution& execution);')
p=p.replace('void recompute_credit(Execution& execution) {', '''std::array<long double, 2> boundary_credit(const Execution& execution) {
  if (curved_epoch(execution)) return exact_credit(execution);
  return {{execution.credit[0],execution.credit[1]}};
}

void recompute_credit(Execution& execution) {''',1)
Path('work/norm-review/Execution-curved-exact-credit.cc').write_text(p)
Path('work/norm-review/curved-exact-credit.patch').write_text(''.join(difflib.unified_diff(base.splitlines(keepends=True),p.splitlines(keepends=True),fromfile='a/die/src/Execution.cc',tofile='b/die/src/Execution.cc')))
