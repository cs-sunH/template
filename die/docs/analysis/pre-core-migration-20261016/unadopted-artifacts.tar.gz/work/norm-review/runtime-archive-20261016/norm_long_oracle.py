#!/usr/bin/env python3
"""Draft offline Norm oracle: BF16/FP32 mixed roles, rows <= 1/2/4 Cores.

The per-Core rows are identical and remain in lockstep, so one owner activity
represents the same tile on each consuming Core. This is an offline discrete
reference, never a production implementation. All 13 resource rows participate
in grouped_rates; routing work is intentionally zero and requires a synthetic
nonbinding-routing fixture. No binding-route or independent hardware evidence.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT / 'die/validation'))
from elementwise_service_oracle import Activity, grouped_rates, compare


def storage(n, dtype):
    if dtype not in ('bf16', 'fp32'):
        raise ValueError('draft rejects INT4 and other storage formats')
    return n * (2 if dtype == 'bf16' else 4)


def facts(raw):
    task = raw['compiled_plan']['task']
    shape = task['tensor_shapes']
    core_count = int(raw['hardware']['derived']['die']['core_count'])
    rows, hidden = int(shape['m']), int(shape['hidden'])
    if core_count not in (1, 2, 4) or not 1 <= rows <= core_count:
        raise ValueError('draft requires 1/2/4 Cores and one row per consuming Core')
    if task['layer_instances'] != 1 or task['weight_passes'] != 1:
        raise ValueError('draft requires one region instance')
    if hidden <= 512 or (hidden + 255) // 256 > 8192:
        raise ValueError('offline width scope: 513..2097152')
    dtypes = task['storage_dtype']
    x, p, y = [dtypes[key] for key in ('activations', 'parameters', 'output')]
    for dt in (x, p, y):
        storage(1, dt)
    layer = shape['norm_type'] == 'layernorm'
    if shape['norm_type'] not in ('layernorm', 'rmsnorm'):
        raise ValueError('unknown Norm type')
    profile = raw['hardware']['input']['performance_profile']
    capacities = [float(r['capacity']) for r in raw['hardware']['resources']]
    peak = float(raw['hardware']['derived']['core']['P_vec_per_core_ops_per_s'])
    return dict(rows=rows, hidden=hidden, core_count=core_count, x=x, p=p, y=y,
                layer=layer, capacities=capacities, peak=peak,
                eta_vec=float(profile['eta_vec']), eta_hbm=float(profile['eta_hbm_vector']))


def independent_ledger(f):
    n, rows, vectors = f['hidden'], f['rows'], 2 if f['layer'] else 1
    xb, pb, yb = storage(n, f['x']), vectors * storage(n, f['p']), storage(n, f['y'])
    xc = 0 if f['x'] == 'fp32' else 4 * n
    pc = 0 if f['p'] == 'fp32' else vectors * 4 * n
    yc = 0 if f['y'] == 'fp32' else 4 * n
    stat_r, stat_w = xb + xc, xc + 16
    apply_r = xb + xc + vectors * 4 * n + yc + (pb if pc else 0) + 16
    apply_w = xc + pc + 4 * n + (yb if yc else 0)
    converted = n * (2 * (f['x'] != 'fp32') + vectors * (f['p'] != 'fp32') + (f['y'] != 'fp32'))
    math_ops = (8 if f['layer'] else 6) * n
    peak = (2 * (storage(256, f['x']) + vectors * storage(256, f['p']))
            + 2 * storage(256, f['y']) + 4 * 256
            + (vectors * 4 * 256 if f['p'] != 'fp32' else 0) + 16 + 64)
    return {'hbm_read_bytes_total': rows * (2 * xb + pb),
            'hbm_write_bytes_total': rows * yb,
            'source_vec_ops': rows * math_ops,
            'vec_equivalent_ops': rows * (math_ops + converted),
            'conversion_elements': rows * converted,
            'sram_read_bytes': rows * (stat_r + apply_r + yb),
            'sram_write_bytes': rows * (stat_w + apply_w + 2 * xb + pb),
            'local_bus_bytes': rows * (stat_r + stat_w + apply_r + apply_w),
            'sram_peak_bytes_per_core': peak,
            'hbm_workspace_peak_bytes': 0}


def simulate(f, arrivals):
    sizes = [min(256, f['hidden'] - begin) for begin in range(0, f['hidden'], 256)]
    vectors, rows = (2 if f['layer'] else 1), f['rows']
    capacities = f['capacities']
    per_core = [cap / f['core_count'] for cap in capacities]
    count, now, events = len(arrivals), 0.0, 0
    states = [['pending'] * len(sizes) for _ in arrivals]
    phases, live = [0] * count, []
    finish, first = [None] * count, [None] * count
    busy = {'hbm_busy_s': 0.0, 'hbm_shared_s': 0.0, 'compute_busy_s': 0.0,
            'row_busy_s': [0.0, 0.0], 'row_shared_s': [0.0, 0.0]}

    def activity(owner, index, role):
        n, phase = sizes[index], phases[owner]
        xb, pb, yb = storage(n, f['x']), vectors * storage(n, f['p']), storage(n, f['y'])
        xc = 0 if f['x'] == 'fp32' else 4 * n
        pc = 0 if f['p'] == 'fp32' else vectors * 4 * n
        yc = 0 if f['y'] == 'fp32' else 4 * n
        work = [0.0] * 13
        if role in ('load', 'store'):
            payload_per_core = yb if role == 'store' else xb + (pb if phase else 0)
            payload = rows * payload_per_core
            resource = 1 if role == 'store' else 2
            work[resource] = payload
            work[4] = work[5] = payload / (2 * f['eta_hbm'])
            quantity = payload
            private = payload_per_core / per_core[resource]
        else:
            if phase == 0:
                sr, sw = xb + xc, xc + (16 if index == len(sizes) - 1 else 0)
                eq = n * ((3 if f['layer'] else 2) + (f['x'] != 'fp32'))
            else:
                sr = xb + xc + vectors * 4 * n + yc + (pb if pc else 0) + (16 if index == 0 else 0)
                sw = xc + pc + 4 * n + (yb if yc else 0)
                eq = n * ((5 if f['layer'] else 4) + (f['x'] != 'fp32')
                          + vectors * (f['p'] != 'fp32') + (f['y'] != 'fp32'))
            work[0] = eq / (f['peak'] * f['eta_vec'])
            work[1], work[2], work[3] = rows * sr, rows * sw, rows * (sr + sw)
            quantity = work[3]
            private = max(work[0], sr / per_core[1], sw / per_core[2], (sr + sw) / per_core[3])
        return Activity(owner, index, role, work, private, quantity)

    while any(value is None for value in finish):
        for owner in range(count):
            if arrivals[owner] > now + 1e-13 or finish[owner] is not None:
                continue
            state = states[owner]
            if all(s == 'stored' for s in state):
                if phases[owner] == 0:
                    phases[owner] = 1
                    states[owner] = state = ['pending'] * len(sizes)
                else:
                    finish[owner] = now
                    continue
            if phases[owner] == 1 and not any(a.request == owner and a.role == 'store' for a in live):
                candidates = [i for i, s in enumerate(state) if s == 'produced']
                if candidates:
                    index = candidates[0]
                    state[index] = 'storing'
                    live.append(activity(owner, index, 'store'))
            if not any(a.request == owner and a.role == 'compute' for a in live):
                used = sum(s in ('computing', 'produced', 'storing') for s in state)
                candidates = [i for i, s in enumerate(state) if s == 'buffered']
                if candidates and (phases[owner] == 0 or used < 2):
                    index = candidates[0]
                    state[index] = 'computing'
                    live.append(activity(owner, index, 'compute'))
            if not any(a.request == owner and a.role == 'load' for a in live):
                used = sum(s in ('loading', 'buffered', 'computing') for s in state)
                candidates = [i for i, s in enumerate(state) if s == 'pending']
                if candidates and used < 2:
                    index = candidates[0]
                    state[index] = 'loading'
                    live.append(activity(owner, index, 'load'))
        if all(value is not None for value in finish):
            break
        rates = grouped_rates(live, capacities) if live else []
        future = [value - now for value in arrivals if value > now + 1e-13]
        future += [(1 - a.progress) / rate for a, rate in zip(live, rates) if rate > 0]
        if not future:
            raise ArithmeticError('oracle deadlock')
        delta = min(future)
        if not math.isfinite(delta) or delta <= 0:
            raise ArithmeticError('oracle nonpositive interval')
        hbm, compute, row_owners = set(), set(), [set(), set()]
        for a, rate in zip(live, rates):
            if rate <= 0:
                continue
            a.progress += rate * delta
            if a.work[0] > 0:
                compute.add(a.request)
            for row in (0, 1):
                if a.work[4 + row] > 0:
                    row_owners[row].add(a.request)
                    hbm.add(a.request)
        busy['hbm_busy_s'] += delta if hbm else 0
        busy['hbm_shared_s'] += delta if len(hbm) >= 2 else 0
        busy['compute_busy_s'] += delta if compute else 0
        for row in (0, 1):
            busy['row_busy_s'][row] += delta if row_owners[row] else 0
            busy['row_shared_s'][row] += delta if len(row_owners[row]) >= 2 else 0
        now += delta
        for a in live:
            if a.progress >= 1 - 1e-10:
                state = states[a.request]
                if a.role == 'load':
                    state[a.block] = 'buffered'
                elif a.role == 'store' or phases[a.request] == 0:
                    state[a.block] = 'stored'
                else:
                    state[a.block] = 'produced'
                    if first[a.request] is None:
                        first[a.request] = now
        live = [a for a in live if a.progress < 1 - 1e-10]
        events += 1
        if events > 200000:
            raise ArithmeticError('offline event guard')
    return {'finish_s': finish, 'first_output_ready_s': first, 'counters': busy,
            'discrete_events': events,
            'scope': 'identical per-Core rows; complete statistics barrier; two physical input/output slots; routing nonbinding'}


def report(raw):
    f = facts(raw)
    expected = independent_ledger(f)
    summary = raw['compiled_plan']['summary']
    for key, value in expected.items():
        if summary[key] != value:
            raise ValueError(f'independent ledger mismatch: {key}: {summary[key]} != {value}')
    launch = int(raw['compiled_plan']['wire'].get('launch_ns', 0))
    scenarios = {}
    for name, actual in raw['runs'].items():
        arrivals = [(int(n) + launch) / 1e9 for n in actual['arrivals_ns']]
        reference = simulate(f, arrivals)
        scenarios[name] = {'reference': reference, 'comparison': compare(actual, reference)}
    return {'status': 'draft_not_adopted', 'scope': __doc__, 'independent_ledger': expected,
            'ledger_matches': True, 'scenarios': scenarios, 'parameters_fitted': False,
            'hardware_calibration': 'not_available', 'binding_routing': 'not_available',
            'source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--raw', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    output = Path(args.output)
    if output.exists():
        parser.error('fresh output required')
    result = report(json.loads(Path(args.raw).read_text()))
    output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({name: item['comparison']['status'] for name, item in result['scenarios'].items()}))


if __name__ == '__main__':
    main()
