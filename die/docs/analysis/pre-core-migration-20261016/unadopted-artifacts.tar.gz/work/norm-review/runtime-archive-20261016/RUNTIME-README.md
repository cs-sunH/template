# Runtime credit research archive — stopped, not adopted

Stopped on the user's new unique-Core design instruction. No Runtime prototype
has been applied to `die/src/Execution.cc`; that file still matches Git
`04c63312e1e269911ba0818fe3212f2899199b8c`. This directory contains text only:
source patches, generator/runner scripts, input test source, actual raw/logs,
status and SHA manifest. No object, ELF, shared/static library or cache is part
of this archive. Old small/large-Core naming in copied research fixtures is
historical and does not override the newest root DOCX.

## Reproducible findings

The original failing long-row fixture is RMSNorm, hidden65537, balanced,
Cores4/rows1, activations BF16, parameters/output FP32. Its synchronized owners
stall at apply-middle epoch4. Load13 and Store15 are terminal, while Compute14
has exact progress `9.999999999997531472231e-01`. Remaining progress is
`2.468527769e-13`, above the existing progress-close limit `2e-13`.
Its actual input credit is `255*(1-p)=6.29474581095e-11`; output credit is
`-254*(1-p)=-6.27006053326e-11`. Original recompute snaps both to zero under
the existing `2e-10` credit tolerance. With the only consumer blocked on zero
input, Runtime has no next event. Tightening endpoint projection alone does
not resolve this; its actual failing raw snapshot is retained.

Preserving positive credit and classifying curved boundaries exactly resolves
that fixture and preserves the independent tiny-slack regression, but exposes
another problem: `min_positive` discards genuine boundary intervals at or below
`1e-15ns`. Exact-boundary prototypes therefore fail unrelated actual cases;
they must not be adopted merely because the original fixture completes.

`boundary-diagnostic.stderr.log` preserves the complete first normal RMS BF16
ledger case trace. At epoch4 output credit `0.780244836199371571972` and net
credit rate `-223750712.250712247449/s`, Runtime integrates
`3.487116659209150213664ns` toward empty. A remaining actual credit
`3.707971429900425164305e-17` has a real boundary interval
`1.657188659916152682682e-16ns`. `min_positive` drops it and instead integrates
the remaining public-tick interval `0.512883340790849786336ns`, causing output
credit `-0.11475801280347738`. The original event time consumed a binary64
credit projection even though progress/cumulative expressions are long double.

Recomputing curved credit from exact progress for internal classification and
events fixes that case and the next two mixed combinations. It still fails the
fourth combination with input `1.0622468484693504`. Real very small headroom
can also arise from certified downward-rounded tangent rates, so arithmetic
roundoff clamping alone does not justify dropping the next physical event.

## Version results

| Prototype | Actual result |
|---|---|
| strict-projection | Original driver still fails; snapshot remains stalled. |
| positive-slack global diagnostic | Original driver completes; legacy also changed, other regression targets not run. Diagnostic only. |
| curved-positive-slack | Driver/curve-runtime/clock/symmetry/ratio pass; credit-scale and long-row fail finite credit. Separate tiny-slack test passes. |
| curved-roundoff-slack | Seven of eight scratch targets pass; long-row first BF16 case fails output credit. |
| curved-exact-credit, legacy preserved | Seven of eight targets pass; long-row fourth mixed case fails input credit. |
| curved-sub-epsilon | Compilation passed. Driver, eight targets, event amplification and budgets **not_run**. User steering arrived before execution. |

The scratch eight-target set is the original failing oracle driver,
service_curve_runtime, runtime_credit_scale, runtime_clock_translation,
runtime_owner_symmetry, ratio_allocator, norm_long_row, and the new independent
runtime_credit_slack test. These are separately relinked existing test objects
with one scratch Execution object and the existing static library; they are
not a production CTest certificate. Per-version `*-scratch-summary.json` and
stdout/stderr/link logs retain each success and failure.

The tiny-slack test is copied without weakening its assertions. For unit values
1, 2^-10 and 2^-60 in both emptying/filling directions, one trillion operations
must really consume half a second before finite credit blocks. It verifies
250ms snapshot continuation, no unpaid remaining-half service at750ms and
cancellation. It passes every tested positive-slack prototype. An initial
scratch compile omitted COARSE_DIE_ROOT_DIR; its failure is explicitly retained
as a transcribed tool-output note, followed by the actual corrected build logs.

## Numerical representation scope and unverified next idea

The exact-credit candidate uses a stateless helper to recompute credit from
Plan plus exact progress. Its double array remains the wire/diagnostic view;
all curved boundary masks, singleton/LP constraints, advancement, next_event
and saved-rate tangent validation use the helper. Legacy decisions retain their
old binary64 array and tolerance. Original illegal-credit rejection threshold,
physical work, PRIVATE, max-min allocation and strict tangent certification are
unchanged in the scratch sources.

Only arithmetic uncertainty is clamped by the candidate's gamma32 expression:
`u=epsilon(long double)/2`, `gamma32=32*u/(1-32*u)`, multiplied by the sum of
absolute initial/cumulative contributions plus capacity, capped at the original
credit tolerance. At most three activities exist. A monotone affine segment
needs at most six basic arithmetic operations for a cumulative value; three
values, four accumulation steps, a boundary difference and evaluation of the
bound fit a conservative32-operation normal-arithmetic budget. This is an
explicit bound candidate, **not a completed proof for every legal numerical
input**: underflow/subnormal interpolation paths and changing-segment extremes
were not independently certified. No success claim is made from the constant.

The last compiled candidate additionally retains every positive curved event
interval, including intervals below the old1e-15ns cutoff; legacy filtering is
unchanged. It rejects nonpositive internal intervals. This is a proposed fix
for the demonstrated dropped event, not a validated result. Its source patch
and generator are saved, but do not resume it until the authoritative new Core
design and current task priority are established. No time/progress/credit
tolerance was enlarged to manufacture a pass.

## Sources and reproduction

`archive-status.json` lists the baseline source identity, each version and scope.
Every `Execution-*.patch` applies to the unchanged baseline Execution.cc; these
replace repeated full source copies. Generator scripts reconstruct the proposed
versions. Runner scripts record the exact scratch link and run commands. Build
commands use C++17/O3, normal die/src and die/include plus the existing helper
JSON include path. Test input sources are under `test-source/`.

`SHA256-manifest.json` hashes all archived text. Object/library hashes in the
status were captured at archive time, not claimed as contemporaneous hashes of
every past run. Binary artifacts remain transient outside this archive and are
deliberately excluded. Parent integration, full public regression, API equality,
model accuracy, production speed and five-repository publication remain outside
this research archive's acceptance scope.
