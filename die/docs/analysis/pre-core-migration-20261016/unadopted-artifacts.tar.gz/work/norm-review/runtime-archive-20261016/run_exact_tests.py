from pathlib import Path
import subprocess,json,hashlib,time
root=Path.cwd();out=root/'work/norm-review';build=root/'work/build-die-canonical';obj=out/'Execution-curved-exact-credit.o';lib=build/'libcoarse_die.a'
names=['norm_long_oracle_driver','service_curve_runtime_test','runtime_credit_scale_test','runtime_clock_translation_test','runtime_owner_symmetry_test','ratio_allocator_test','norm_long_row_test','runtime_credit_slack_test']
results=[]
for name in names:
 source_object=(out/'runtime_credit_slack_test.o') if name=='runtime_credit_slack_test' else build/f'CMakeFiles/coarse_{name}.dir/tests/{name}.cc.o';exe=out/f'curved-exact-{name}'
 cmd=['g++',str(source_object),str(obj),str(lib),'-o',str(exe)]
 with (out/f'curved-exact-{name}-link.log').open('w') as log:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 row={'target':name,'link_return_code':p.returncode}
 if p.returncode==0:
  cmd=[str(exe)]
  if name=='norm_long_oracle_driver':cmd+=['--hidden','65537','--norm','rmsnorm','--profile','balanced','--cores','4','--rows','1','--activation-dtype','bf16','--parameter-dtype','fp32','--output-dtype','fp32']
  start=time.time()
  with (out/f'curved-exact-{name}.stdout.log').open('w') as log,(out/f'curved-exact-{name}.stderr.log').open('w') as err:p=subprocess.run(cmd,stdout=log,stderr=err)
  row.update(run_return_code=p.returncode,elapsed_s=time.time()-start,command=cmd)
 print(json.dumps(row),flush=True);results.append(row)
summary={'scope':'scratch object overrides Execution only; existing current test objects and library; not production CTest evidence','scratch_source_sha256':hashlib.sha256((out/'Execution-curved-exact-credit.cc').read_bytes()).hexdigest(),'scratch_object_sha256':hashlib.sha256(obj.read_bytes()).hexdigest(),'results':results}
(out/'curved-exact-scratch-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
