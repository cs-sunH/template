from pathlib import Path
import difflib
base=Path('die/src/Execution.cc').read_text();p=Path('work/norm-review/Execution-curved-exact-credit.cc').read_text()
for begin,end in [('void Runtime::advance_to(', '\nvoid Runtime::cancel('),('std::optional<std::uint64_t> Runtime::next_event() const {','\nnlohmann::json Runtime::query_progress(')]:
 s=p.index(begin);e=p.index(end,s);body=p[s:e]
 needle='''    (void)handle;'''
 if begin.startswith('void Runtime::advance_to'):needle='''      (void)handle;'''
 lambda_body=needle+'''
      const auto local_min_positive = [&](long double current,long double candidate) {
        if (!curved_epoch(execution)) return min_positive(current,candidate);
        if (!std::isfinite(candidate) || candidate<=0) return current;
        return candidate<current ? candidate : current;
      };'''
 assert body.count(needle)>=1
 body=body.replace(needle,lambda_body,1)
 body=body.replace('= min_positive(', '= local_min_positive(')
 if begin.startswith('void Runtime::advance_to'):
  assert 'if (next_delta <= kTimeEpsilonNs)' in body
  body=body.replace('if (next_delta <= kTimeEpsilonNs)', 'if (next_delta <= 0.0L)')
 p=p[:s]+body+p[e:]
Path('work/norm-review/Execution-curved-sub-epsilon.cc').write_text(p)
Path('work/norm-review/curved-sub-epsilon.patch').write_text(''.join(difflib.unified_diff(base.splitlines(keepends=True),p.splitlines(keepends=True),fromfile='a/die/src/Execution.cc',tofile='b/die/src/Execution.cc')))
