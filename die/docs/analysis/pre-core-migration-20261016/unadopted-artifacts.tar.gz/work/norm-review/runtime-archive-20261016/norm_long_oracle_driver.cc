// Draft: build with -I<repo>/die/tests and link the current coarse_die library.
// Syntax-checked only; not linked or executed. Not an adopted repository test.
#define main elementwise_driver_unused_main
#include "elementwise_oracle_driver.cc"
#undef main
int main(int argc,char** argv) {
  try {
    std::uint64_t hidden=65537,cores=1,rows=1,offset=500000000;
    std::string norm="rmsnorm",profile="balanced",x="bf16",p="bf16",y="bf16";
    for(int i=1;i<argc;++i) {
      const std::string key=argv[i];if(i+1==argc)throw std::invalid_argument("missing option value");
      const std::string value=argv[++i];
      if(key=="--hidden")hidden=number(value);
      else if(key=="--cores")cores=number(value);
      else if(key=="--rows")rows=number(value);
      else if(key=="--offset-ns")offset=number(value,true);
      else if(key=="--norm")norm=value;
      else if(key=="--profile")profile=value;
      else if(key=="--activation-dtype")x=value;
      else if(key=="--parameter-dtype")p=value;
      else if(key=="--output-dtype")y=value;
      else throw std::invalid_argument("unknown option "+key);
    }
    if((cores!=1 && cores!=2 && cores!=4) || rows<1 || rows>cores || hidden<=512 || hidden>2097152)
      throw std::invalid_argument("draft scope: cores1/2/4, rows1..cores, hidden513..2097152");
    for(const auto& dt:{x,p,y})if(dt!="bf16" && dt!="fp32")
      throw std::invalid_argument("draft explicitly rejects INT4 and other dtypes");
    if(norm!="rmsnorm" && norm!="layernorm")throw std::invalid_argument("unknown Norm");
    if(profile!="balanced" && profile!="memory" && profile!="compute" && profile!="local")
      throw std::invalid_argument("unknown synthetic profile");
    std::ifstream file(std::string(COARSE_DIE_SOURCE_DIR)+"/configs/example_hardware_explicit.json");
    if(!file)throw std::runtime_error("cannot read explicit fixture");
    json cfg=json::parse(file);
    cfg["architecture"]["core_type"]="small";
    cfg["architecture"]["core_columns_nx"]=cores;cfg["architecture"]["core_rows_ny"]=1;
    cfg["performance_profile"]["eta_vec"]=1.0;
    cfg["performance_profile"]["eta_hbm_vector"]=1.0;
    cfg["performance_profile"]["launch_ns_per_macro"]=0;
    cfg["performance_profile"]["memory_setup_ns_per_macro"]=0;
    auto hw=resolve_hardware(cfg);
    const unsigned vectors=norm=="layernorm" ? 2 : 1;
    const unsigned math=norm=="layernorm" ? 8 : 6;
    const unsigned ops_per_element=math+2*(x!="fp32")+vectors*(p!="fp32")+(y!="fp32");
    double peak=ops_per_element*25600.0;
    if(profile=="memory" || profile=="local")peak*=100;
    if(profile=="compute")peak*=0.1;
    hw.derived["core"]["P_vec_per_core_ops_per_s"]=peak;
    const double xc=x=="fp32" ? 0 : 4,pc=p=="fp32" ? 0 : 4*vectors,yc=y=="fp32" ? 0 : 4;
    const double sr=storage(1,x)+xc+4*vectors+yc+(pc ? vectors*storage(1,p) : 0);
    const double sw=xc+pc+4+(yc ? storage(1,y) : 0);
    for(std::size_t r=0;r<resource_count;++r) {
      const bool enabled=hw.derived["resources"][r]["enabled"].get<bool>();
      double rate=enabled ? 1.0e12*cores : 0;
      if(r==COMPUTE_GATE)rate=1.0;
      if(r==HBM0 || r==HBM1)rate=profile=="local" ? 1.0e9 : 51200.0*cores;
      if(r==LOCAL && profile=="local")rate=(sr+sw)*25600.0*cores;
      hw.rates[r]=rate;hw.derived["resources"][r]["rate"]=rate;
    }
    hw.fingerprint="synthetic-norm-long-mixed-draft:"+stable_hash(hw.fingerprint+":"+norm+":"+
        std::to_string(hidden)+":"+std::to_string(rows)+":"+profile+":"+x+":"+p+":"+y+":"+std::to_string(peak));
    const json spec={{"op_kind","norm"},{"tensor_shapes",{{"m",rows},{"hidden",hidden},{"norm_type",norm}}},
        {"storage_dtype",{{"activations",x},{"parameters",p},{"output",y}}},
        {"layer_instances",1},{"weight_passes",1}};
    const auto plan=compile(hw,spec);
    if(!plan->summary.contains("norm_long_row_ledger"))throw std::runtime_error("fixture did not select long-row mapping");
    json resources=json::array();
    for(std::size_t r=0;r<resource_count;++r)resources.push_back({{"name",names[r]},{"capacity",hw.rates[r]}});
    std::cout<<json({{"schema_version",1},{"scope","draft_mixed_BF16_FP32_nonbinding_routing_not_hardware_calibration"},
        {"fixture",{{"hidden",hidden},{"rows",rows},{"cores",cores},{"norm",norm},{"profile",profile},
                    {"activation_dtype",x},{"parameter_dtype",p},{"output_dtype",y}}},
        {"hardware",{{"input",hw.input},{"derived",hw.derived},{"resources",resources},{"fingerprint",hw.fingerprint}}},
        {"compiled_plan",plan_data(*plan)},
        {"runs",{{"solo",run(hw,plan,{0})},{"sync",run(hw,plan,{0,0})},{"offset",run(hw,plan,{0,offset})}}}}).dump(2)<<'\n';
    return 0;
  }catch(const std::exception& e){std::cerr<<"norm_long_oracle_driver: "<<e.what()<<'\n';return 1;}
}
