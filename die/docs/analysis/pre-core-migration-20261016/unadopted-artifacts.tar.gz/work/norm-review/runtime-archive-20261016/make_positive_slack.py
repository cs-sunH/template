from pathlib import Path
import difflib
src=Path('die/src/Execution.cc');p=src.read_text();base=p
needle='constexpr std::uint64_t kMaxAdvanceEvents = 1000000;'
helper='''

// Preserve genuine interior credit for cumulative curves. Validation still
// uses the original finite-buffer tolerance for roundoff outside the range.
bool curved_epoch(const Execution& execution) {
  return execution.epoch < execution.plan->epochs.size() && std::any_of(
      execution.plan->epochs[execution.epoch].activities.begin(),
      execution.plan->epochs[execution.epoch].activities.end(),
      [](const Activity& activity){ return !activity.credit_curve.empty(); });
}'''
assert p.count(needle)==1;p=p.replace(needle,needle+helper)
def replace(old,new,count=1):
 global p
 assert p.count(old)==count,(old,p.count(old));p=p.replace(old,new)
replace('''const double tolerance = kCreditTolerance *
            std::max(1.0, execution.credit_capacity[b]);''','''const double tolerance = curved_epoch(execution) ? 0.0 : kCreditTolerance *
            std::max(1.0, execution.credit_capacity[b]);''')
replace('const double tolerance=kCreditTolerance*std::max(1.0,ref.execution->credit_capacity[b]);','const double tolerance=curved_epoch(*ref.execution) ? 0.0 : kCreditTolerance*std::max(1.0,ref.execution->credit_capacity[b]);')
replace('const double tolerance = kCreditTolerance * std::max(1.0, capacity);','const double tolerance = curved_epoch(*execution) ? 0.0 : kCreditTolerance * std::max(1.0, capacity);')
replace('''    if (std::abs(credit[buffer]) <= tolerance) credit[buffer] = 0.0L;
    if (std::abs(credit[buffer] - capacity) <= tolerance) credit[buffer] = capacity;''','''    const bool curved = curved_epoch(execution);
    if ((!curved || credit[buffer] < 0.0L) && std::abs(credit[buffer]) <= tolerance) credit[buffer] = 0.0L;
    if ((!curved || credit[buffer] > capacity) && std::abs(credit[buffer] - capacity) <= tolerance) credit[buffer] = capacity;''')
replace('credit < capacity - kCreditTolerance','credit < capacity - (curved_epoch(execution) ? 0.0L : kCreditTolerance)',2)
replace('credit > kCreditTolerance','credit > (curved_epoch(execution) ? 0.0L : kCreditTolerance)',2)
replace('''        const long double tolerance = static_cast<long double>(kCreditTolerance) *
            std::max(1.0L, capacity);
        const bool at_low = execution.credit[buffer] <= tolerance;''','''        const long double tolerance = curved_epoch(execution) ? 0.0L : static_cast<long double>(kCreditTolerance) *
            std::max(1.0L, capacity);
        const bool at_low = execution.credit[buffer] <= tolerance;''')
Path('work/norm-review/Execution-curved-positive-slack.cc').write_text(p)
Path('work/norm-review/curved-positive-slack.patch').write_text(''.join(difflib.unified_diff(base.splitlines(keepends=True),p.splitlines(keepends=True),fromfile='a/die/src/Execution.cc',tofile='b/die/src/Execution.cc')))
